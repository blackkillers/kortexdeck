---
name: file
description: "Injects the exact content of a specific source file into the prompt context."
category: "Code & Refactor"
platform: "cursor"
type: "Extension"
difficulty: "Beginner"
tags: ["cursor", "file", "context", "targeting"]
---

# Target File Inclusion (@file)

> **Platform**: `CURSOR` | **Category**: `Code & Refactor` | **Type**: `Extension` | **Difficulty**: `Beginner`

## 1. Executive Summary & Purpose
Focuses model attention on critical interfaces (e.g. types/database.ts) without saturating the token window.

## 2. Activation Syntax & Command Line
```bash
@file <file_path>
```

## 3. Core Behavioral Directives & Execution Protocol
1. **Context Initialization**: Prioritize zero-latency client-side execution, defensive boundaries, and strict type safety.
2. **Autonomous Execution**: When triggered via `@file`, execute all sub-tasks systematically until complete verification.
3. **Safety & Privacy**: Sanitize all inputs. Never log or transmit authentication credentials, private tokens, or sensitive user environment data.
4. **Error Handling**: Gracefully recover from network or parsing anomalies with actionable diagnostic logs.

## 4. Practical Implementation Example
```markdown
@file src/types/auth.ts Implement session verification helpers conforming to these interfaces.
```

## 5. Multi-Platform Agent Compatibility Matrix
- **Google Antigravity**: Native support via `/goal`, `/schedule`, and rule sidecars.
- **Anthropic Claude Code**: Integrated into `CLAUDE.md` and XML system prompt blocks.
- **Cursor IDE**: Direct compilation into `.cursorrules` and semantic index queries.
- **Windsurf / Codex / Cline / Roo Code**: Universal MCP and system prompt compatible.
