---
name: logo-001
description: "Generate scalable SVG logos with geometric shapes, gradients, and typography"
category: "Logo & Branding"
platform: "Design"
type: "Vector"
difficulty: "Advanced"
tags: ["svg", "logo", "design", "vector", "branding"]
---

# SVG Logo Generator

> **Platform**: `DESIGN` | **Category**: `Logo & Branding` | **Type**: `Vector` | **Difficulty**: `Advanced`

## 1. Executive Summary & Purpose
SVG logo creation: geometric primitives, GSAP animations, gradient definitions, text paths, clip masks, responsive viewBox, and multi-format export (SVG, PNG, ICO, WebP)

## 2. Activation Syntax & Command Line
```bash
/svg-logo [concept] [--style minimal|bold|gradient|3d] [--animate] [--export all]
```

## 3. Core Behavioral Directives & Execution Protocol
1. **Context Initialization**: Prioritize zero-latency client-side execution, defensive boundaries, and strict type safety.
2. **Autonomous Execution**: When triggered via `/svg-logo`, execute all sub-tasks systematically until complete verification.
3. **Safety & Privacy**: Sanitize all inputs. Never log or transmit authentication credentials, private tokens, or sensitive user environment data.
4. **Error Handling**: Gracefully recover from network or parsing anomalies with actionable diagnostic logs.

## 4. Practical Implementation Example
```markdown
/svg-logo tech-startup --style gradient --animate --export all
```

## 5. Multi-Platform Agent Compatibility Matrix
- **Google Antigravity**: Native support via `/goal`, `/schedule`, and rule sidecars.
- **Anthropic Claude Code**: Integrated into `CLAUDE.md` and XML system prompt blocks.
- **Cursor IDE**: Direct compilation into `.cursorrules` and semantic index queries.
- **Windsurf / Codex / Cline / Roo Code**: Universal MCP and system prompt compatible.
