---
name: db-008
description: "Build Elasticsearch queries: fuzzy search, facets, highlighting, aggregations"
category: "Database"
platform: "Database"
type: "Search"
difficulty: "Advanced"
tags: ["elasticsearch", "full-text-search", "search", "analytics"]
---

# Elasticsearch Full-Text Search

> **Platform**: `DATABASE` | **Category**: `Database` | **Type**: `Search` | **Difficulty**: `Advanced`

## 1. Executive Summary & Purpose
Elasticsearch mastery: index mapping, analyzers/tokenizers, multi-match query, fuzzy search, geo-distance, aggregation buckets/metrics, and suggestion completion

## 2. Activation Syntax & Command Line
```bash
/elastic-search [query-type] [--index] [--fuzzy] [--highlight] [--aggs]
```

## 3. Core Behavioral Directives & Execution Protocol
1. **Context Initialization**: Prioritize zero-latency client-side execution, defensive boundaries, and strict type safety.
2. **Autonomous Execution**: When triggered via `/elastic-search`, execute all sub-tasks systematically until complete verification.
3. **Safety & Privacy**: Sanitize all inputs. Never log or transmit authentication credentials, private tokens, or sensitive user environment data.
4. **Error Handling**: Gracefully recover from network or parsing anomalies with actionable diagnostic logs.

## 4. Practical Implementation Example
```markdown
/elastic-search multi-match --fuzzy --highlight --aggs facets
```

## 5. Multi-Platform Agent Compatibility Matrix
- **Google Antigravity**: Native support via `/goal`, `/schedule`, and rule sidecars.
- **Anthropic Claude Code**: Integrated into `CLAUDE.md` and XML system prompt blocks.
- **Cursor IDE**: Direct compilation into `.cursorrules` and semantic index queries.
- **Windsurf / Codex / Cline / Roo Code**: Universal MCP and system prompt compatible.
