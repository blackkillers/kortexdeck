---
name: bk-002
description: "Generate FastAPI async endpoints with Pydantic models and OpenAPI docs"
category: "Backend & API"
platform: "Backend"
type: "Framework"
difficulty: "Advanced"
tags: ["fastapi", "python", "async", "api"]
---

# FastAPI Async Endpoints

> **Platform**: `BACKEND` | **Category**: `Backend & API` | **Type**: `Framework` | **Difficulty**: `Advanced`

## 1. Executive Summary & Purpose
Build high-performance async Python APIs with FastAPI, Pydantic v2, SQLAlchemy async, Alembic migrations, and automatic OpenAPI/Swagger documentation

## 2. Activation Syntax & Command Line
```bash
/fastapi-async [endpoint] [--model pydantic] [--db sqlalchemy]
```

## 3. Core Behavioral Directives & Execution Protocol
1. **Context Initialization**: Prioritize zero-latency client-side execution, defensive boundaries, and strict type safety.
2. **Autonomous Execution**: When triggered via `/fastapi-async`, execute all sub-tasks systematically until complete verification.
3. **Safety & Privacy**: Sanitize all inputs. Never log or transmit authentication credentials, private tokens, or sensitive user environment data.
4. **Error Handling**: Gracefully recover from network or parsing anomalies with actionable diagnostic logs.

## 4. Practical Implementation Example
```markdown
/fastapi-async /items --model Product --db sqlalchemy
```

## 5. Multi-Platform Agent Compatibility Matrix
- **Google Antigravity**: Native support via `/goal`, `/schedule`, and rule sidecars.
- **Anthropic Claude Code**: Integrated into `CLAUDE.md` and XML system prompt blocks.
- **Cursor IDE**: Direct compilation into `.cursorrules` and semantic index queries.
- **Windsurf / Codex / Cline / Roo Code**: Universal MCP and system prompt compatible.
