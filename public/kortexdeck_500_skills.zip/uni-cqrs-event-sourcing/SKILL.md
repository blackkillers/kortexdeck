---
name: uni-cqrs-event-sourcing
description: "Separates read and write data models with append-only immutable event logs for auditability and scale."
category: "Architecture & System"
platform: "universal"
type: "Workflow"
difficulty: "Expert"
tags: ["uni-cqrs-event-sourcing", "universal", "architecture", "engineering"]
---

# CQRS & Event Sourcing Architecture

> **Platform**: `UNIVERSAL` | **Category**: `Architecture & System` | **Type**: `Workflow` | **Difficulty**: `Expert`

## 1. Executive Summary & Purpose
Universal software engineering workflow: Separates read and write data models with append-only immutable event logs for auditability and scale. Applicable across all modern tech stacks.

## 2. Activation Syntax & Command Line
```bash
/cqrs-pattern --target <module> [--apply]
```

## 3. Core Behavioral Directives & Execution Protocol
1. **Context Initialization**: Prioritize zero-latency client-side execution, defensive boundaries, and strict type safety.
2. **Autonomous Execution**: When triggered via `/cqrs-pattern`, execute all sub-tasks systematically until complete verification.
3. **Safety & Privacy**: Sanitize all inputs. Never log or transmit authentication credentials, private tokens, or sensitive user environment data.
4. **Error Handling**: Gracefully recover from network or parsing anomalies with actionable diagnostic logs.

## 4. Practical Implementation Example
```markdown
/cqrs-pattern --target src/billing --apply
```

## 5. Multi-Platform Agent Compatibility Matrix
- **Google Antigravity**: Native support via `/goal`, `/schedule`, and rule sidecars.
- **Anthropic Claude Code**: Integrated into `CLAUDE.md` and XML system prompt blocks.
- **Cursor IDE**: Direct compilation into `.cursorrules` and semantic index queries.
- **Windsurf / Codex / Cline / Roo Code**: Universal MCP and system prompt compatible.
