---
name: claude-model
description: "Dynamically switches between Claude 3.7 Sonnet, Claude 3.5 Haiku, and Opus with extended thinking."
category: "Workflow & Agents"
platform: "claude"
type: "Slash Command"
difficulty: "Beginner"
tags: ["model", "claude", "claude-code", "workflow & agents", "cli"]
---

# Model Switcher

> **Platform**: `CLAUDE` | **Category**: `Workflow & Agents` | **Type**: `Slash Command` | **Difficulty**: `Beginner`

## 1. Executive Summary & Purpose
Official Anthropic Claude Code slash command for model switcher. Dynamically switches between Claude 3.7 Sonnet, Claude 3.5 Haiku, and Opus with extended thinking.

## 2. Activation Syntax & Command Line
```bash
/model [options] [arguments]
```

## 3. Core Behavioral Directives & Execution Protocol
1. **Context Initialization**: Prioritize zero-latency client-side execution, defensive boundaries, and strict type safety.
2. **Autonomous Execution**: When triggered via `/model`, execute all sub-tasks systematically until complete verification.
3. **Safety & Privacy**: Sanitize all inputs. Never log or transmit authentication credentials, private tokens, or sensitive user environment data.
4. **Error Handling**: Gracefully recover from network or parsing anomalies with actionable diagnostic logs.

## 4. Practical Implementation Example
```markdown
/model --help
```

## 5. Multi-Platform Agent Compatibility Matrix
- **Google Antigravity**: Native support via `/goal`, `/schedule`, and rule sidecars.
- **Anthropic Claude Code**: Integrated into `CLAUDE.md` and XML system prompt blocks.
- **Cursor IDE**: Direct compilation into `.cursorrules` and semantic index queries.
- **Windsurf / Codex / Cline / Roo Code**: Universal MCP and system prompt compatible.
