---
name: mcp-server-sqlite
description: "Fast querying, schema inspection, and data mutations on local SQLite files."
category: "Data & Analytics"
platform: "mcp"
type: "MCP Server"
difficulty: "Beginner"
tags: ["sqlite", "mcp", "server", "model-context-protocol", "data & analytics"]
---

# MCP SQLite Embedded Database

> **Platform**: `MCP` | **Category**: `Data & Analytics` | **Type**: `MCP Server` | **Difficulty**: `Beginner`

## 1. Executive Summary & Purpose
Official Model Context Protocol (MCP) server: MCP SQLite Embedded Database. Connects AI models directly to the sqlite ecosystem.

## 2. Activation Syntax & Command Line
```bash
npx -y @modelcontextprotocol/server-sqlite [options]
```

## 3. Core Behavioral Directives & Execution Protocol
1. **Context Initialization**: Prioritize zero-latency client-side execution, defensive boundaries, and strict type safety.
2. **Autonomous Execution**: When triggered via `mcp://sqlite`, execute all sub-tasks systematically until complete verification.
3. **Safety & Privacy**: Sanitize all inputs. Never log or transmit authentication credentials, private tokens, or sensitive user environment data.
4. **Error Handling**: Gracefully recover from network or parsing anomalies with actionable diagnostic logs.

## 4. Practical Implementation Example
```markdown
npx -y @modelcontextprotocol/server-sqlite --port 3000
```

## 5. Multi-Platform Agent Compatibility Matrix
- **Google Antigravity**: Native support via `/goal`, `/schedule`, and rule sidecars.
- **Anthropic Claude Code**: Integrated into `CLAUDE.md` and XML system prompt blocks.
- **Cursor IDE**: Direct compilation into `.cursorrules` and semantic index queries.
- **Windsurf / Codex / Cline / Roo Code**: Universal MCP and system prompt compatible.
