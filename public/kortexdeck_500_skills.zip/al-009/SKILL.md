---
name: al-009
description: "Systematic backtracking: N-Queens, Sudoku solver, permutations, combinations"
category: "Algorithmique"
platform: "Algorithm"
type: "Search"
difficulty: "Advanced"
tags: ["backtracking", "recursion", "dfs", "algorithm"]
---

# Backtracking Framework

> **Platform**: `ALGORITHM` | **Category**: `Algorithmique` | **Type**: `Search` | **Difficulty**: `Advanced`

## 1. Executive Summary & Purpose
Build backtracking solutions: N-Queens, Sudoku, word search, phone number permutations, subsets, combination sum, and pruning strategies for optimization

## 2. Activation Syntax & Command Line
```bash
/backtrack [problem] [--prune] [--visualize]
```

## 3. Core Behavioral Directives & Execution Protocol
1. **Context Initialization**: Prioritize zero-latency client-side execution, defensive boundaries, and strict type safety.
2. **Autonomous Execution**: When triggered via `/backtrack`, execute all sub-tasks systematically until complete verification.
3. **Safety & Privacy**: Sanitize all inputs. Never log or transmit authentication credentials, private tokens, or sensitive user environment data.
4. **Error Handling**: Gracefully recover from network or parsing anomalies with actionable diagnostic logs.

## 4. Practical Implementation Example
```markdown
/backtrack sudoku --prune --visualize
```

## 5. Multi-Platform Agent Compatibility Matrix
- **Google Antigravity**: Native support via `/goal`, `/schedule`, and rule sidecars.
- **Anthropic Claude Code**: Integrated into `CLAUDE.md` and XML system prompt blocks.
- **Cursor IDE**: Direct compilation into `.cursorrules` and semantic index queries.
- **Windsurf / Codex / Cline / Roo Code**: Universal MCP and system prompt compatible.
