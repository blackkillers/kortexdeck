---
name: omni-tool-480
description: "High-performance engineering directive #480 specialized for MCP & Integrations."
category: "MCP & Integrations"
platform: "claude"
type: "Prompt Template"
difficulty: "Expert"
tags: ["tool-480", "mcp & integrations", "claude", "command"]
---

# Engineering Directive #480

> **Platform**: `CLAUDE` | **Category**: `MCP & Integrations` | **Type**: `Prompt Template` | **Difficulty**: `Expert`

## 1. Executive Summary & Purpose
Detailed technical specification and execution prompt for solving advanced engineering challenges in MCP & Integrations.

## 2. Activation Syntax & Command Line
```bash
/tool-480 --target-env <dev|staging|prod> [--debug]
```

## 3. Core Behavioral Directives & Execution Protocol
1. **Context Initialization**: Prioritize zero-latency client-side execution, defensive boundaries, and strict type safety.
2. **Autonomous Execution**: When triggered via `/tool-480`, execute all sub-tasks systematically until complete verification.
3. **Safety & Privacy**: Sanitize all inputs. Never log or transmit authentication credentials, private tokens, or sensitive user environment data.
4. **Error Handling**: Gracefully recover from network or parsing anomalies with actionable diagnostic logs.

## 4. Practical Implementation Example
```markdown
/tool-480 --target-env prod --debug
```

## 5. Multi-Platform Agent Compatibility Matrix
- **Google Antigravity**: Native support via `/goal`, `/schedule`, and rule sidecars.
- **Anthropic Claude Code**: Integrated into `CLAUDE.md` and XML system prompt blocks.
- **Cursor IDE**: Direct compilation into `.cursorrules` and semantic index queries.
- **Windsurf / Codex / Cline / Roo Code**: Universal MCP and system prompt compatible.
