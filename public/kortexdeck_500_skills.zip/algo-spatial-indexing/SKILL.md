---
name: algo-spatial-indexing
description: "Hierarchical spatial partitioning for 2D/3D collision detection, geographic bounding-box queries, and k-Nearest Neighbors."
category: "Algorithmique"
platform: "universal"
type: "Algorithm"
difficulty: "Advanced"
tags: ["algorithms", "spatial-indexing", "quadtree", "geo", "r-tree"]
---

# Spatial Indexing (Quadtrees, R-Tree & Geohash)

> **Platform**: `UNIVERSAL` | **Category**: `Algorithmique` | **Type**: `Algorithm` | **Difficulty**: `Advanced`

## 1. Executive Summary & Purpose
Accelerates spatial range searches from $O(N)$ to $O(\log N)$. Implements dynamic Quadtrees, Hilbert curve spatial hashing, and R-Tree bounding polygon intersections.

## 2. Activation Syntax & Command Line
```bash
quadtree.insert({ x, y, data }); quadtree.queryRange(boundingBox);
```

## 3. Core Behavioral Directives & Execution Protocol
1. **Context Initialization**: Prioritize zero-latency client-side execution, defensive boundaries, and strict type safety.
2. **Autonomous Execution**: When triggered via `skill:algo-spatial-r-tree`, execute all sub-tasks systematically until complete verification.
3. **Safety & Privacy**: Sanitize all inputs. Never log or transmit authentication credentials, private tokens, or sensitive user environment data.
4. **Error Handling**: Gracefully recover from network or parsing anomalies with actionable diagnostic logs.

## 4. Practical Implementation Example
```markdown
Build a Quadtree index for 50,000 real-time moving delivery drivers and query all drivers within a 3km radius in under 2 milliseconds.
```

## 5. Multi-Platform Agent Compatibility Matrix
- **Google Antigravity**: Native support via `/goal`, `/schedule`, and rule sidecars.
- **Anthropic Claude Code**: Integrated into `CLAUDE.md` and XML system prompt blocks.
- **Cursor IDE**: Direct compilation into `.cursorrules` and semantic index queries.
- **Windsurf / Codex / Cline / Roo Code**: Universal MCP and system prompt compatible.
