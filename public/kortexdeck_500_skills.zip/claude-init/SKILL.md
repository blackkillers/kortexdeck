---
name: claude-init
description: "Scans the codebase to author a comprehensive CLAUDE.md file with build commands and standards."
category: "Architecture & System"
platform: "claude"
type: "Slash Command"
difficulty: "Beginner"
tags: ["init", "claude", "claude-code", "architecture & system", "cli"]
---

# Project CLAUDE.md Initialization

> **Platform**: `CLAUDE` | **Category**: `Architecture & System` | **Type**: `Slash Command` | **Difficulty**: `Beginner`

## 1. Executive Summary & Purpose
Official Anthropic Claude Code slash command for project claude.md initialization. Scans the codebase to author a comprehensive CLAUDE.md file with build commands and standards.

## 2. Activation Syntax & Command Line
```bash
/init [options] [arguments]
```

## 3. Core Behavioral Directives & Execution Protocol
1. **Context Initialization**: Prioritize zero-latency client-side execution, defensive boundaries, and strict type safety.
2. **Autonomous Execution**: When triggered via `/init`, execute all sub-tasks systematically until complete verification.
3. **Safety & Privacy**: Sanitize all inputs. Never log or transmit authentication credentials, private tokens, or sensitive user environment data.
4. **Error Handling**: Gracefully recover from network or parsing anomalies with actionable diagnostic logs.

## 4. Practical Implementation Example
```markdown
/init --help
```

## 5. Multi-Platform Agent Compatibility Matrix
- **Google Antigravity**: Native support via `/goal`, `/schedule`, and rule sidecars.
- **Anthropic Claude Code**: Integrated into `CLAUDE.md` and XML system prompt blocks.
- **Cursor IDE**: Direct compilation into `.cursorrules` and semantic index queries.
- **Windsurf / Codex / Cline / Roo Code**: Universal MCP and system prompt compatible.
