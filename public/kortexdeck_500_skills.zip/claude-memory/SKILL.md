---
name: claude-memory
description: "Views and manages saved facts, developer preferences, and rules stored in ~/.claude/memory."
category: "Workflow & Agents"
platform: "claude"
type: "Slash Command"
difficulty: "Intermediate"
tags: ["memory", "claude", "claude-code", "workflow & agents", "cli"]
---

# Persistent Memory Inspection

> **Platform**: `CLAUDE` | **Category**: `Workflow & Agents` | **Type**: `Slash Command` | **Difficulty**: `Intermediate`

## 1. Executive Summary & Purpose
Official Anthropic Claude Code slash command for persistent memory inspection. Views and manages saved facts, developer preferences, and rules stored in ~/.claude/memory.

## 2. Activation Syntax & Command Line
```bash
/memory [options] [arguments]
```

## 3. Core Behavioral Directives & Execution Protocol
1. **Context Initialization**: Prioritize zero-latency client-side execution, defensive boundaries, and strict type safety.
2. **Autonomous Execution**: When triggered via `/memory`, execute all sub-tasks systematically until complete verification.
3. **Safety & Privacy**: Sanitize all inputs. Never log or transmit authentication credentials, private tokens, or sensitive user environment data.
4. **Error Handling**: Gracefully recover from network or parsing anomalies with actionable diagnostic logs.

## 4. Practical Implementation Example
```markdown
/memory --help
```

## 5. Multi-Platform Agent Compatibility Matrix
- **Google Antigravity**: Native support via `/goal`, `/schedule`, and rule sidecars.
- **Anthropic Claude Code**: Integrated into `CLAUDE.md` and XML system prompt blocks.
- **Cursor IDE**: Direct compilation into `.cursorrules` and semantic index queries.
- **Windsurf / Codex / Cline / Roo Code**: Universal MCP and system prompt compatible.
