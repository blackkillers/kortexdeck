---
name: video-ffmpeg-matrix-pro
description: "Mastery of FFmpeg CLI filtergraphs, H.264/H.265/AV1 two-pass compression, audio normalization (EBU R128), and video concatenation."
category: "Video"
platform: "universal"
type: "Media Processing"
difficulty: "Advanced"
tags: ["video", "ffmpeg", "transcoding", "multimedia", "filtergraph"]
---

# FFmpeg Transcoder & Complex Filter Matrix

> **Platform**: `UNIVERSAL` | **Category**: `Video` | **Type**: `Media Processing` | **Difficulty**: `Advanced`

## 1. Executive Summary & Purpose
Constructs advanced video rendering pipelines. Programmatically generates subtitles, dynamic overlays, split-screen layouts, frame rate conversions, and lossless video slicing.

## 2. Activation Syntax & Command Line
```bash
ffmpeg -i input.mp4 -filter_complex '[0:v]scale=1920:1080,fps=60[v];[0:a]loudnorm=I=-16:TP=-1.5[a]' -map '[v]' -map '[a]' -c:v libx264 -crf 18 output.mp4
```

## 3. Core Behavioral Directives & Execution Protocol
1. **Context Initialization**: Prioritize zero-latency client-side execution, defensive boundaries, and strict type safety.
2. **Autonomous Execution**: When triggered via `skill:video-ffmpeg-pro`, execute all sub-tasks systematically until complete verification.
3. **Safety & Privacy**: Sanitize all inputs. Never log or transmit authentication credentials, private tokens, or sensitive user environment data.
4. **Error Handling**: Gracefully recover from network or parsing anomalies with actionable diagnostic logs.

## 4. Practical Implementation Example
```markdown
Combine a video stream with custom background music, auto-ducking during voiceovers, and burned-in animated subtitles using a single FFmpeg filtergraph.
```

## 5. Multi-Platform Agent Compatibility Matrix
- **Google Antigravity**: Native support via `/goal`, `/schedule`, and rule sidecars.
- **Anthropic Claude Code**: Integrated into `CLAUDE.md` and XML system prompt blocks.
- **Cursor IDE**: Direct compilation into `.cursorrules` and semantic index queries.
- **Windsurf / Codex / Cline / Roo Code**: Universal MCP and system prompt compatible.
