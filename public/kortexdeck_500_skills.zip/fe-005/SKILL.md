---
name: fe-005
description: "Create Zustand stores with persist, devtools, immer middleware"
category: "Frontend & UI"
platform: "Frontend"
type: "State"
difficulty: "Advanced"
tags: ["zustand", "state", "react", "store"]
---

# Zustand State Manager

> **Platform**: `FRONTEND` | **Category**: `Frontend & UI` | **Type**: `State` | **Difficulty**: `Advanced`

## 1. Executive Summary & Purpose
Build typed Zustand stores: slice pattern, immer for immutable updates, persist to localStorage/sessionStorage, Redux DevTools integration, and computed selectors

## 2. Activation Syntax & Command Line
```bash
/zustand-store [store-name] [--persist] [--devtools] [--immer]
```

## 3. Core Behavioral Directives & Execution Protocol
1. **Context Initialization**: Prioritize zero-latency client-side execution, defensive boundaries, and strict type safety.
2. **Autonomous Execution**: When triggered via `/zustand-store`, execute all sub-tasks systematically until complete verification.
3. **Safety & Privacy**: Sanitize all inputs. Never log or transmit authentication credentials, private tokens, or sensitive user environment data.
4. **Error Handling**: Gracefully recover from network or parsing anomalies with actionable diagnostic logs.

## 4. Practical Implementation Example
```markdown
/zustand-store userStore --persist --devtools --immer
```

## 5. Multi-Platform Agent Compatibility Matrix
- **Google Antigravity**: Native support via `/goal`, `/schedule`, and rule sidecars.
- **Anthropic Claude Code**: Integrated into `CLAUDE.md` and XML system prompt blocks.
- **Cursor IDE**: Direct compilation into `.cursorrules` and semantic index queries.
- **Windsurf / Codex / Cline / Roo Code**: Universal MCP and system prompt compatible.
