---
name: agy-gcp-managed-airflow-dag-authoring
description: "Designs idempotent TaskFlow DAGs, secret management, and sensor timeout guards."
category: "DevOps & Cloud"
platform: "antigravity"
type: "Skill"
difficulty: "Intermediate"
tags: ["gcp-managed-airflow-dag-authoring", "gcp-managed-airflow-dag-authoring", "devops & cloud", "antigravity", "skill"]
---

# Airflow 2 & 3 DAG Authoring

> **Platform**: `ANTIGRAVITY` | **Category**: `DevOps & Cloud` | **Type**: `Skill` | **Difficulty**: `Intermediate`

## 1. Executive Summary & Purpose
Applies the Airflow 2 & 3 DAG Authoring skill in Google Antigravity to solve domain-specific architectural challenges with verified best practices.

## 2. Activation Syntax & Command Line
```bash
use skill: gcp-managed-airflow-dag-authoring [--option <value>]
```

## 3. Core Behavioral Directives & Execution Protocol
1. **Context Initialization**: Prioritize zero-latency client-side execution, defensive boundaries, and strict type safety.
2. **Autonomous Execution**: When triggered via `gcp-managed-airflow-dag-authoring`, execute all sub-tasks systematically until complete verification.
3. **Safety & Privacy**: Sanitize all inputs. Never log or transmit authentication credentials, private tokens, or sensitive user environment data.
4. **Error Handling**: Gracefully recover from network or parsing anomalies with actionable diagnostic logs.

## 4. Practical Implementation Example
```markdown
use skill: gcp-managed-airflow-dag-authoring --target src/app --verbose
```

## 5. Multi-Platform Agent Compatibility Matrix
- **Google Antigravity**: Native support via `/goal`, `/schedule`, and rule sidecars.
- **Anthropic Claude Code**: Integrated into `CLAUDE.md` and XML system prompt blocks.
- **Cursor IDE**: Direct compilation into `.cursorrules` and semantic index queries.
- **Windsurf / Codex / Cline / Roo Code**: Universal MCP and system prompt compatible.
