---
name: bk-011
description: "Configure API Gateway with Kong/Traefik: routing, auth, rate limiting, logging"
category: "Backend & API"
platform: "Backend"
type: "Architecture"
difficulty: "Advanced"
tags: ["api-gateway", "kong", "traefik", "load-balancer"]
---

# API Gateway Config

> **Platform**: `BACKEND` | **Category**: `Backend & API` | **Type**: `Architecture` | **Difficulty**: `Advanced`

## 1. Executive Summary & Purpose
Set up API Gateway layer with service discovery, load balancing, authentication plugins, request/response transformation, circuit breaker, and canary routing

## 2. Activation Syntax & Command Line
```bash
/api-gateway [gateway] [--services] [--auth] [--lb round-robin]
```

## 3. Core Behavioral Directives & Execution Protocol
1. **Context Initialization**: Prioritize zero-latency client-side execution, defensive boundaries, and strict type safety.
2. **Autonomous Execution**: When triggered via `/api-gateway`, execute all sub-tasks systematically until complete verification.
3. **Safety & Privacy**: Sanitize all inputs. Never log or transmit authentication credentials, private tokens, or sensitive user environment data.
4. **Error Handling**: Gracefully recover from network or parsing anomalies with actionable diagnostic logs.

## 4. Practical Implementation Example
```markdown
/api-gateway kong --services user,order --auth jwt --lb round-robin
```

## 5. Multi-Platform Agent Compatibility Matrix
- **Google Antigravity**: Native support via `/goal`, `/schedule`, and rule sidecars.
- **Anthropic Claude Code**: Integrated into `CLAUDE.md` and XML system prompt blocks.
- **Cursor IDE**: Direct compilation into `.cursorrules` and semantic index queries.
- **Windsurf / Codex / Cline / Roo Code**: Universal MCP and system prompt compatible.
