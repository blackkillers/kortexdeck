---
name: claude-version
description: "Displays the current CLI version number, build timestamp, and git commit SHA."
category: "Workflow & Agents"
platform: "claude"
type: "Slash Command"
difficulty: "Beginner"
tags: ["version", "claude", "claude-code", "workflow & agents", "cli"]
---

# Version & Build Inspector

> **Platform**: `CLAUDE` | **Category**: `Workflow & Agents` | **Type**: `Slash Command` | **Difficulty**: `Beginner`

## 1. Executive Summary & Purpose
Official Anthropic Claude Code slash command for version & build inspector. Displays the current CLI version number, build timestamp, and git commit SHA.

## 2. Activation Syntax & Command Line
```bash
/version [options] [arguments]
```

## 3. Core Behavioral Directives & Execution Protocol
1. **Context Initialization**: Prioritize zero-latency client-side execution, defensive boundaries, and strict type safety.
2. **Autonomous Execution**: When triggered via `/version`, execute all sub-tasks systematically until complete verification.
3. **Safety & Privacy**: Sanitize all inputs. Never log or transmit authentication credentials, private tokens, or sensitive user environment data.
4. **Error Handling**: Gracefully recover from network or parsing anomalies with actionable diagnostic logs.

## 4. Practical Implementation Example
```markdown
/version --help
```

## 5. Multi-Platform Agent Compatibility Matrix
- **Google Antigravity**: Native support via `/goal`, `/schedule`, and rule sidecars.
- **Anthropic Claude Code**: Integrated into `CLAUDE.md` and XML system prompt blocks.
- **Cursor IDE**: Direct compilation into `.cursorrules` and semantic index queries.
- **Windsurf / Codex / Cline / Roo Code**: Universal MCP and system prompt compatible.
