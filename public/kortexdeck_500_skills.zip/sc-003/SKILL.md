---
name: sc-003
description: "Parse HTML/XML with BeautifulSoup4: CSS selectors, XPath, structured data extraction"
category: "Scraping"
platform: "Scraping"
type: "Parsing"
difficulty: "Advanced"
tags: ["beautifulsoup", "python", "html-parsing", "scraping"]
---

# BeautifulSoup Parser

> **Platform**: `SCRAPING` | **Category**: `Scraping` | **Type**: `Parsing` | **Difficulty**: `Advanced`

## 1. Executive Summary & Purpose
HTML parsing with BS4: CSS selectors, XPath queries, structured data (JSON-LD, microdata, OpenGraph), table extraction, pagination handling, and data normalization

## 2. Activation Syntax & Command Line
```bash
/bs4-parse [url] [--selector css|xpath] [--structured-data] [--paginate]
```

## 3. Core Behavioral Directives & Execution Protocol
1. **Context Initialization**: Prioritize zero-latency client-side execution, defensive boundaries, and strict type safety.
2. **Autonomous Execution**: When triggered via `/bs4-parse`, execute all sub-tasks systematically until complete verification.
3. **Safety & Privacy**: Sanitize all inputs. Never log or transmit authentication credentials, private tokens, or sensitive user environment data.
4. **Error Handling**: Gracefully recover from network or parsing anomalies with actionable diagnostic logs.

## 4. Practical Implementation Example
```markdown
/bs4-parse https://news.site --selector css --structured-data --paginate
```

## 5. Multi-Platform Agent Compatibility Matrix
- **Google Antigravity**: Native support via `/goal`, `/schedule`, and rule sidecars.
- **Anthropic Claude Code**: Integrated into `CLAUDE.md` and XML system prompt blocks.
- **Cursor IDE**: Direct compilation into `.cursorrules` and semantic index queries.
- **Windsurf / Codex / Cline / Roo Code**: Universal MCP and system prompt compatible.
