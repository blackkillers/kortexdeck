---
name: -cursorrules-a11y-wcag
description: "Mandates aria-label attributes, keyboard focus management, and 7:1 contrast ratios."
category: "Web & Frontend"
platform: "cursor"
type: "Rule / Prompt"
difficulty: "Intermediate"
tags: [".cursorrules-a11y-wcag", "cursorrules", "cursor", "best-practices"]
---

# WCAG AAA Web Accessibility Standard

> **Platform**: `CURSOR` | **Category**: `Web & Frontend` | **Type**: `Rule / Prompt` | **Difficulty**: `Intermediate`

## 1. Executive Summary & Purpose
.cursorrules governance file to automate team engineering standards: Mandates aria-label attributes, keyboard focus management, and 7:1 contrast ratios.

## 2. Activation Syntax & Command Line
```bash
// .cursorrules
.cursorrules:a11y-wcag
// Active directives in Cursor IDE
```

## 3. Core Behavioral Directives & Execution Protocol
1. **Context Initialization**: Prioritize zero-latency client-side execution, defensive boundaries, and strict type safety.
2. **Autonomous Execution**: When triggered via `.cursorrules:a11y-wcag`, execute all sub-tasks systematically until complete verification.
3. **Safety & Privacy**: Sanitize all inputs. Never log or transmit authentication credentials, private tokens, or sensitive user environment data.
4. **Error Handling**: Gracefully recover from network or parsing anomalies with actionable diagnostic logs.

## 4. Practical Implementation Example
```markdown
Build an authentication component strictly following the WCAG AAA Web Accessibility Standard specification.
```

## 5. Multi-Platform Agent Compatibility Matrix
- **Google Antigravity**: Native support via `/goal`, `/schedule`, and rule sidecars.
- **Anthropic Claude Code**: Integrated into `CLAUDE.md` and XML system prompt blocks.
- **Cursor IDE**: Direct compilation into `.cursorrules` and semantic index queries.
- **Windsurf / Codex / Cline / Roo Code**: Universal MCP and system prompt compatible.
