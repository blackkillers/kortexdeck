---
name: claude-rebase
description: "Guides conflict resolution step-by-step during interactive git rebase workflows."
category: "Code & Refactor"
platform: "claude"
type: "Slash Command"
difficulty: "Expert"
tags: ["rebase", "claude", "claude-code", "code & refactor", "cli"]
---

# Interactive Rebase Assistant

> **Platform**: `CLAUDE` | **Category**: `Code & Refactor` | **Type**: `Slash Command` | **Difficulty**: `Expert`

## 1. Executive Summary & Purpose
Official Anthropic Claude Code slash command for interactive rebase assistant. Guides conflict resolution step-by-step during interactive git rebase workflows.

## 2. Activation Syntax & Command Line
```bash
/rebase [options] [arguments]
```

## 3. Core Behavioral Directives & Execution Protocol
1. **Context Initialization**: Prioritize zero-latency client-side execution, defensive boundaries, and strict type safety.
2. **Autonomous Execution**: When triggered via `/rebase`, execute all sub-tasks systematically until complete verification.
3. **Safety & Privacy**: Sanitize all inputs. Never log or transmit authentication credentials, private tokens, or sensitive user environment data.
4. **Error Handling**: Gracefully recover from network or parsing anomalies with actionable diagnostic logs.

## 4. Practical Implementation Example
```markdown
/rebase --help
```

## 5. Multi-Platform Agent Compatibility Matrix
- **Google Antigravity**: Native support via `/goal`, `/schedule`, and rule sidecars.
- **Anthropic Claude Code**: Integrated into `CLAUDE.md` and XML system prompt blocks.
- **Cursor IDE**: Direct compilation into `.cursorrules` and semantic index queries.
- **Windsurf / Codex / Cline / Roo Code**: Universal MCP and system prompt compatible.
