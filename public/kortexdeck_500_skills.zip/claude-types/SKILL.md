---
name: claude-types
description: "Executes tsc --noEmit and resolves generic signature mismatches and missing types."
category: "Code & Refactor"
platform: "claude"
type: "Slash Command"
difficulty: "Intermediate"
tags: ["types", "claude", "claude-code", "code & refactor", "cli"]
---

# Strict TypeScript Type-Checker

> **Platform**: `CLAUDE` | **Category**: `Code & Refactor` | **Type**: `Slash Command` | **Difficulty**: `Intermediate`

## 1. Executive Summary & Purpose
Official Anthropic Claude Code slash command for strict typescript type-checker. Executes tsc --noEmit and resolves generic signature mismatches and missing types.

## 2. Activation Syntax & Command Line
```bash
/types [options] [arguments]
```

## 3. Core Behavioral Directives & Execution Protocol
1. **Context Initialization**: Prioritize zero-latency client-side execution, defensive boundaries, and strict type safety.
2. **Autonomous Execution**: When triggered via `/types`, execute all sub-tasks systematically until complete verification.
3. **Safety & Privacy**: Sanitize all inputs. Never log or transmit authentication credentials, private tokens, or sensitive user environment data.
4. **Error Handling**: Gracefully recover from network or parsing anomalies with actionable diagnostic logs.

## 4. Practical Implementation Example
```markdown
/types --help
```

## 5. Multi-Platform Agent Compatibility Matrix
- **Google Antigravity**: Native support via `/goal`, `/schedule`, and rule sidecars.
- **Anthropic Claude Code**: Integrated into `CLAUDE.md` and XML system prompt blocks.
- **Cursor IDE**: Direct compilation into `.cursorrules` and semantic index queries.
- **Windsurf / Codex / Cline / Roo Code**: Universal MCP and system prompt compatible.
