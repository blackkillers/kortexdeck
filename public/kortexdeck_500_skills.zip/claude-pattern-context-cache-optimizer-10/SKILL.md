---
name: claude-pattern-context-cache-optimizer-10
description: "Arranges immutable prompt prefixes to achieve a 90% cache hit rate and reduce latency."
category: "Architecture & System"
platform: "claude"
type: "Workflow"
difficulty: "Intermediate"
tags: ["context-cache-optimizer", "claude", "prompt-engineering", "anthropic"]
---

# Anthropic Context Cache Optimizer

> **Platform**: `CLAUDE` | **Category**: `Architecture & System` | **Type**: `Workflow` | **Difficulty**: `Intermediate`

## 1. Executive Summary & Purpose
Advanced Anthropic Claude prompt engineering pattern: Arranges immutable prompt prefixes to achieve a 90% cache hit rate and reduce latency. Optimized for Claude 3.7 Sonnet.

## 2. Activation Syntax & Command Line
```bash
<prompt_pattern name='context-cache-optimizer'>
  <context>...</context>
</prompt_pattern>
```

## 3. Core Behavioral Directives & Execution Protocol
1. **Context Initialization**: Prioritize zero-latency client-side execution, defensive boundaries, and strict type safety.
2. **Autonomous Execution**: When triggered via `prompt://claude/context-cache-optimizer-10`, execute all sub-tasks systematically until complete verification.
3. **Safety & Privacy**: Sanitize all inputs. Never log or transmit authentication credentials, private tokens, or sensitive user environment data.
4. **Error Handling**: Gracefully recover from network or parsing anomalies with actionable diagnostic logs.

## 4. Practical Implementation Example
```markdown
Apply the Anthropic Context Cache Optimizer pattern to architect a resilient payment service.
```

## 5. Multi-Platform Agent Compatibility Matrix
- **Google Antigravity**: Native support via `/goal`, `/schedule`, and rule sidecars.
- **Anthropic Claude Code**: Integrated into `CLAUDE.md` and XML system prompt blocks.
- **Cursor IDE**: Direct compilation into `.cursorrules` and semantic index queries.
- **Windsurf / Codex / Cline / Roo Code**: Universal MCP and system prompt compatible.
