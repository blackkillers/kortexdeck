---
name: mcp-server-github
description: "Manages GitHub issues, pull requests, automated reviews, and repository releases."
category: "DevOps & Cloud"
platform: "mcp"
type: "MCP Server"
difficulty: "Intermediate"
tags: ["github", "mcp", "server", "model-context-protocol", "devops & cloud"]
---

# MCP GitHub API Integration

> **Platform**: `MCP` | **Category**: `DevOps & Cloud` | **Type**: `MCP Server` | **Difficulty**: `Intermediate`

## 1. Executive Summary & Purpose
Official Model Context Protocol (MCP) server: MCP GitHub API Integration. Connects AI models directly to the github ecosystem.

## 2. Activation Syntax & Command Line
```bash
npx -y @modelcontextprotocol/server-github [options]
```

## 3. Core Behavioral Directives & Execution Protocol
1. **Context Initialization**: Prioritize zero-latency client-side execution, defensive boundaries, and strict type safety.
2. **Autonomous Execution**: When triggered via `mcp://github`, execute all sub-tasks systematically until complete verification.
3. **Safety & Privacy**: Sanitize all inputs. Never log or transmit authentication credentials, private tokens, or sensitive user environment data.
4. **Error Handling**: Gracefully recover from network or parsing anomalies with actionable diagnostic logs.

## 4. Practical Implementation Example
```markdown
npx -y @modelcontextprotocol/server-github --port 3000
```

## 5. Multi-Platform Agent Compatibility Matrix
- **Google Antigravity**: Native support via `/goal`, `/schedule`, and rule sidecars.
- **Anthropic Claude Code**: Integrated into `CLAUDE.md` and XML system prompt blocks.
- **Cursor IDE**: Direct compilation into `.cursorrules` and semantic index queries.
- **Windsurf / Codex / Cline / Roo Code**: Universal MCP and system prompt compatible.
