---
name: codex-cursor-rule-54
description: "Codex code optimization and architectural governance directive #54."
category: "Code & Refactor"
platform: "codex"
type: "Rule / Prompt"
difficulty: "Intermediate"
tags: ["codex", "cursor", "rule", "rule-54"]
---

# Codex Engineering Directive #54

> **Platform**: `CODEX` | **Category**: `Code & Refactor` | **Type**: `Rule / Prompt` | **Difficulty**: `Intermediate`

## 1. Executive Summary & Purpose
Advanced engineering directive for OpenAI Codex and Cursor ensuring architectural alignment and code resilience.

## 2. Activation Syntax & Command Line
```bash
/codex-rule-54 --strict
```

## 3. Core Behavioral Directives & Execution Protocol
1. **Context Initialization**: Prioritize zero-latency client-side execution, defensive boundaries, and strict type safety.
2. **Autonomous Execution**: When triggered via `/codex-rule-54`, execute all sub-tasks systematically until complete verification.
3. **Safety & Privacy**: Sanitize all inputs. Never log or transmit authentication credentials, private tokens, or sensitive user environment data.
4. **Error Handling**: Gracefully recover from network or parsing anomalies with actionable diagnostic logs.

## 4. Practical Implementation Example
```markdown
/codex-rule-54 Apply this design pattern across all data ingestion workers.
```

## 5. Multi-Platform Agent Compatibility Matrix
- **Google Antigravity**: Native support via `/goal`, `/schedule`, and rule sidecars.
- **Anthropic Claude Code**: Integrated into `CLAUDE.md` and XML system prompt blocks.
- **Cursor IDE**: Direct compilation into `.cursorrules` and semantic index queries.
- **Windsurf / Codex / Cline / Roo Code**: Universal MCP and system prompt compatible.
