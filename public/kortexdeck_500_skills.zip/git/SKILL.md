---
name: git
description: "Inspects recent commits, active branch, and working tree diffs."
category: "Code & Refactor"
platform: "cursor"
type: "Extension"
difficulty: "Beginner"
tags: ["cursor", "git", "diff", "history", "version-control"]
---

# Git History & Diff Context (@git)

> **Platform**: `CURSOR` | **Category**: `Code & Refactor` | **Type**: `Extension` | **Difficulty**: `Beginner`

## 1. Executive Summary & Purpose
Provides context on recent edits to help debug regressions or generate accurate PR descriptions.

## 2. Activation Syntax & Command Line
```bash
@git <diff|log|branch>
```

## 3. Core Behavioral Directives & Execution Protocol
1. **Context Initialization**: Prioritize zero-latency client-side execution, defensive boundaries, and strict type safety.
2. **Autonomous Execution**: When triggered via `@git`, execute all sub-tasks systematically until complete verification.
3. **Safety & Privacy**: Sanitize all inputs. Never log or transmit authentication credentials, private tokens, or sensitive user environment data.
4. **Error Handling**: Gracefully recover from network or parsing anomalies with actionable diagnostic logs.

## 4. Practical Implementation Example
```markdown
@git diff Summarize the architectural impact of these changes on the public API.
```

## 5. Multi-Platform Agent Compatibility Matrix
- **Google Antigravity**: Native support via `/goal`, `/schedule`, and rule sidecars.
- **Anthropic Claude Code**: Integrated into `CLAUDE.md` and XML system prompt blocks.
- **Cursor IDE**: Direct compilation into `.cursorrules` and semantic index queries.
- **Windsurf / Codex / Cline / Roo Code**: Universal MCP and system prompt compatible.
