---
name: scraping-playwright-stealth
description: "Headless browser automation bypassing Cloudflare Turnstile, browser fingerprinting, and behavioral bot detection."
category: "Scraping"
platform: "universal"
type: "Web Automation"
difficulty: "Advanced"
tags: ["scraping", "playwright", "puppeteer", "stealth", "automation"]
---

# Playwright & Puppeteer Stealth Scraper Pro

> **Platform**: `UNIVERSAL` | **Category**: `Scraping` | **Type**: `Web Automation` | **Difficulty**: `Advanced`

## 1. Executive Summary & Purpose
Constructs undetectable web scrapers. Injects randomized mouse Bézier curves, realistic typing cadences, WebGL/Canvas noise spoofing, and rotating residential proxy pools.

## 2. Activation Syntax & Command Line
```bash
const browser = await playwright.chromium.launch({ args: ['--disable-blink-features=AutomationControlled'] });
```

## 3. Core Behavioral Directives & Execution Protocol
1. **Context Initialization**: Prioritize zero-latency client-side execution, defensive boundaries, and strict type safety.
2. **Autonomous Execution**: When triggered via `skill:scraping-stealth`, execute all sub-tasks systematically until complete verification.
3. **Safety & Privacy**: Sanitize all inputs. Never log or transmit authentication credentials, private tokens, or sensitive user environment data.
4. **Error Handling**: Gracefully recover from network or parsing anomalies with actionable diagnostic logs.

## 4. Practical Implementation Example
```markdown
Scrape dynamically rendered single-page application data with automated infinite scroll, custom wait-for-selector guards, and CAPTCHA evasion.
```

## 5. Multi-Platform Agent Compatibility Matrix
- **Google Antigravity**: Native support via `/goal`, `/schedule`, and rule sidecars.
- **Anthropic Claude Code**: Integrated into `CLAUDE.md` and XML system prompt blocks.
- **Cursor IDE**: Direct compilation into `.cursorrules` and semantic index queries.
- **Windsurf / Codex / Cline / Roo Code**: Universal MCP and system prompt compatible.
