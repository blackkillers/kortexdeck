---
name: web
description: "Searches live web documentation and package registries for current releases."
category: "Web & Frontend"
platform: "cursor"
type: "Extension"
difficulty: "Beginner"
tags: ["cursor", "web", "docs", "latest", "google"]
---

# Live Web Search (@web)

> **Platform**: `CURSOR` | **Category**: `Web & Frontend` | **Type**: `Extension` | **Difficulty**: `Beginner`

## 1. Executive Summary & Purpose
Executes real-time searches to resolve recent bugs, check newly released framework APIs, or verify breaking changes.

## 2. Activation Syntax & Command Line
```bash
@web <technical_search_query>
```

## 3. Core Behavioral Directives & Execution Protocol
1. **Context Initialization**: Prioritize zero-latency client-side execution, defensive boundaries, and strict type safety.
2. **Autonomous Execution**: When triggered via `@web`, execute all sub-tasks systematically until complete verification.
3. **Safety & Privacy**: Sanitize all inputs. Never log or transmit authentication credentials, private tokens, or sensitive user environment data.
4. **Error Handling**: Gracefully recover from network or parsing anomalies with actionable diagnostic logs.

## 4. Practical Implementation Example
```markdown
@web What are the breaking changes between Next.js 14 and 15 regarding fetch() caching?
```

## 5. Multi-Platform Agent Compatibility Matrix
- **Google Antigravity**: Native support via `/goal`, `/schedule`, and rule sidecars.
- **Anthropic Claude Code**: Integrated into `CLAUDE.md` and XML system prompt blocks.
- **Cursor IDE**: Direct compilation into `.cursorrules` and semantic index queries.
- **Windsurf / Codex / Cline / Roo Code**: Universal MCP and system prompt compatible.
