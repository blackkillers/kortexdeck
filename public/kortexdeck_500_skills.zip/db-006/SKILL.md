---
name: db-006
description: "Master SQL window functions: ROW_NUMBER, RANK, LAG/LEAD, running totals"
category: "Database"
platform: "Database"
type: "Analytics"
difficulty: "Advanced"
tags: ["sql", "window-functions", "analytics", "postgresql"]
---

# SQL Window Functions

> **Platform**: `DATABASE` | **Category**: `Database` | **Type**: `Analytics` | **Difficulty**: `Advanced`

## 1. Executive Summary & Purpose
Advanced window functions: ROW_NUMBER, RANK, DENSE_RANK, NTILE, LAG/LEAD for time series, running totals with SUM OVER, moving averages, and frame specification

## 2. Activation Syntax & Command Line
```bash
/sql-window [function] [--partition-by] [--order-by] [--frame rows|range]
```

## 3. Core Behavioral Directives & Execution Protocol
1. **Context Initialization**: Prioritize zero-latency client-side execution, defensive boundaries, and strict type safety.
2. **Autonomous Execution**: When triggered via `/sql-window`, execute all sub-tasks systematically until complete verification.
3. **Safety & Privacy**: Sanitize all inputs. Never log or transmit authentication credentials, private tokens, or sensitive user environment data.
4. **Error Handling**: Gracefully recover from network or parsing anomalies with actionable diagnostic logs.

## 4. Practical Implementation Example
```markdown
/sql-window rank --partition-by department --order-by salary DESC
```

## 5. Multi-Platform Agent Compatibility Matrix
- **Google Antigravity**: Native support via `/goal`, `/schedule`, and rule sidecars.
- **Anthropic Claude Code**: Integrated into `CLAUDE.md` and XML system prompt blocks.
- **Cursor IDE**: Direct compilation into `.cursorrules` and semantic index queries.
- **Windsurf / Codex / Cline / Roo Code**: Universal MCP and system prompt compatible.
