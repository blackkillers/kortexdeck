---
name: nd-001
description: "Generate brandable domain names: portmanteau, keyword combinations, CVCV patterns"
category: "Name & Domain"
platform: "Domain"
type: "Branding"
difficulty: "Advanced"
tags: ["domain", "naming", "branding", "startup", "tld"]
---

# Domain Name Generator

> **Platform**: `DOMAIN` | **Category**: `Name & Domain` | **Type**: `Branding` | **Difficulty**: `Advanced`

## 1. Executive Summary & Purpose
Domain name generation: keyword analysis, portmanteau synthesis, CVCV (pronounceable) patterns, .com/.io/.dev/.ai availability check, Levenshtein similarity, and trademark proximity

## 2. Activation Syntax & Command Line
```bash
/domain-gen [keywords] [--tld com|io|dev|ai] [--style portmanteau|descriptive|abstract] [--check]
```

## 3. Core Behavioral Directives & Execution Protocol
1. **Context Initialization**: Prioritize zero-latency client-side execution, defensive boundaries, and strict type safety.
2. **Autonomous Execution**: When triggered via `/domain-gen`, execute all sub-tasks systematically until complete verification.
3. **Safety & Privacy**: Sanitize all inputs. Never log or transmit authentication credentials, private tokens, or sensitive user environment data.
4. **Error Handling**: Gracefully recover from network or parsing anomalies with actionable diagnostic logs.

## 4. Practical Implementation Example
```markdown
/domain-gen ai automation tools --tld io,dev,ai --style portmanteau --check
```

## 5. Multi-Platform Agent Compatibility Matrix
- **Google Antigravity**: Native support via `/goal`, `/schedule`, and rule sidecars.
- **Anthropic Claude Code**: Integrated into `CLAUDE.md` and XML system prompt blocks.
- **Cursor IDE**: Direct compilation into `.cursorrules` and semantic index queries.
- **Windsurf / Codex / Cline / Roo Code**: Universal MCP and system prompt compatible.
