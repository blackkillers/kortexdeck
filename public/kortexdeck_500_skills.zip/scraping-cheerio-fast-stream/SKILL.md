---
name: scraping-cheerio-fast-stream
description: "Ultra-fast, low-memory server-side DOM parsing and structured microdata (JSON-LD / OpenGraph) extraction."
category: "Scraping"
platform: "universal"
type: "Data Extraction"
difficulty: "Intermediate"
tags: ["scraping", "cheerio", "html-parser", "fast-extract", "json-ld"]
---

# Cheerio & Streaming HTML Extractor

> **Platform**: `UNIVERSAL` | **Category**: `Scraping` | **Type**: `Data Extraction` | **Difficulty**: `Intermediate`

## 1. Executive Summary & Purpose
Parses megabytes of raw HTML in single-digit milliseconds. Extracts product schemas, canonical URLs, meta tags, and tabular data using jQuery-like CSS selectors without spawning browser instances.

## 2. Activation Syntax & Command Line
```bash
const $ = cheerio.load(htmlChunk); const data = $('script[type="application/ld+json"]').text();
```

## 3. Core Behavioral Directives & Execution Protocol
1. **Context Initialization**: Prioritize zero-latency client-side execution, defensive boundaries, and strict type safety.
2. **Autonomous Execution**: When triggered via `skill:scraping-cheerio`, execute all sub-tasks systematically until complete verification.
3. **Safety & Privacy**: Sanitize all inputs. Never log or transmit authentication credentials, private tokens, or sensitive user environment data.
4. **Error Handling**: Gracefully recover from network or parsing anomalies with actionable diagnostic logs.

## 4. Practical Implementation Example
```markdown
Download and extract structured product details, price variants, and high-res image URLs from 500 static e-commerce pages in 2 seconds.
```

## 5. Multi-Platform Agent Compatibility Matrix
- **Google Antigravity**: Native support via `/goal`, `/schedule`, and rule sidecars.
- **Anthropic Claude Code**: Integrated into `CLAUDE.md` and XML system prompt blocks.
- **Cursor IDE**: Direct compilation into `.cursorrules` and semantic index queries.
- **Windsurf / Codex / Cline / Roo Code**: Universal MCP and system prompt compatible.
