---
name: fw-002
description: "Generate Spring Boot 3 microservices: REST, JPA, Security, Actuator, Docker"
category: "Framework"
platform: "Framework"
type: "Backend"
difficulty: "Advanced"
tags: ["spring-boot", "java", "microservice", "jpa", "security"]
---

# Spring Boot Microservice

> **Platform**: `FRAMEWORK` | **Category**: `Framework` | **Type**: `Backend` | **Difficulty**: `Advanced`

## 1. Executive Summary & Purpose
Spring Boot 3 scaffold: REST controllers, Spring Data JPA with Liquibase, Spring Security OAuth2, Actuator health/metrics, MapStruct DTOs, and Docker Compose dev setup

## 2. Activation Syntax & Command Line
```bash
/spring-boot [service] [--db postgres|mysql] [--security oauth2|jwt] [--actuator]
```

## 3. Core Behavioral Directives & Execution Protocol
1. **Context Initialization**: Prioritize zero-latency client-side execution, defensive boundaries, and strict type safety.
2. **Autonomous Execution**: When triggered via `/spring-boot`, execute all sub-tasks systematically until complete verification.
3. **Safety & Privacy**: Sanitize all inputs. Never log or transmit authentication credentials, private tokens, or sensitive user environment data.
4. **Error Handling**: Gracefully recover from network or parsing anomalies with actionable diagnostic logs.

## 4. Practical Implementation Example
```markdown
/spring-boot user-service --db postgres --security jwt --actuator
```

## 5. Multi-Platform Agent Compatibility Matrix
- **Google Antigravity**: Native support via `/goal`, `/schedule`, and rule sidecars.
- **Anthropic Claude Code**: Integrated into `CLAUDE.md` and XML system prompt blocks.
- **Cursor IDE**: Direct compilation into `.cursorrules` and semantic index queries.
- **Windsurf / Codex / Cline / Roo Code**: Universal MCP and system prompt compatible.
