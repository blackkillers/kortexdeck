---
name: namedomain-whois-dns-auditor
description: "Comprehensive DNS configuration verification: A/AAAA, CNAME, MX, SPF, DKIM, DMARC, and CAA SSL records."
category: "Name & Domain"
platform: "universal"
type: "Infrastructure Audit"
difficulty: "Intermediate"
tags: ["domain", "dns", "whois", "security", "dmarc", "spf"]
---

# WHOIS, DNS & Email Security Record Auditor

> **Platform**: `UNIVERSAL` | **Category**: `Name & Domain` | **Type**: `Infrastructure Audit` | **Difficulty**: `Intermediate`

## 1. Executive Summary & Purpose
Inspects domain DNS propagation and email security posture. Detects subdomain takeover vulnerabilities, dangling CNAMEs, missing SPF/DMARC policies, and DNSSEC validation errors.

## 2. Activation Syntax & Command Line
```bash
/dns-audit check --domain=example.com --email-sec --takeover-scan
```

## 3. Core Behavioral Directives & Execution Protocol
1. **Context Initialization**: Prioritize zero-latency client-side execution, defensive boundaries, and strict type safety.
2. **Autonomous Execution**: When triggered via `skill:namedomain-dns-auditor`, execute all sub-tasks systematically until complete verification.
3. **Safety & Privacy**: Sanitize all inputs. Never log or transmit authentication credentials, private tokens, or sensitive user environment data.
4. **Error Handling**: Gracefully recover from network or parsing anomalies with actionable diagnostic logs.

## 4. Practical Implementation Example
```markdown
Audit the DNS records for cohenwebstudio.com, verifying valid SPF, DKIM, and DMARC enforcement policies and fast TTL propagation.
```

## 5. Multi-Platform Agent Compatibility Matrix
- **Google Antigravity**: Native support via `/goal`, `/schedule`, and rule sidecars.
- **Anthropic Claude Code**: Integrated into `CLAUDE.md` and XML system prompt blocks.
- **Cursor IDE**: Direct compilation into `.cursorrules` and semantic index queries.
- **Windsurf / Codex / Cline / Roo Code**: Universal MCP and system prompt compatible.
