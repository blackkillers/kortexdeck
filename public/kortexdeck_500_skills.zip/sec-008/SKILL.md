---
name: sec-008
description: "Audit npm/pip/maven dependencies for known CVEs and supply chain risks"
category: "Security"
platform: "Security"
type: "Scanning"
difficulty: "Advanced"
tags: ["dependencies", "cve", "security", "supply-chain", "npm"]
---

# Dependency Vulnerability Audit

> **Platform**: `SECURITY` | **Category**: `Security` | **Type**: `Scanning` | **Difficulty**: `Advanced`

## 1. Executive Summary & Purpose
Dependency security: npm audit, pip-audit, Dependabot config, Supply chain attack detection, license compliance, and automated PR creation for patches

## 2. Activation Syntax & Command Line
```bash
/dep-audit [ecosystem] [--fix] [--dependabot] [--license-check]
```

## 3. Core Behavioral Directives & Execution Protocol
1. **Context Initialization**: Prioritize zero-latency client-side execution, defensive boundaries, and strict type safety.
2. **Autonomous Execution**: When triggered via `/dep-audit`, execute all sub-tasks systematically until complete verification.
3. **Safety & Privacy**: Sanitize all inputs. Never log or transmit authentication credentials, private tokens, or sensitive user environment data.
4. **Error Handling**: Gracefully recover from network or parsing anomalies with actionable diagnostic logs.

## 4. Practical Implementation Example
```markdown
/dep-audit npm --fix --dependabot --license-check
```

## 5. Multi-Platform Agent Compatibility Matrix
- **Google Antigravity**: Native support via `/goal`, `/schedule`, and rule sidecars.
- **Anthropic Claude Code**: Integrated into `CLAUDE.md` and XML system prompt blocks.
- **Cursor IDE**: Direct compilation into `.cursorrules` and semantic index queries.
- **Windsurf / Codex / Cline / Roo Code**: Universal MCP and system prompt compatible.
