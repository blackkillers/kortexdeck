---
name: db-clickhouse-olap-titan
description: "Sub-second analytical queries over billions of event rows using columnar storage, partitioning keys, and Materialized Views."
category: "Database"
platform: "universal"
type: "OLAP Analytics"
difficulty: "Expert"
tags: ["database", "clickhouse", "olap", "big-data", "analytics"]
---

# ClickHouse Realtime Analytics & MergeTree Engine

> **Platform**: `UNIVERSAL` | **Category**: `Database` | **Type**: `OLAP Analytics` | **Difficulty**: `Expert`

## 1. Executive Summary & Purpose
Designs high-throughput analytics pipelines. Configures ReplacingMergeTree and AggregatingMergeTree engines, data skip indexes, and real-time Kafka engine ingestion tables.

## 2. Activation Syntax & Command Line
```bash
ENGINE = ReplacingMergeTree(version) PARTITION BY toYYYYMM(event_date) ORDER BY (tenant_id, event_type, event_time)
```

## 3. Core Behavioral Directives & Execution Protocol
1. **Context Initialization**: Prioritize zero-latency client-side execution, defensive boundaries, and strict type safety.
2. **Autonomous Execution**: When triggered via `skill:db-clickhouse-titan`, execute all sub-tasks systematically until complete verification.
3. **Safety & Privacy**: Sanitize all inputs. Never log or transmit authentication credentials, private tokens, or sensitive user environment data.
4. **Error Handling**: Gracefully recover from network or parsing anomalies with actionable diagnostic logs.

## 4. Practical Implementation Example
```markdown
Create a ClickHouse analytics schema with a Materialized View calculating 5-minute rolling averages across 500 million clickstream events.
```

## 5. Multi-Platform Agent Compatibility Matrix
- **Google Antigravity**: Native support via `/goal`, `/schedule`, and rule sidecars.
- **Anthropic Claude Code**: Integrated into `CLAUDE.md` and XML system prompt blocks.
- **Cursor IDE**: Direct compilation into `.cursorrules` and semantic index queries.
- **Windsurf / Codex / Cline / Roo Code**: Universal MCP and system prompt compatible.
