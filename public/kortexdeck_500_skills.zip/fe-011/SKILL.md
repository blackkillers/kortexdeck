---
name: fe-011
description: "Build interactive data visualizations with Recharts or Chart.js"
category: "Frontend & UI"
platform: "Frontend"
type: "Visualization"
difficulty: "Advanced"
tags: ["recharts", "charts", "d3", "visualization"]
---

# Chart Dashboard

> **Platform**: `FRONTEND` | **Category**: `Frontend & UI` | **Type**: `Visualization` | **Difficulty**: `Advanced`

## 1. Executive Summary & Purpose
Create responsive charts: line, bar, pie, area, scatter, heatmap with Recharts or Chart.js, real-time updates, zoom/pan, and accessible data tables

## 2. Activation Syntax & Command Line
```bash
/charts [type] [--library recharts|chartjs|d3] [--realtime] [--responsive]
```

## 3. Core Behavioral Directives & Execution Protocol
1. **Context Initialization**: Prioritize zero-latency client-side execution, defensive boundaries, and strict type safety.
2. **Autonomous Execution**: When triggered via `/charts`, execute all sub-tasks systematically until complete verification.
3. **Safety & Privacy**: Sanitize all inputs. Never log or transmit authentication credentials, private tokens, or sensitive user environment data.
4. **Error Handling**: Gracefully recover from network or parsing anomalies with actionable diagnostic logs.

## 4. Practical Implementation Example
```markdown
/charts dashboard --library recharts --realtime --responsive
```

## 5. Multi-Platform Agent Compatibility Matrix
- **Google Antigravity**: Native support via `/goal`, `/schedule`, and rule sidecars.
- **Anthropic Claude Code**: Integrated into `CLAUDE.md` and XML system prompt blocks.
- **Cursor IDE**: Direct compilation into `.cursorrules` and semantic index queries.
- **Windsurf / Codex / Cline / Roo Code**: Universal MCP and system prompt compatible.
