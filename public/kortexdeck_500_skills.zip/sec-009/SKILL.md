---
name: sec-009
description: "Design Zero Trust network: mTLS, service mesh, BeyondCorp access policies"
category: "Security"
platform: "Security"
type: "Architecture"
difficulty: "Advanced"
tags: ["zero-trust", "mtls", "service-mesh", "istio", "security"]
---

# Zero Trust Access Policy

> **Platform**: `SECURITY` | **Category**: `Security` | **Type**: `Architecture` | **Difficulty**: `Advanced`

## 1. Executive Summary & Purpose
Implement Zero Trust: mutual TLS between services, service mesh (Istio/Linkerd), BeyondCorp model, short-lived certificates, SPIFFE/SPIRE identity, and policy as code

## 2. Activation Syntax & Command Line
```bash
/zero-trust [component] [--mesh istio|linkerd] [--mtls] [--spiffe]
```

## 3. Core Behavioral Directives & Execution Protocol
1. **Context Initialization**: Prioritize zero-latency client-side execution, defensive boundaries, and strict type safety.
2. **Autonomous Execution**: When triggered via `/zero-trust`, execute all sub-tasks systematically until complete verification.
3. **Safety & Privacy**: Sanitize all inputs. Never log or transmit authentication credentials, private tokens, or sensitive user environment data.
4. **Error Handling**: Gracefully recover from network or parsing anomalies with actionable diagnostic logs.

## 4. Practical Implementation Example
```markdown
/zero-trust api-service --mesh istio --mtls --spiffe
```

## 5. Multi-Platform Agent Compatibility Matrix
- **Google Antigravity**: Native support via `/goal`, `/schedule`, and rule sidecars.
- **Anthropic Claude Code**: Integrated into `CLAUDE.md` and XML system prompt blocks.
- **Cursor IDE**: Direct compilation into `.cursorrules` and semantic index queries.
- **Windsurf / Codex / Cline / Roo Code**: Universal MCP and system prompt compatible.
