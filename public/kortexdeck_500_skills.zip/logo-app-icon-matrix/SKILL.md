---
name: logo-app-icon-matrix
description: "Automated generation of web manifest icons, Apple touch icons (180x180), Android adaptive icons, and multi-resolution .ico files."
category: "Logo & Branding"
platform: "universal"
type: "Asset Generation"
difficulty: "Beginner"
tags: ["logo", "favicon", "app-icon", "pwa", "branding"]
---

# Favicon & App Icon Multi-Format Generator

> **Platform**: `UNIVERSAL` | **Category**: `Logo & Branding` | **Type**: `Asset Generation` | **Difficulty**: `Beginner`

## 1. Executive Summary & Purpose
Transforms a single source SVG into a complete web and mobile icon asset package. Generates site.webmanifest, browserconfig.xml, and HTML link tags with pixel-perfect rounding.

## 2. Activation Syntax & Command Line
```bash
/icon-matrix generate --source=logo.svg --output=public/
```

## 3. Core Behavioral Directives & Execution Protocol
1. **Context Initialization**: Prioritize zero-latency client-side execution, defensive boundaries, and strict type safety.
2. **Autonomous Execution**: When triggered via `skill:logo-app-icon-matrix`, execute all sub-tasks systematically until complete verification.
3. **Safety & Privacy**: Sanitize all inputs. Never log or transmit authentication credentials, private tokens, or sensitive user environment data.
4. **Error Handling**: Gracefully recover from network or parsing anomalies with actionable diagnostic logs.

## 4. Practical Implementation Example
```markdown
Generate all standard icon sizes (16x16, 32x32, 180x180, 192x192, 512x512) and update index.html meta tags automatically.
```

## 5. Multi-Platform Agent Compatibility Matrix
- **Google Antigravity**: Native support via `/goal`, `/schedule`, and rule sidecars.
- **Anthropic Claude Code**: Integrated into `CLAUDE.md` and XML system prompt blocks.
- **Cursor IDE**: Direct compilation into `.cursorrules` and semantic index queries.
- **Windsurf / Codex / Cline / Roo Code**: Universal MCP and system prompt compatible.
