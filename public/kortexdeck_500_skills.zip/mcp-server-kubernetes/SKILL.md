---
name: mcp-server-kubernetes
description: "Deploys pods, inspects namespaces, manages ingresses, and checks k8s logs."
category: "DevOps & Cloud"
platform: "mcp"
type: "MCP Server"
difficulty: "Expert"
tags: ["kubernetes", "mcp", "server", "model-context-protocol", "devops & cloud"]
---

# MCP Kubernetes Cluster Control

> **Platform**: `MCP` | **Category**: `DevOps & Cloud` | **Type**: `MCP Server` | **Difficulty**: `Expert`

## 1. Executive Summary & Purpose
Official Model Context Protocol (MCP) server: MCP Kubernetes Cluster Control. Connects AI models directly to the kubernetes ecosystem.

## 2. Activation Syntax & Command Line
```bash
npx -y @modelcontextprotocol/server-kubernetes [options]
```

## 3. Core Behavioral Directives & Execution Protocol
1. **Context Initialization**: Prioritize zero-latency client-side execution, defensive boundaries, and strict type safety.
2. **Autonomous Execution**: When triggered via `mcp://kubernetes`, execute all sub-tasks systematically until complete verification.
3. **Safety & Privacy**: Sanitize all inputs. Never log or transmit authentication credentials, private tokens, or sensitive user environment data.
4. **Error Handling**: Gracefully recover from network or parsing anomalies with actionable diagnostic logs.

## 4. Practical Implementation Example
```markdown
npx -y @modelcontextprotocol/server-kubernetes --port 3000
```

## 5. Multi-Platform Agent Compatibility Matrix
- **Google Antigravity**: Native support via `/goal`, `/schedule`, and rule sidecars.
- **Anthropic Claude Code**: Integrated into `CLAUDE.md` and XML system prompt blocks.
- **Cursor IDE**: Direct compilation into `.cursorrules` and semantic index queries.
- **Windsurf / Codex / Cline / Roo Code**: Universal MCP and system prompt compatible.
