---
name: arch-001
description: "Design event-driven systems: event sourcing, CQRS, saga pattern, outbox"
category: "Architecture"
platform: "Architecture"
type: "Pattern"
difficulty: "Advanced"
tags: ["event-sourcing", "cqrs", "saga", "kafka", "architecture"]
---

# Event-Driven Architecture

> **Platform**: `ARCHITECTURE` | **Category**: `Architecture` | **Type**: `Pattern` | **Difficulty**: `Advanced`

## 1. Executive Summary & Purpose
Event-driven architecture: event sourcing with event store, CQRS read/write model separation, saga pattern for distributed transactions, transactional outbox, and event versioning

## 2. Activation Syntax & Command Line
```bash
/event-driven [pattern] [--broker kafka|rabbitmq] [--cqrs] [--saga]
```

## 3. Core Behavioral Directives & Execution Protocol
1. **Context Initialization**: Prioritize zero-latency client-side execution, defensive boundaries, and strict type safety.
2. **Autonomous Execution**: When triggered via `/event-driven`, execute all sub-tasks systematically until complete verification.
3. **Safety & Privacy**: Sanitize all inputs. Never log or transmit authentication credentials, private tokens, or sensitive user environment data.
4. **Error Handling**: Gracefully recover from network or parsing anomalies with actionable diagnostic logs.

## 4. Practical Implementation Example
```markdown
/event-driven order-system --broker kafka --cqrs --saga
```

## 5. Multi-Platform Agent Compatibility Matrix
- **Google Antigravity**: Native support via `/goal`, `/schedule`, and rule sidecars.
- **Anthropic Claude Code**: Integrated into `CLAUDE.md` and XML system prompt blocks.
- **Cursor IDE**: Direct compilation into `.cursorrules` and semantic index queries.
- **Windsurf / Codex / Cline / Roo Code**: Universal MCP and system prompt compatible.
