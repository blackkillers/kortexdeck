---
name: agy-dart-fix-runtime-errors
description: "Fetches stack traces, pinpoints failing code lines, and applies hot-reload fixes."
category: "Debugging & Tests"
platform: "antigravity"
type: "Skill"
difficulty: "Intermediate"
tags: ["dart-fix-runtime-errors", "dart-fix-runtime-errors", "debugging & tests", "antigravity", "skill"]
---

# Dart Runtime Error Resolver

> **Platform**: `ANTIGRAVITY` | **Category**: `Debugging & Tests` | **Type**: `Skill` | **Difficulty**: `Intermediate`

## 1. Executive Summary & Purpose
Applies the Dart Runtime Error Resolver skill in Google Antigravity to solve domain-specific architectural challenges with verified best practices.

## 2. Activation Syntax & Command Line
```bash
use skill: dart-fix-runtime-errors [--option <value>]
```

## 3. Core Behavioral Directives & Execution Protocol
1. **Context Initialization**: Prioritize zero-latency client-side execution, defensive boundaries, and strict type safety.
2. **Autonomous Execution**: When triggered via `dart-fix-runtime-errors`, execute all sub-tasks systematically until complete verification.
3. **Safety & Privacy**: Sanitize all inputs. Never log or transmit authentication credentials, private tokens, or sensitive user environment data.
4. **Error Handling**: Gracefully recover from network or parsing anomalies with actionable diagnostic logs.

## 4. Practical Implementation Example
```markdown
use skill: dart-fix-runtime-errors --target src/app --verbose
```

## 5. Multi-Platform Agent Compatibility Matrix
- **Google Antigravity**: Native support via `/goal`, `/schedule`, and rule sidecars.
- **Anthropic Claude Code**: Integrated into `CLAUDE.md` and XML system prompt blocks.
- **Cursor IDE**: Direct compilation into `.cursorrules` and semantic index queries.
- **Windsurf / Codex / Cline / Roo Code**: Universal MCP and system prompt compatible.
