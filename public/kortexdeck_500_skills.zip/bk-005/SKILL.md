---
name: bk-005
description: "Build real-time WebSocket hub with rooms, broadcasts, and presence"
category: "Backend & API"
platform: "Backend"
type: "Pattern"
difficulty: "Advanced"
tags: ["websocket", "realtime", "socket.io", "redis"]
---

# WebSocket Real-Time Hub

> **Platform**: `BACKEND` | **Category**: `Backend & API` | **Type**: `Pattern` | **Difficulty**: `Advanced`

## 1. Executive Summary & Purpose
Implement Socket.io or native WebSocket server with room management, typed events, heartbeat/ping, reconnection logic, and Redis pub/sub for horizontal scaling

## 2. Activation Syntax & Command Line
```bash
/ws-hub [feature] [--rooms] [--redis] [--framework socket.io|ws]
```

## 3. Core Behavioral Directives & Execution Protocol
1. **Context Initialization**: Prioritize zero-latency client-side execution, defensive boundaries, and strict type safety.
2. **Autonomous Execution**: When triggered via `/ws-hub`, execute all sub-tasks systematically until complete verification.
3. **Safety & Privacy**: Sanitize all inputs. Never log or transmit authentication credentials, private tokens, or sensitive user environment data.
4. **Error Handling**: Gracefully recover from network or parsing anomalies with actionable diagnostic logs.

## 4. Practical Implementation Example
```markdown
/ws-hub chat --rooms --redis --framework socket.io
```

## 5. Multi-Platform Agent Compatibility Matrix
- **Google Antigravity**: Native support via `/goal`, `/schedule`, and rule sidecars.
- **Anthropic Claude Code**: Integrated into `CLAUDE.md` and XML system prompt blocks.
- **Cursor IDE**: Direct compilation into `.cursorrules` and semantic index queries.
- **Windsurf / Codex / Cline / Roo Code**: Universal MCP and system prompt compatible.
