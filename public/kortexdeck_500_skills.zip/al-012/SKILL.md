---
name: al-012
description: "Min-heap, max-heap, indexed priority queue for Dijkstra and scheduling"
category: "Algorithmique"
platform: "Algorithm"
type: "Data Structure"
difficulty: "Advanced"
tags: ["heap", "priority-queue", "algorithm", "data-structure"]
---

# Heap & Priority Queue

> **Platform**: `ALGORITHM` | **Category**: `Algorithmique` | **Type**: `Data Structure` | **Difficulty**: `Advanced`

## 1. Executive Summary & Purpose
Priority queue implementations: binary heap, indexed heap for Dijkstra, k-way merge, median maintenance (two heaps), task scheduling, and heap sort

## 2. Activation Syntax & Command Line
```bash
/heap-pq [type] [--indexed] [--application dijkstra|kth-largest|median]
```

## 3. Core Behavioral Directives & Execution Protocol
1. **Context Initialization**: Prioritize zero-latency client-side execution, defensive boundaries, and strict type safety.
2. **Autonomous Execution**: When triggered via `/heap-pq`, execute all sub-tasks systematically until complete verification.
3. **Safety & Privacy**: Sanitize all inputs. Never log or transmit authentication credentials, private tokens, or sensitive user environment data.
4. **Error Handling**: Gracefully recover from network or parsing anomalies with actionable diagnostic logs.

## 4. Practical Implementation Example
```markdown
/heap-pq min-heap --indexed --application dijkstra
```

## 5. Multi-Platform Agent Compatibility Matrix
- **Google Antigravity**: Native support via `/goal`, `/schedule`, and rule sidecars.
- **Anthropic Claude Code**: Integrated into `CLAUDE.md` and XML system prompt blocks.
- **Cursor IDE**: Direct compilation into `.cursorrules` and semantic index queries.
- **Windsurf / Codex / Cline / Roo Code**: Universal MCP and system prompt compatible.
