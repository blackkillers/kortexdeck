---
name: img-002
description: "Engineer Stable Diffusion prompts: style, lighting, composition, negative prompts"
category: "Image"
platform: "Image"
type: "AI Generation"
difficulty: "Advanced"
tags: ["stable-diffusion", "image-generation", "prompt-engineering", "ai"]
---

# Stable Diffusion Prompter

> **Platform**: `IMAGE` | **Category**: `Image` | **Type**: `AI Generation` | **Difficulty**: `Advanced`

## 1. Executive Summary & Purpose
SD prompt engineering: style modifiers (cinematic, illustration, photography), lighting (golden hour, studio), composition (rule of thirds), LoRA concepts, and CLIP guidance

## 2. Activation Syntax & Command Line
```bash
/sd-prompt [subject] [--style cinematic|illustration|photography] [--lighting] [--negative]
```

## 3. Core Behavioral Directives & Execution Protocol
1. **Context Initialization**: Prioritize zero-latency client-side execution, defensive boundaries, and strict type safety.
2. **Autonomous Execution**: When triggered via `/sd-prompt`, execute all sub-tasks systematically until complete verification.
3. **Safety & Privacy**: Sanitize all inputs. Never log or transmit authentication credentials, private tokens, or sensitive user environment data.
4. **Error Handling**: Gracefully recover from network or parsing anomalies with actionable diagnostic logs.

## 4. Practical Implementation Example
```markdown
/sd-prompt portrait --style cinematic --lighting golden-hour --negative blur,low-quality
```

## 5. Multi-Platform Agent Compatibility Matrix
- **Google Antigravity**: Native support via `/goal`, `/schedule`, and rule sidecars.
- **Anthropic Claude Code**: Integrated into `CLAUDE.md` and XML system prompt blocks.
- **Cursor IDE**: Direct compilation into `.cursorrules` and semantic index queries.
- **Windsurf / Codex / Cline / Roo Code**: Universal MCP and system prompt compatible.
