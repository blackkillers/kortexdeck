---
name: claude-bench
description: "Benchmarks execution speed (ops/sec) and memory footprint for critical functions."
category: "Debugging & Tests"
platform: "claude"
type: "Slash Command"
difficulty: "Expert"
tags: ["bench", "claude", "claude-code", "debugging & tests", "cli"]
---

# Algorithmic Benchmark Suite

> **Platform**: `CLAUDE` | **Category**: `Debugging & Tests` | **Type**: `Slash Command` | **Difficulty**: `Expert`

## 1. Executive Summary & Purpose
Official Anthropic Claude Code slash command for algorithmic benchmark suite. Benchmarks execution speed (ops/sec) and memory footprint for critical functions.

## 2. Activation Syntax & Command Line
```bash
/bench [options] [arguments]
```

## 3. Core Behavioral Directives & Execution Protocol
1. **Context Initialization**: Prioritize zero-latency client-side execution, defensive boundaries, and strict type safety.
2. **Autonomous Execution**: When triggered via `/bench`, execute all sub-tasks systematically until complete verification.
3. **Safety & Privacy**: Sanitize all inputs. Never log or transmit authentication credentials, private tokens, or sensitive user environment data.
4. **Error Handling**: Gracefully recover from network or parsing anomalies with actionable diagnostic logs.

## 4. Practical Implementation Example
```markdown
/bench --help
```

## 5. Multi-Platform Agent Compatibility Matrix
- **Google Antigravity**: Native support via `/goal`, `/schedule`, and rule sidecars.
- **Anthropic Claude Code**: Integrated into `CLAUDE.md` and XML system prompt blocks.
- **Cursor IDE**: Direct compilation into `.cursorrules` and semantic index queries.
- **Windsurf / Codex / Cline / Roo Code**: Universal MCP and system prompt compatible.
