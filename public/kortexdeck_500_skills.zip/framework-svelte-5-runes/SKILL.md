---
name: framework-svelte-5-runes
description: "Deep integration of Svelte 5 $state, $derived, $effect, and snippet composition patterns."
category: "Framework"
platform: "universal"
type: "Modern Frontend"
difficulty: "Intermediate"
tags: ["svelte5", "runes", "signals", "framework", "frontend"]
---

# Svelte 5 Runes & Fine-Grained Reactivity

> **Platform**: `UNIVERSAL` | **Category**: `Framework` | **Type**: `Modern Frontend` | **Difficulty**: `Intermediate`

## 1. Executive Summary & Purpose
Builds ultra-lightweight web applications with zero virtual DOM overhead. Leverages universal signals across components, typed runes, and declarative event handlers.

## 2. Activation Syntax & Command Line
```bash
let count = $state(0); let doubled = $derived(count * 2); $effect(() => console.log(count));
```

## 3. Core Behavioral Directives & Execution Protocol
1. **Context Initialization**: Prioritize zero-latency client-side execution, defensive boundaries, and strict type safety.
2. **Autonomous Execution**: When triggered via `skill:svelte-5-runes`, execute all sub-tasks systematically until complete verification.
3. **Safety & Privacy**: Sanitize all inputs. Never log or transmit authentication credentials, private tokens, or sensitive user environment data.
4. **Error Handling**: Gracefully recover from network or parsing anomalies with actionable diagnostic logs.

## 4. Practical Implementation Example
```markdown
Refactor a complex stateful shopping cart component into Svelte 5 runes with reactive derived totals and localStorage synchronization.
```

## 5. Multi-Platform Agent Compatibility Matrix
- **Google Antigravity**: Native support via `/goal`, `/schedule`, and rule sidecars.
- **Anthropic Claude Code**: Integrated into `CLAUDE.md` and XML system prompt blocks.
- **Cursor IDE**: Direct compilation into `.cursorrules` and semantic index queries.
- **Windsurf / Codex / Cline / Roo Code**: Universal MCP and system prompt compatible.
