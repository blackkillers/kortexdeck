---
name: fw-003
description: "Build NestJS modules: controllers, services, guards, interceptors, pipes"
category: "Framework"
platform: "Framework"
type: "Backend"
difficulty: "Advanced"
tags: ["nestjs", "typescript", "node", "dependency-injection", "guards"]
---

# NestJS Module Builder

> **Platform**: `FRAMEWORK` | **Category**: `Framework` | **Type**: `Backend` | **Difficulty**: `Advanced`

## 1. Executive Summary & Purpose
NestJS module architecture: feature modules, dependency injection, guards (JWT/RBAC), interceptors (logging/transform), pipes (validation), exception filters, and Swagger decorator

## 2. Activation Syntax & Command Line
```bash
/nestjs-module [module] [--guard jwt|rbac] [--interceptor] [--swagger]
```

## 3. Core Behavioral Directives & Execution Protocol
1. **Context Initialization**: Prioritize zero-latency client-side execution, defensive boundaries, and strict type safety.
2. **Autonomous Execution**: When triggered via `/nestjs-module`, execute all sub-tasks systematically until complete verification.
3. **Safety & Privacy**: Sanitize all inputs. Never log or transmit authentication credentials, private tokens, or sensitive user environment data.
4. **Error Handling**: Gracefully recover from network or parsing anomalies with actionable diagnostic logs.

## 4. Practical Implementation Example
```markdown
/nestjs-module auth --guard jwt,rbac --interceptor logging --swagger
```

## 5. Multi-Platform Agent Compatibility Matrix
- **Google Antigravity**: Native support via `/goal`, `/schedule`, and rule sidecars.
- **Anthropic Claude Code**: Integrated into `CLAUDE.md` and XML system prompt blocks.
- **Cursor IDE**: Direct compilation into `.cursorrules` and semantic index queries.
- **Windsurf / Codex / Cline / Roo Code**: Universal MCP and system prompt compatible.
