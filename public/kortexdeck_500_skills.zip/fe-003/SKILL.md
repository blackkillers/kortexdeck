---
name: fe-003
description: "Build reusable Tailwind CSS component system with variants and dark mode"
category: "Frontend & UI"
platform: "Frontend"
type: "Design"
difficulty: "Advanced"
tags: ["tailwind", "design-system", "css", "ui"]
---

# Tailwind Component System

> **Platform**: `FRONTEND` | **Category**: `Frontend & UI` | **Type**: `Design` | **Difficulty**: `Advanced`

## 1. Executive Summary & Purpose
Create design system with Tailwind v4: CVA variants, class-variance-authority, Radix UI primitives, dark mode toggle, responsive breakpoints, and Storybook docs

## 2. Activation Syntax & Command Line
```bash
/tailwind-system [component] [--variants] [--dark-mode] [--storybook]
```

## 3. Core Behavioral Directives & Execution Protocol
1. **Context Initialization**: Prioritize zero-latency client-side execution, defensive boundaries, and strict type safety.
2. **Autonomous Execution**: When triggered via `/tailwind-system`, execute all sub-tasks systematically until complete verification.
3. **Safety & Privacy**: Sanitize all inputs. Never log or transmit authentication credentials, private tokens, or sensitive user environment data.
4. **Error Handling**: Gracefully recover from network or parsing anomalies with actionable diagnostic logs.

## 4. Practical Implementation Example
```markdown
/tailwind-system Button --variants primary,secondary,ghost --dark-mode --storybook
```

## 5. Multi-Platform Agent Compatibility Matrix
- **Google Antigravity**: Native support via `/goal`, `/schedule`, and rule sidecars.
- **Anthropic Claude Code**: Integrated into `CLAUDE.md` and XML system prompt blocks.
- **Cursor IDE**: Direct compilation into `.cursorrules` and semantic index queries.
- **Windsurf / Codex / Cline / Roo Code**: Universal MCP and system prompt compatible.
