---
name: algo-ast-graph-traversal
description: "Abstract Syntax Tree parsing, cyclic dependency detection with Tarjan's SCC, and topological sort execution."
category: "Algorithmique"
platform: "universal"
type: "Algorithm"
difficulty: "Expert"
tags: ["algorithms", "ast", "graph-theory", "toposort", "refactoring"]
---

# AST Code Analysis & Dependency Graph Traversal

> **Platform**: `UNIVERSAL` | **Category**: `Algorithmique` | **Type**: `Algorithm` | **Difficulty**: `Expert`

## 1. Executive Summary & Purpose
Navigates codebases using AST visitor patterns. Identifies dead code, builds cross-module dependency DAGs, computes cyclomatic complexity, and verifies architectural boundaries.

## 2. Activation Syntax & Command Line
```bash
/algo-ast analyze --target=src --detect-cycles --toposort
```

## 3. Core Behavioral Directives & Execution Protocol
1. **Context Initialization**: Prioritize zero-latency client-side execution, defensive boundaries, and strict type safety.
2. **Autonomous Execution**: When triggered via `skill:algo-ast-graph`, execute all sub-tasks systematically until complete verification.
3. **Safety & Privacy**: Sanitize all inputs. Never log or transmit authentication credentials, private tokens, or sensitive user environment data.
4. **Error Handling**: Gracefully recover from network or parsing anomalies with actionable diagnostic logs.

## 4. Practical Implementation Example
```markdown
Parse all TypeScript files in the monorepo, construct the dependency graph, detect any circular imports, and output the topological build order.
```

## 5. Multi-Platform Agent Compatibility Matrix
- **Google Antigravity**: Native support via `/goal`, `/schedule`, and rule sidecars.
- **Anthropic Claude Code**: Integrated into `CLAUDE.md` and XML system prompt blocks.
- **Cursor IDE**: Direct compilation into `.cursorrules` and semantic index queries.
- **Windsurf / Codex / Cline / Roo Code**: Universal MCP and system prompt compatible.
