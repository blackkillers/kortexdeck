---
name: docs
description: "Indexes and searches third-party framework documentation (React, Tailwind, Prisma, etc.)."
category: "Architecture & System"
platform: "cursor"
type: "Extension"
difficulty: "Beginner"
tags: ["cursor", "docs", "documentation", "framework", "reference"]
---

# Official Framework Documentation (@docs)

> **Platform**: `CURSOR` | **Category**: `Architecture & System` | **Type**: `Extension` | **Difficulty**: `Beginner`

## 1. Executive Summary & Purpose
Connects directly to official library documentation so code generations always adhere to modern specifications.

## 2. Activation Syntax & Command Line
```bash
@docs <library_name> <question>
```

## 3. Core Behavioral Directives & Execution Protocol
1. **Context Initialization**: Prioritize zero-latency client-side execution, defensive boundaries, and strict type safety.
2. **Autonomous Execution**: When triggered via `@docs`, execute all sub-tasks systematically until complete verification.
3. **Safety & Privacy**: Sanitize all inputs. Never log or transmit authentication credentials, private tokens, or sensitive user environment data.
4. **Error Handling**: Gracefully recover from network or parsing anomalies with actionable diagnostic logs.

## 4. Practical Implementation Example
```markdown
@docs Zustand How to configure a persistent storage middleware with LZ-String compression?
```

## 5. Multi-Platform Agent Compatibility Matrix
- **Google Antigravity**: Native support via `/goal`, `/schedule`, and rule sidecars.
- **Anthropic Claude Code**: Integrated into `CLAUDE.md` and XML system prompt blocks.
- **Cursor IDE**: Direct compilation into `.cursorrules` and semantic index queries.
- **Windsurf / Codex / Cline / Roo Code**: Universal MCP and system prompt compatible.
