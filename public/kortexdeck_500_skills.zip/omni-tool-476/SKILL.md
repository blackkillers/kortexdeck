---
name: omni-tool-476
description: "High-performance engineering directive #476 specialized for Science & Bio."
category: "Science & Bio"
platform: "antigravity"
type: "Prompt Template"
difficulty: "Intermediate"
tags: ["tool-476", "science & bio", "antigravity", "command"]
---

# Engineering Directive #476

> **Platform**: `ANTIGRAVITY` | **Category**: `Science & Bio` | **Type**: `Prompt Template` | **Difficulty**: `Intermediate`

## 1. Executive Summary & Purpose
Detailed technical specification and execution prompt for solving advanced engineering challenges in Science & Bio.

## 2. Activation Syntax & Command Line
```bash
/tool-476 --target-env <dev|staging|prod> [--debug]
```

## 3. Core Behavioral Directives & Execution Protocol
1. **Context Initialization**: Prioritize zero-latency client-side execution, defensive boundaries, and strict type safety.
2. **Autonomous Execution**: When triggered via `/tool-476`, execute all sub-tasks systematically until complete verification.
3. **Safety & Privacy**: Sanitize all inputs. Never log or transmit authentication credentials, private tokens, or sensitive user environment data.
4. **Error Handling**: Gracefully recover from network or parsing anomalies with actionable diagnostic logs.

## 4. Practical Implementation Example
```markdown
/tool-476 --target-env prod --debug
```

## 5. Multi-Platform Agent Compatibility Matrix
- **Google Antigravity**: Native support via `/goal`, `/schedule`, and rule sidecars.
- **Anthropic Claude Code**: Integrated into `CLAUDE.md` and XML system prompt blocks.
- **Cursor IDE**: Direct compilation into `.cursorrules` and semantic index queries.
- **Windsurf / Codex / Cline / Roo Code**: Universal MCP and system prompt compatible.
