---
name: agy-flutter-apply-architecture-best-practices
description: "Structures modular UI/Domain/Data layer patterns with Riverpod or BLoC."
category: "Architecture & System"
platform: "antigravity"
type: "Skill"
difficulty: "Intermediate"
tags: ["flutter-apply-architecture-best-practices", "flutter-apply-architecture-best-practices", "architecture & system", "antigravity", "skill"]
---

# Flutter Clean Architecture Pro

> **Platform**: `ANTIGRAVITY` | **Category**: `Architecture & System` | **Type**: `Skill` | **Difficulty**: `Intermediate`

## 1. Executive Summary & Purpose
Applies the Flutter Clean Architecture Pro skill in Google Antigravity to solve domain-specific architectural challenges with verified best practices.

## 2. Activation Syntax & Command Line
```bash
use skill: flutter-apply-architecture-best-practices [--option <value>]
```

## 3. Core Behavioral Directives & Execution Protocol
1. **Context Initialization**: Prioritize zero-latency client-side execution, defensive boundaries, and strict type safety.
2. **Autonomous Execution**: When triggered via `flutter-apply-architecture-best-practices`, execute all sub-tasks systematically until complete verification.
3. **Safety & Privacy**: Sanitize all inputs. Never log or transmit authentication credentials, private tokens, or sensitive user environment data.
4. **Error Handling**: Gracefully recover from network or parsing anomalies with actionable diagnostic logs.

## 4. Practical Implementation Example
```markdown
use skill: flutter-apply-architecture-best-practices --target src/app --verbose
```

## 5. Multi-Platform Agent Compatibility Matrix
- **Google Antigravity**: Native support via `/goal`, `/schedule`, and rule sidecars.
- **Anthropic Claude Code**: Integrated into `CLAUDE.md` and XML system prompt blocks.
- **Cursor IDE**: Direct compilation into `.cursorrules` and semantic index queries.
- **Windsurf / Codex / Cline / Roo Code**: Universal MCP and system prompt compatible.
