---
name: video-generative-ai-director
description: "Cinematic text-to-video prompt architecture for Runway Gen-3, OpenAI Sora, Kling 1.5, and Google Veo 2."
category: "Video"
platform: "universal"
type: "Prompt Engineering"
difficulty: "Intermediate"
tags: ["video", "generative-ai", "sora", "runway", "kling", "prompt-engineering"]
---

# Generative AI Video Director (Sora / Runway / Kling)

> **Platform**: `UNIVERSAL` | **Category**: `Video` | **Type**: `Prompt Engineering` | **Difficulty**: `Intermediate`

## 1. Executive Summary & Purpose
Constructs structured cinematic prompts specifying camera focal length (35mm / 85mm), lighting (golden hour / cyberpunk neon / volumetric fog), camera movement vectors, and physics consistency.

## 2. Activation Syntax & Command Line
```bash
[Subject Description] + [Camera Motion] + [Lighting & Style] + [Resolution & Frame Details]
```

## 3. Core Behavioral Directives & Execution Protocol
1. **Context Initialization**: Prioritize zero-latency client-side execution, defensive boundaries, and strict type safety.
2. **Autonomous Execution**: When triggered via `skill:video-ai-director`, execute all sub-tasks systematically until complete verification.
3. **Safety & Privacy**: Sanitize all inputs. Never log or transmit authentication credentials, private tokens, or sensitive user environment data.
4. **Error Handling**: Gracefully recover from network or parsing anomalies with actionable diagnostic logs.

## 4. Practical Implementation Example
```markdown
Generate a 5-second cinematic trailer prompt with macro lens tracking, anamorphic lens flares, and hyper-detailed cybernetic particle effects.
```

## 5. Multi-Platform Agent Compatibility Matrix
- **Google Antigravity**: Native support via `/goal`, `/schedule`, and rule sidecars.
- **Anthropic Claude Code**: Integrated into `CLAUDE.md` and XML system prompt blocks.
- **Cursor IDE**: Direct compilation into `.cursorrules` and semantic index queries.
- **Windsurf / Codex / Cline / Roo Code**: Universal MCP and system prompt compatible.
