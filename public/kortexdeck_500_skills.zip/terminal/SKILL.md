---
name: terminal
description: "Captures compiler error messages and stack traces from the terminal."
category: "Debugging & Tests"
platform: "cursor"
type: "Extension"
difficulty: "Beginner"
tags: ["cursor", "terminal", "logs", "error", "stacktrace"]
---

# Terminal Output Capture (@terminal)

> **Platform**: `CURSOR` | **Category**: `Debugging & Tests` | **Type**: `Extension` | **Difficulty**: `Beginner`

## 1. Executive Summary & Purpose
Allows the model to directly analyze crash logs and build failures without manual copy-pasting.

## 2. Activation Syntax & Command Line
```bash
@terminal <last_error>
```

## 3. Core Behavioral Directives & Execution Protocol
1. **Context Initialization**: Prioritize zero-latency client-side execution, defensive boundaries, and strict type safety.
2. **Autonomous Execution**: When triggered via `@terminal`, execute all sub-tasks systematically until complete verification.
3. **Safety & Privacy**: Sanitize all inputs. Never log or transmit authentication credentials, private tokens, or sensitive user environment data.
4. **Error Handling**: Gracefully recover from network or parsing anomalies with actionable diagnostic logs.

## 4. Practical Implementation Example
```markdown
@terminal Fix the TypeScript compilation error reported in the terminal output.
```

## 5. Multi-Platform Agent Compatibility Matrix
- **Google Antigravity**: Native support via `/goal`, `/schedule`, and rule sidecars.
- **Anthropic Claude Code**: Integrated into `CLAUDE.md` and XML system prompt blocks.
- **Cursor IDE**: Direct compilation into `.cursorrules` and semantic index queries.
- **Windsurf / Codex / Cline / Roo Code**: Universal MCP and system prompt compatible.
