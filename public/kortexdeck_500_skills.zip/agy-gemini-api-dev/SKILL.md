---
name: agy-gemini-api-dev
description: "Integrates multimodal calls (audio/video/vision), function calling, and structured JSON output."
category: "AI & Multimodal"
platform: "antigravity"
type: "Skill"
difficulty: "Intermediate"
tags: ["gemini-api-dev", "gemini-api-dev", "ai & multimodal", "antigravity", "skill"]
---

# Google GenAI SDK & Gemini 2.5/3 Pro

> **Platform**: `ANTIGRAVITY` | **Category**: `AI & Multimodal` | **Type**: `Skill` | **Difficulty**: `Intermediate`

## 1. Executive Summary & Purpose
Applies the Google GenAI SDK & Gemini 2.5/3 Pro skill in Google Antigravity to solve domain-specific architectural challenges with verified best practices.

## 2. Activation Syntax & Command Line
```bash
use skill: gemini-api-dev [--option <value>]
```

## 3. Core Behavioral Directives & Execution Protocol
1. **Context Initialization**: Prioritize zero-latency client-side execution, defensive boundaries, and strict type safety.
2. **Autonomous Execution**: When triggered via `gemini-api-dev`, execute all sub-tasks systematically until complete verification.
3. **Safety & Privacy**: Sanitize all inputs. Never log or transmit authentication credentials, private tokens, or sensitive user environment data.
4. **Error Handling**: Gracefully recover from network or parsing anomalies with actionable diagnostic logs.

## 4. Practical Implementation Example
```markdown
use skill: gemini-api-dev --target src/app --verbose
```

## 5. Multi-Platform Agent Compatibility Matrix
- **Google Antigravity**: Native support via `/goal`, `/schedule`, and rule sidecars.
- **Anthropic Claude Code**: Integrated into `CLAUDE.md` and XML system prompt blocks.
- **Cursor IDE**: Direct compilation into `.cursorrules` and semantic index queries.
- **Windsurf / Codex / Cline / Roo Code**: Universal MCP and system prompt compatible.
