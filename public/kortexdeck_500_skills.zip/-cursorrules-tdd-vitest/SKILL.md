---
name: -cursorrules-tdd-vitest
description: "Requires writing a failing unit test before any production code implementation."
category: "Debugging & Tests"
platform: "cursor"
type: "Rule / Prompt"
difficulty: "Intermediate"
tags: [".cursorrules-tdd-vitest", "cursorrules", "cursor", "best-practices"]
---

# Test-Driven Development (TDD) Rule

> **Platform**: `CURSOR` | **Category**: `Debugging & Tests` | **Type**: `Rule / Prompt` | **Difficulty**: `Intermediate`

## 1. Executive Summary & Purpose
.cursorrules governance file to automate team engineering standards: Requires writing a failing unit test before any production code implementation.

## 2. Activation Syntax & Command Line
```bash
// .cursorrules
.cursorrules:tdd-vitest
// Active directives in Cursor IDE
```

## 3. Core Behavioral Directives & Execution Protocol
1. **Context Initialization**: Prioritize zero-latency client-side execution, defensive boundaries, and strict type safety.
2. **Autonomous Execution**: When triggered via `.cursorrules:tdd-vitest`, execute all sub-tasks systematically until complete verification.
3. **Safety & Privacy**: Sanitize all inputs. Never log or transmit authentication credentials, private tokens, or sensitive user environment data.
4. **Error Handling**: Gracefully recover from network or parsing anomalies with actionable diagnostic logs.

## 4. Practical Implementation Example
```markdown
Build an authentication component strictly following the Test-Driven Development (TDD) Rule specification.
```

## 5. Multi-Platform Agent Compatibility Matrix
- **Google Antigravity**: Native support via `/goal`, `/schedule`, and rule sidecars.
- **Anthropic Claude Code**: Integrated into `CLAUDE.md` and XML system prompt blocks.
- **Cursor IDE**: Direct compilation into `.cursorrules` and semantic index queries.
- **Windsurf / Codex / Cline / Roo Code**: Universal MCP and system prompt compatible.
