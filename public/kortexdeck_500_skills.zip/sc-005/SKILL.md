---
name: sc-005
description: "Intercept and reverse-engineer hidden APIs from web apps using browser devtools"
category: "Scraping"
platform: "Scraping"
type: "Analysis"
difficulty: "Advanced"
tags: ["api-reverse", "scraping", "network", "playwright", "devtools"]
---

# API Reverse Engineer

> **Platform**: `SCRAPING` | **Category**: `Scraping` | **Type**: `Analysis` | **Difficulty**: `Advanced`

## 1. Executive Summary & Purpose
Reverse engineer hidden APIs: Playwright network interception, HAR file analysis, JWT token extraction, GraphQL introspection, WebSocket message capture, and API reconstruction

## 2. Activation Syntax & Command Line
```bash
/api-reverse [url] [--intercept] [--graphql] [--websocket] [--export postman]
```

## 3. Core Behavioral Directives & Execution Protocol
1. **Context Initialization**: Prioritize zero-latency client-side execution, defensive boundaries, and strict type safety.
2. **Autonomous Execution**: When triggered via `/api-reverse`, execute all sub-tasks systematically until complete verification.
3. **Safety & Privacy**: Sanitize all inputs. Never log or transmit authentication credentials, private tokens, or sensitive user environment data.
4. **Error Handling**: Gracefully recover from network or parsing anomalies with actionable diagnostic logs.

## 4. Practical Implementation Example
```markdown
/api-reverse https://spa-app.com --intercept --graphql --export postman
```

## 5. Multi-Platform Agent Compatibility Matrix
- **Google Antigravity**: Native support via `/goal`, `/schedule`, and rule sidecars.
- **Anthropic Claude Code**: Integrated into `CLAUDE.md` and XML system prompt blocks.
- **Cursor IDE**: Direct compilation into `.cursorrules` and semantic index queries.
- **Windsurf / Codex / Cline / Roo Code**: Universal MCP and system prompt compatible.
