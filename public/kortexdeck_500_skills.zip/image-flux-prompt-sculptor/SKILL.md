---
name: image-flux-prompt-sculptor
description: "High-fidelity text-to-image prompt engineering with parameter tuning (--ar, --stylize, LoRA weights, negative prompts)."
category: "Image"
platform: "universal"
type: "Generative AI"
difficulty: "Beginner"
tags: ["image", "midjourney", "flux", "generative-ai", "prompting"]
---

# Midjourney & Flux.1 Prompt Sculptor

> **Platform**: `UNIVERSAL` | **Category**: `Image` | **Type**: `Generative AI` | **Difficulty**: `Beginner`

## 1. Executive Summary & Purpose
Creates breathtaking photorealistic and vector digital art prompts. Balances compositional weight, texture detail, color harmony, and typographic legibility inside generative image models.

## 2. Activation Syntax & Command Line
```bash
[Core Subject] --style [Photorealistic/Cyberpunk] --lighting [Rim Lighting/Chiaroscuro] --ar 16:9 --v 6.1
```

## 3. Core Behavioral Directives & Execution Protocol
1. **Context Initialization**: Prioritize zero-latency client-side execution, defensive boundaries, and strict type safety.
2. **Autonomous Execution**: When triggered via `skill:image-flux-sculptor`, execute all sub-tasks systematically until complete verification.
3. **Safety & Privacy**: Sanitize all inputs. Never log or transmit authentication credentials, private tokens, or sensitive user environment data.
4. **Error Handling**: Gracefully recover from network or parsing anomalies with actionable diagnostic logs.

## 4. Practical Implementation Example
```markdown
Sculpt a prompt for a high-end luxury dark-mode web landing page hero graphic with floating holographic glass cards and volumetric cyan lighting.
```

## 5. Multi-Platform Agent Compatibility Matrix
- **Google Antigravity**: Native support via `/goal`, `/schedule`, and rule sidecars.
- **Anthropic Claude Code**: Integrated into `CLAUDE.md` and XML system prompt blocks.
- **Cursor IDE**: Direct compilation into `.cursorrules` and semantic index queries.
- **Windsurf / Codex / Cline / Roo Code**: Universal MCP and system prompt compatible.
