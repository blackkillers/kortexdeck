---
name: ui-ux-pro-max
description: "Elite design reasoning system enforcing modern color palettes, typography scale, micro-interactions, responsive grids, and strict WCAG A11y standards."
category: "Frontend & UI"
platform: "universal"
type: "Design Intelligence"
difficulty: "Expert"
tags: ["frontend", "ui-ux", "design-system", "tailwind", "accessibility", "a11y"]
---

# UI/UX Pro Max Design Intelligence

> **Platform**: `UNIVERSAL` | **Category**: `Frontend & UI` | **Type**: `Design Intelligence` | **Difficulty**: `Expert`

## 1. Executive Summary & Purpose
Transforms generic AI code into human-crafted, premium user interfaces. Injects cohesive 8pt spacing grids, modern glassmorphism/dark-mode aesthetics, fluid typography hierarchies, accessible contrast ratios (minimum 4.5:1), and deliberate micro-interactions.

## 2. Activation Syntax & Command Line
```bash
/ui-ux-pro-max --theme=dark-glass --layout=responsive-grid --a11y=strict
```

## 3. Core Behavioral Directives & Execution Protocol
1. **Context Initialization**: Prioritize zero-latency client-side execution, defensive boundaries, and strict type safety.
2. **Autonomous Execution**: When triggered via `skill:ui-ux-pro-max`, execute all sub-tasks systematically until complete verification.
3. **Safety & Privacy**: Sanitize all inputs. Never log or transmit authentication credentials, private tokens, or sensitive user environment data.
4. **Error Handling**: Gracefully recover from network or parsing anomalies with actionable diagnostic logs.

## 4. Practical Implementation Example
```markdown
/ui-ux-pro-max Create a high-conversion SaaS analytics dashboard with interactive metrics cards, custom SVG mini-charts, and keyboard-navigable tabs.
```

## 5. Multi-Platform Agent Compatibility Matrix
- **Google Antigravity**: Native support via `/goal`, `/schedule`, and rule sidecars.
- **Anthropic Claude Code**: Integrated into `CLAUDE.md` and XML system prompt blocks.
- **Cursor IDE**: Direct compilation into `.cursorrules` and semantic index queries.
- **Windsurf / Codex / Cline / Roo Code**: Universal MCP and system prompt compatible.
