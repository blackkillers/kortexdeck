---
name: fastapi-async-master
description: "High-concurrency Python backend engineering with Pydantic v2 schemas, asyncpg connection pooling, dependency injection, and OpenAPI 3.1."
category: "Backend & API"
platform: "universal"
type: "Framework Rule"
difficulty: "Intermediate"
tags: ["fastapi", "python", "backend", "async", "pydantic"]
---

# FastAPI 0.115+ Async Production Architect

> **Platform**: `UNIVERSAL` | **Category**: `Backend & API` | **Type**: `Framework Rule` | **Difficulty**: `Intermediate`

## 1. Executive Summary & Purpose
Constructs asynchronous REST and WebSocket microservices in Python. Enforces strict schema validations, lifespan context managers, custom security middlewares, and background tasks.

## 2. Activation Syntax & Command Line
```bash
@app.post('/v1/events', response_model=EventOut, status_code=201)
```

## 3. Core Behavioral Directives & Execution Protocol
1. **Context Initialization**: Prioritize zero-latency client-side execution, defensive boundaries, and strict type safety.
2. **Autonomous Execution**: When triggered via `skill:fastapi-async-pro`, execute all sub-tasks systematically until complete verification.
3. **Safety & Privacy**: Sanitize all inputs. Never log or transmit authentication credentials, private tokens, or sensitive user environment data.
4. **Error Handling**: Gracefully recover from network or parsing anomalies with actionable diagnostic logs.

## 4. Practical Implementation Example
```markdown
Create an async endpoint accepting batched telemetry data, validating against Pydantic models, and pipeline-inserting into PostgreSQL via asyncpg.
```

## 5. Multi-Platform Agent Compatibility Matrix
- **Google Antigravity**: Native support via `/goal`, `/schedule`, and rule sidecars.
- **Anthropic Claude Code**: Integrated into `CLAUDE.md` and XML system prompt blocks.
- **Cursor IDE**: Direct compilation into `.cursorrules` and semantic index queries.
- **Windsurf / Codex / Cline / Roo Code**: Universal MCP and system prompt compatible.
