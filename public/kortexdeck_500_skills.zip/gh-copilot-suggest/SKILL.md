---
name: gh-copilot-suggest
description: "Generates complex shell commands and unix pipelines from natural language prompts."
category: "DevOps & Cloud"
platform: "codex"
type: "Slash Command"
difficulty: "Intermediate"
tags: ["gh-copilot-suggest", "codex", "copilot", "openai"]
---

# GitHub Copilot Suggest Shell (/suggest)

> **Platform**: `CODEX` | **Category**: `DevOps & Cloud` | **Type**: `Slash Command` | **Difficulty**: `Intermediate`

## 1. Executive Summary & Purpose
OpenAI Codex & GitHub Copilot CLI tool: Generates complex shell commands and unix pipelines from natural language prompts.

## 2. Activation Syntax & Command Line
```bash
gh copilot suggest <instructions>
```

## 3. Core Behavioral Directives & Execution Protocol
1. **Context Initialization**: Prioritize zero-latency client-side execution, defensive boundaries, and strict type safety.
2. **Autonomous Execution**: When triggered via `gh copilot suggest`, execute all sub-tasks systematically until complete verification.
3. **Safety & Privacy**: Sanitize all inputs. Never log or transmit authentication credentials, private tokens, or sensitive user environment data.
4. **Error Handling**: Gracefully recover from network or parsing anomalies with actionable diagnostic logs.

## 4. Practical Implementation Example
```markdown
gh copilot suggest Convert this nested loop into a parallelized Map-Reduce algorithm.
```

## 5. Multi-Platform Agent Compatibility Matrix
- **Google Antigravity**: Native support via `/goal`, `/schedule`, and rule sidecars.
- **Anthropic Claude Code**: Integrated into `CLAUDE.md` and XML system prompt blocks.
- **Cursor IDE**: Direct compilation into `.cursorrules` and semantic index queries.
- **Windsurf / Codex / Cline / Roo Code**: Universal MCP and system prompt compatible.
