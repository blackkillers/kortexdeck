---
name: db-001
description: "Analyze and create optimal PostgreSQL indexes: B-tree, GiST, BRIN, partial"
category: "Database"
platform: "Database"
type: "Optimization"
difficulty: "Advanced"
tags: ["postgresql", "indexes", "optimization", "sql"]
---

# PostgreSQL Index Optimizer

> **Platform**: `DATABASE` | **Category**: `Database` | **Type**: `Optimization` | **Difficulty**: `Advanced`

## 1. Executive Summary & Purpose
PostgreSQL indexing mastery: analyze slow queries with EXPLAIN ANALYZE, create B-tree, GiST, GIN, BRIN indexes, partial/covering indexes, and multi-column composite indexes

## 2. Activation Syntax & Command Line
```bash
/pg-index [table] [--analyze] [--type btree|gist|gin|brin] [--partial condition]
```

## 3. Core Behavioral Directives & Execution Protocol
1. **Context Initialization**: Prioritize zero-latency client-side execution, defensive boundaries, and strict type safety.
2. **Autonomous Execution**: When triggered via `/pg-index`, execute all sub-tasks systematically until complete verification.
3. **Safety & Privacy**: Sanitize all inputs. Never log or transmit authentication credentials, private tokens, or sensitive user environment data.
4. **Error Handling**: Gracefully recover from network or parsing anomalies with actionable diagnostic logs.

## 4. Practical Implementation Example
```markdown
/pg-index users_table --analyze --type btree --partial 'active = true'
```

## 5. Multi-Platform Agent Compatibility Matrix
- **Google Antigravity**: Native support via `/goal`, `/schedule`, and rule sidecars.
- **Anthropic Claude Code**: Integrated into `CLAUDE.md` and XML system prompt blocks.
- **Cursor IDE**: Direct compilation into `.cursorrules` and semantic index queries.
- **Windsurf / Codex / Cline / Roo Code**: Universal MCP and system prompt compatible.
