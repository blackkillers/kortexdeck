---
name: fe-004
description: "Add fluid animations with Framer Motion: page transitions, stagger, gestures"
category: "Frontend & UI"
platform: "Frontend"
type: "Animation"
difficulty: "Advanced"
tags: ["framer-motion", "animation", "ui", "react"]
---

# Framer Motion Animator

> **Platform**: `FRONTEND` | **Category**: `Frontend & UI` | **Type**: `Animation` | **Difficulty**: `Advanced`

## 1. Executive Summary & Purpose
Implement Framer Motion animations: page transitions with layout animations, stagger children, drag gestures, scroll-linked animations, and shared element transitions

## 2. Activation Syntax & Command Line
```bash
/animate [component] [--type transition|stagger|gesture|scroll] [--duration 0.3]
```

## 3. Core Behavioral Directives & Execution Protocol
1. **Context Initialization**: Prioritize zero-latency client-side execution, defensive boundaries, and strict type safety.
2. **Autonomous Execution**: When triggered via `/animate`, execute all sub-tasks systematically until complete verification.
3. **Safety & Privacy**: Sanitize all inputs. Never log or transmit authentication credentials, private tokens, or sensitive user environment data.
4. **Error Handling**: Gracefully recover from network or parsing anomalies with actionable diagnostic logs.

## 4. Practical Implementation Example
```markdown
/animate CardList --type stagger --duration 0.4
```

## 5. Multi-Platform Agent Compatibility Matrix
- **Google Antigravity**: Native support via `/goal`, `/schedule`, and rule sidecars.
- **Anthropic Claude Code**: Integrated into `CLAUDE.md` and XML system prompt blocks.
- **Cursor IDE**: Direct compilation into `.cursorrules` and semantic index queries.
- **Windsurf / Codex / Cline / Roo Code**: Universal MCP and system prompt compatible.
