---
name: algo-probabilistic-structures
description: "Implementation of space-efficient Bloom Filters, Counting Bloom Filters, HyperLogLog, and Count-Min Sketch."
category: "Algorithmique"
platform: "universal"
type: "Algorithm"
difficulty: "Advanced"
tags: ["algorithms", "bloom-filter", "hyperloglog", "probabilistic", "streaming"]
---

# Probabilistic Data Structures (Bloom & HyperLogLog)

> **Platform**: `UNIVERSAL` | **Category**: `Algorithmique` | **Type**: `Algorithm` | **Difficulty**: `Advanced`

## 1. Executive Summary & Purpose
Solves massive scale stream counting and membership problems in $O(1)$ memory. Configures optimal bit-array size and hash function counts based on false positive tolerance $\epsilon$.

## 2. Activation Syntax & Command Line
```bash
m = - (n * ln(p)) / (ln(2)^2); k = (m / n) * ln(2)
```

## 3. Core Behavioral Directives & Execution Protocol
1. **Context Initialization**: Prioritize zero-latency client-side execution, defensive boundaries, and strict type safety.
2. **Autonomous Execution**: When triggered via `skill:algo-bloom-hll`, execute all sub-tasks systematically until complete verification.
3. **Safety & Privacy**: Sanitize all inputs. Never log or transmit authentication credentials, private tokens, or sensitive user environment data.
4. **Error Handling**: Gracefully recover from network or parsing anomalies with actionable diagnostic logs.

## 4. Practical Implementation Example
```markdown
Implement an in-memory Bloom filter in TypeScript checking URL deduplication for 10 million crawled pages with a 0.1% false positive rate.
```

## 5. Multi-Platform Agent Compatibility Matrix
- **Google Antigravity**: Native support via `/goal`, `/schedule`, and rule sidecars.
- **Anthropic Claude Code**: Integrated into `CLAUDE.md` and XML system prompt blocks.
- **Cursor IDE**: Direct compilation into `.cursorrules` and semantic index queries.
- **Windsurf / Codex / Cline / Roo Code**: Universal MCP and system prompt compatible.
