---
name: al-006
description: "Fixed/variable sliding window: max subarray, longest substring, minimum window"
category: "Algorithmique"
platform: "Algorithm"
type: "Pattern"
difficulty: "Advanced"
tags: ["sliding-window", "two-pointer", "array", "algorithm"]
---

# Sliding Window Technique

> **Platform**: `ALGORITHM` | **Category**: `Algorithmique` | **Type**: `Pattern` | **Difficulty**: `Advanced`

## 1. Executive Summary & Purpose
Apply sliding window: fixed-size window (max sum), variable-size (longest substring without repeat), monotonic deque, two-pointer technique, and shrinkable window

## 2. Activation Syntax & Command Line
```bash
/sliding-window [problem] [--window fixed|variable] [--deque]
```

## 3. Core Behavioral Directives & Execution Protocol
1. **Context Initialization**: Prioritize zero-latency client-side execution, defensive boundaries, and strict type safety.
2. **Autonomous Execution**: When triggered via `/sliding-window`, execute all sub-tasks systematically until complete verification.
3. **Safety & Privacy**: Sanitize all inputs. Never log or transmit authentication credentials, private tokens, or sensitive user environment data.
4. **Error Handling**: Gracefully recover from network or parsing anomalies with actionable diagnostic logs.

## 4. Practical Implementation Example
```markdown
/sliding-window longest-substring --window variable
```

## 5. Multi-Platform Agent Compatibility Matrix
- **Google Antigravity**: Native support via `/goal`, `/schedule`, and rule sidecars.
- **Anthropic Claude Code**: Integrated into `CLAUDE.md` and XML system prompt blocks.
- **Cursor IDE**: Direct compilation into `.cursorrules` and semantic index queries.
- **Windsurf / Codex / Cline / Roo Code**: Universal MCP and system prompt compatible.
