---
name: gh-copilot-explain
description: "Decodes cryptic shell commands, regexes, and flags step by step."
category: "DevOps & Cloud"
platform: "codex"
type: "Slash Command"
difficulty: "Intermediate"
tags: ["gh-copilot-explain", "codex", "copilot", "openai"]
---

# GitHub Copilot Explain Command (/explain)

> **Platform**: `CODEX` | **Category**: `DevOps & Cloud` | **Type**: `Slash Command` | **Difficulty**: `Intermediate`

## 1. Executive Summary & Purpose
OpenAI Codex & GitHub Copilot CLI tool: Decodes cryptic shell commands, regexes, and flags step by step.

## 2. Activation Syntax & Command Line
```bash
gh copilot explain <instructions>
```

## 3. Core Behavioral Directives & Execution Protocol
1. **Context Initialization**: Prioritize zero-latency client-side execution, defensive boundaries, and strict type safety.
2. **Autonomous Execution**: When triggered via `gh copilot explain`, execute all sub-tasks systematically until complete verification.
3. **Safety & Privacy**: Sanitize all inputs. Never log or transmit authentication credentials, private tokens, or sensitive user environment data.
4. **Error Handling**: Gracefully recover from network or parsing anomalies with actionable diagnostic logs.

## 4. Practical Implementation Example
```markdown
gh copilot explain Convert this nested loop into a parallelized Map-Reduce algorithm.
```

## 5. Multi-Platform Agent Compatibility Matrix
- **Google Antigravity**: Native support via `/goal`, `/schedule`, and rule sidecars.
- **Anthropic Claude Code**: Integrated into `CLAUDE.md` and XML system prompt blocks.
- **Cursor IDE**: Direct compilation into `.cursorrules` and semantic index queries.
- **Windsurf / Codex / Cline / Roo Code**: Universal MCP and system prompt compatible.
