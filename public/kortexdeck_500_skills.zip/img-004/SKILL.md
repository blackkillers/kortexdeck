---
name: img-004
description: "Remove image backgrounds with rembg/SAM: products, portraits, logos"
category: "Image"
platform: "Image"
type: "AI"
difficulty: "Advanced"
tags: ["background-removal", "rembg", "sam", "image", "ai"]
---

# Background Remover

> **Platform**: `IMAGE` | **Category**: `Image` | **Type**: `AI` | **Difficulty**: `Advanced`

## 1. Executive Summary & Purpose
Background removal: rembg (U²-Net) for bulk processing, Segment Anything Model (SAM) for precise cutouts, alpha channel output, transparent PNG, and batch folder processing

## 2. Activation Syntax & Command Line
```bash
/bg-remove [image] [--model rembg|sam] [--output png] [--batch folder/]
```

## 3. Core Behavioral Directives & Execution Protocol
1. **Context Initialization**: Prioritize zero-latency client-side execution, defensive boundaries, and strict type safety.
2. **Autonomous Execution**: When triggered via `/bg-remove`, execute all sub-tasks systematically until complete verification.
3. **Safety & Privacy**: Sanitize all inputs. Never log or transmit authentication credentials, private tokens, or sensitive user environment data.
4. **Error Handling**: Gracefully recover from network or parsing anomalies with actionable diagnostic logs.

## 4. Practical Implementation Example
```markdown
/bg-remove product.jpg --model rembg --output png
```

## 5. Multi-Platform Agent Compatibility Matrix
- **Google Antigravity**: Native support via `/goal`, `/schedule`, and rule sidecars.
- **Anthropic Claude Code**: Integrated into `CLAUDE.md` and XML system prompt blocks.
- **Cursor IDE**: Direct compilation into `.cursorrules` and semantic index queries.
- **Windsurf / Codex / Cline / Roo Code**: Universal MCP and system prompt compatible.
