---
name: fe-002
description: "Generate Next.js 15 App Router pages with metadata, layouts, and loading states"
category: "Frontend & UI"
platform: "Frontend"
type: "Framework"
difficulty: "Advanced"
tags: ["nextjs", "app-router", "seo", "streaming"]
---

# Next.js App Router Page

> **Platform**: `FRONTEND` | **Category**: `Frontend & UI` | **Type**: `Framework` | **Difficulty**: `Advanced`

## 1. Executive Summary & Purpose
Create App Router pages: generateStaticParams, generateMetadata, parallel routes, intercepting routes, streaming with Suspense, and partial prerendering

## 2. Activation Syntax & Command Line
```bash
/nextjs-page [route] [--type static|dynamic|ssr] [--metadata] [--loading]
```

## 3. Core Behavioral Directives & Execution Protocol
1. **Context Initialization**: Prioritize zero-latency client-side execution, defensive boundaries, and strict type safety.
2. **Autonomous Execution**: When triggered via `/nextjs-page`, execute all sub-tasks systematically until complete verification.
3. **Safety & Privacy**: Sanitize all inputs. Never log or transmit authentication credentials, private tokens, or sensitive user environment data.
4. **Error Handling**: Gracefully recover from network or parsing anomalies with actionable diagnostic logs.

## 4. Practical Implementation Example
```markdown
/nextjs-page /products/[id] --type dynamic --metadata --loading
```

## 5. Multi-Platform Agent Compatibility Matrix
- **Google Antigravity**: Native support via `/goal`, `/schedule`, and rule sidecars.
- **Anthropic Claude Code**: Integrated into `CLAUDE.md` and XML system prompt blocks.
- **Cursor IDE**: Direct compilation into `.cursorrules` and semantic index queries.
- **Windsurf / Codex / Cline / Roo Code**: Universal MCP and system prompt compatible.
