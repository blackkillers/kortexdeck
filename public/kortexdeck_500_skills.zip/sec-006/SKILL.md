---
name: sec-006
description: "Scan Docker images for vulnerabilities with Trivy, Snyk, Grype"
category: "Security"
platform: "Security"
type: "DevSecOps"
difficulty: "Advanced"
tags: ["docker", "container", "security", "trivy", "devsecops"]
---

# Container Security Scanner

> **Platform**: `SECURITY` | **Category**: `Security` | **Type**: `DevSecOps` | **Difficulty**: `Advanced`

## 1. Executive Summary & Purpose
Secure containers: Trivy vulnerability scan, non-root user enforcement, read-only filesystem, distroless base images, Snyk container scanning, and SBOM generation

## 2. Activation Syntax & Command Line
```bash
/container-sec [image] [--scanner trivy|snyk|grype] [--severity HIGH,CRITICAL] [--sbom]
```

## 3. Core Behavioral Directives & Execution Protocol
1. **Context Initialization**: Prioritize zero-latency client-side execution, defensive boundaries, and strict type safety.
2. **Autonomous Execution**: When triggered via `/container-sec`, execute all sub-tasks systematically until complete verification.
3. **Safety & Privacy**: Sanitize all inputs. Never log or transmit authentication credentials, private tokens, or sensitive user environment data.
4. **Error Handling**: Gracefully recover from network or parsing anomalies with actionable diagnostic logs.

## 4. Practical Implementation Example
```markdown
/container-sec my-app:latest --scanner trivy --severity HIGH,CRITICAL --sbom
```

## 5. Multi-Platform Agent Compatibility Matrix
- **Google Antigravity**: Native support via `/goal`, `/schedule`, and rule sidecars.
- **Anthropic Claude Code**: Integrated into `CLAUDE.md` and XML system prompt blocks.
- **Cursor IDE**: Direct compilation into `.cursorrules` and semantic index queries.
- **Windsurf / Codex / Cline / Roo Code**: Universal MCP and system prompt compatible.
