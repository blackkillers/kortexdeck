---
name: claude-pattern-few-shot-calib-24
description: "Provides 3 precise input/output examples to strictly enforce edge-case formats."
category: "AI & Multimodal"
platform: "claude"
type: "Prompt Template"
difficulty: "Intermediate"
tags: ["few-shot-calib", "claude", "prompt-engineering", "anthropic"]
---

# Few-Shot Calibration Pairs v3

> **Platform**: `CLAUDE` | **Category**: `AI & Multimodal` | **Type**: `Prompt Template` | **Difficulty**: `Intermediate`

## 1. Executive Summary & Purpose
Advanced Anthropic Claude prompt engineering pattern: Provides 3 precise input/output examples to strictly enforce edge-case formats. Optimized for Claude 3.7 Sonnet.

## 2. Activation Syntax & Command Line
```bash
<prompt_pattern name='few-shot-calib'>
  <context>...</context>
</prompt_pattern>
```

## 3. Core Behavioral Directives & Execution Protocol
1. **Context Initialization**: Prioritize zero-latency client-side execution, defensive boundaries, and strict type safety.
2. **Autonomous Execution**: When triggered via `prompt://claude/few-shot-calib-24`, execute all sub-tasks systematically until complete verification.
3. **Safety & Privacy**: Sanitize all inputs. Never log or transmit authentication credentials, private tokens, or sensitive user environment data.
4. **Error Handling**: Gracefully recover from network or parsing anomalies with actionable diagnostic logs.

## 4. Practical Implementation Example
```markdown
Apply the Few-Shot Calibration Pairs pattern to architect a resilient payment service.
```

## 5. Multi-Platform Agent Compatibility Matrix
- **Google Antigravity**: Native support via `/goal`, `/schedule`, and rule sidecars.
- **Anthropic Claude Code**: Integrated into `CLAUDE.md` and XML system prompt blocks.
- **Cursor IDE**: Direct compilation into `.cursorrules` and semantic index queries.
- **Windsurf / Codex / Cline / Roo Code**: Universal MCP and system prompt compatible.
