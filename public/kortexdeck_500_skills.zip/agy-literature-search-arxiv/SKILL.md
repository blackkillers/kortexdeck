---
name: agy-literature-search-arxiv
description: "Fetches preprints in artificial intelligence, physics, and computer science."
category: "Science & Bio"
platform: "antigravity"
type: "Skill"
difficulty: "Intermediate"
tags: ["literature-search-arxiv", "science", "biology", "genomics", "research"]
---

# arXiv Academic Paper Search

> **Platform**: `ANTIGRAVITY` | **Category**: `Science & Bio` | **Type**: `Skill` | **Difficulty**: `Intermediate`

## 1. Executive Summary & Purpose
Retrieves and analyzes specialized research data from arXiv Academic Paper Search for bioinformatics and scientific computing workflows.

## 2. Activation Syntax & Command Line
```bash
use skill: literature-search-arxiv --query <term_or_id>
```

## 3. Core Behavioral Directives & Execution Protocol
1. **Context Initialization**: Prioritize zero-latency client-side execution, defensive boundaries, and strict type safety.
2. **Autonomous Execution**: When triggered via `literature-search-arxiv`, execute all sub-tasks systematically until complete verification.
3. **Safety & Privacy**: Sanitize all inputs. Never log or transmit authentication credentials, private tokens, or sensitive user environment data.
4. **Error Handling**: Gracefully recover from network or parsing anomalies with actionable diagnostic logs.

## 4. Practical Implementation Example
```markdown
use skill: literature-search-arxiv --query BRCA1 --limit 5
```

## 5. Multi-Platform Agent Compatibility Matrix
- **Google Antigravity**: Native support via `/goal`, `/schedule`, and rule sidecars.
- **Anthropic Claude Code**: Integrated into `CLAUDE.md` and XML system prompt blocks.
- **Cursor IDE**: Direct compilation into `.cursorrules` and semantic index queries.
- **Windsurf / Codex / Cline / Roo Code**: Universal MCP and system prompt compatible.
