---
name: claude-bug
description: "Submits a detailed diagnostic report with execution logs to the Claude Code engineering team."
category: "Debugging & Tests"
platform: "claude"
type: "Slash Command"
difficulty: "Intermediate"
tags: ["bug", "claude", "claude-code", "debugging & tests", "cli"]
---

# Claude Code Bug Reporter

> **Platform**: `CLAUDE` | **Category**: `Debugging & Tests` | **Type**: `Slash Command` | **Difficulty**: `Intermediate`

## 1. Executive Summary & Purpose
Official Anthropic Claude Code slash command for claude code bug reporter. Submits a detailed diagnostic report with execution logs to the Claude Code engineering team.

## 2. Activation Syntax & Command Line
```bash
/bug [options] [arguments]
```

## 3. Core Behavioral Directives & Execution Protocol
1. **Context Initialization**: Prioritize zero-latency client-side execution, defensive boundaries, and strict type safety.
2. **Autonomous Execution**: When triggered via `/bug`, execute all sub-tasks systematically until complete verification.
3. **Safety & Privacy**: Sanitize all inputs. Never log or transmit authentication credentials, private tokens, or sensitive user environment data.
4. **Error Handling**: Gracefully recover from network or parsing anomalies with actionable diagnostic logs.

## 4. Practical Implementation Example
```markdown
/bug --help
```

## 5. Multi-Platform Agent Compatibility Matrix
- **Google Antigravity**: Native support via `/goal`, `/schedule`, and rule sidecars.
- **Anthropic Claude Code**: Integrated into `CLAUDE.md` and XML system prompt blocks.
- **Cursor IDE**: Direct compilation into `.cursorrules` and semantic index queries.
- **Windsurf / Codex / Cline / Roo Code**: Universal MCP and system prompt compatible.
