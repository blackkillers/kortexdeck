---
name: rust-axum-titan
description: "Memory-safe, blazingly fast asynchronous web microservices powered by Tokio, Tower middlewares, and type-safe state extractors."
category: "Backend & API"
platform: "universal"
type: "Framework Rule"
difficulty: "Expert"
tags: ["rust", "axum", "tokio", "backend", "zero-overhead"]
---

# Rust Axum Zero-Overhead Backend

> **Platform**: `UNIVERSAL` | **Category**: `Backend & API` | **Type**: `Framework Rule` | **Difficulty**: `Expert`

## 1. Executive Summary & Purpose
Builds mission-critical microservices in Rust. Leverages zero-copy deserialization, SQLx compile-time checked queries, and robust error enum handling without panics.

## 2. Activation Syntax & Command Line
```bash
async fn handler(State(pool): State<PgPool>, Json(payload): Json<CreateUser>) -> Result<Json<User>, AppError>
```

## 3. Core Behavioral Directives & Execution Protocol
1. **Context Initialization**: Prioritize zero-latency client-side execution, defensive boundaries, and strict type safety.
2. **Autonomous Execution**: When triggered via `skill:rust-axum-titan`, execute all sub-tasks systematically until complete verification.
3. **Safety & Privacy**: Sanitize all inputs. Never log or transmit authentication credentials, private tokens, or sensitive user environment data.
4. **Error Handling**: Gracefully recover from network or parsing anomalies with actionable diagnostic logs.

## 4. Practical Implementation Example
```markdown
Create a type-safe Axum route with JWT validation middleware, Postgres connection pool extraction, and structured JSON responses.
```

## 5. Multi-Platform Agent Compatibility Matrix
- **Google Antigravity**: Native support via `/goal`, `/schedule`, and rule sidecars.
- **Anthropic Claude Code**: Integrated into `CLAUDE.md` and XML system prompt blocks.
- **Cursor IDE**: Direct compilation into `.cursorrules` and semantic index queries.
- **Windsurf / Codex / Cline / Roo Code**: Universal MCP and system prompt compatible.
