---
name: sec-001
description: "Systematic audit for OWASP Top 10 vulnerabilities in your codebase"
category: "Security"
platform: "Security"
type: "Audit"
difficulty: "Advanced"
tags: ["owasp", "security", "audit", "vulnerabilities"]
---

# OWASP Top 10 Auditor

> **Platform**: `SECURITY` | **Category**: `Security` | **Type**: `Audit` | **Difficulty**: `Advanced`

## 1. Executive Summary & Purpose
Scan for OWASP Top 10: injection flaws, broken auth, XSS, IDOR, security misconfig, SSRF, XXE, insecure deserialization, vulnerable components, and logging failures

## 2. Activation Syntax & Command Line
```bash
/owasp-audit [target] [--top10] [--report html|json] [--fix]
```

## 3. Core Behavioral Directives & Execution Protocol
1. **Context Initialization**: Prioritize zero-latency client-side execution, defensive boundaries, and strict type safety.
2. **Autonomous Execution**: When triggered via `/owasp-audit`, execute all sub-tasks systematically until complete verification.
3. **Safety & Privacy**: Sanitize all inputs. Never log or transmit authentication credentials, private tokens, or sensitive user environment data.
4. **Error Handling**: Gracefully recover from network or parsing anomalies with actionable diagnostic logs.

## 4. Practical Implementation Example
```markdown
/owasp-audit src/ --top10 --report html --fix
```

## 5. Multi-Platform Agent Compatibility Matrix
- **Google Antigravity**: Native support via `/goal`, `/schedule`, and rule sidecars.
- **Anthropic Claude Code**: Integrated into `CLAUDE.md` and XML system prompt blocks.
- **Cursor IDE**: Direct compilation into `.cursorrules` and semantic index queries.
- **Windsurf / Codex / Cline / Roo Code**: Universal MCP and system prompt compatible.
