---
name: claude-openapi-spec
description: "Introspects REST route handlers to output complete Swagger/OpenAPI documentation."
category: "Architecture & System"
platform: "claude"
type: "Slash Command"
difficulty: "Intermediate"
tags: ["openapi-spec", "claude", "claude-code", "architecture & system", "cli"]
---

# OpenAPI v3.1 Spec Generator

> **Platform**: `CLAUDE` | **Category**: `Architecture & System` | **Type**: `Slash Command` | **Difficulty**: `Intermediate`

## 1. Executive Summary & Purpose
Official Anthropic Claude Code slash command for openapi v3.1 spec generator. Introspects REST route handlers to output complete Swagger/OpenAPI documentation.

## 2. Activation Syntax & Command Line
```bash
/openapi-spec [options] [arguments]
```

## 3. Core Behavioral Directives & Execution Protocol
1. **Context Initialization**: Prioritize zero-latency client-side execution, defensive boundaries, and strict type safety.
2. **Autonomous Execution**: When triggered via `/openapi-spec`, execute all sub-tasks systematically until complete verification.
3. **Safety & Privacy**: Sanitize all inputs. Never log or transmit authentication credentials, private tokens, or sensitive user environment data.
4. **Error Handling**: Gracefully recover from network or parsing anomalies with actionable diagnostic logs.

## 4. Practical Implementation Example
```markdown
/openapi-spec --help
```

## 5. Multi-Platform Agent Compatibility Matrix
- **Google Antigravity**: Native support via `/goal`, `/schedule`, and rule sidecars.
- **Anthropic Claude Code**: Integrated into `CLAUDE.md` and XML system prompt blocks.
- **Cursor IDE**: Direct compilation into `.cursorrules` and semantic index queries.
- **Windsurf / Codex / Cline / Roo Code**: Universal MCP and system prompt compatible.
