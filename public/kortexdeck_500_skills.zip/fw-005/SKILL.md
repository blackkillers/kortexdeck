---
name: fw-005
description: "Build Go web services with Gin/Echo: routing, middleware, validation, Swagger"
category: "Framework"
platform: "Framework"
type: "Backend"
difficulty: "Advanced"
tags: ["go", "gin", "echo", "golang", "rest"]
---

# Gin/Echo Go Web Server

> **Platform**: `FRAMEWORK` | **Category**: `Framework` | **Type**: `Backend` | **Difficulty**: `Advanced`

## 1. Executive Summary & Purpose
Go web framework: Gin/Echo router setup, middleware chain (auth, CORS, logging, recovery), request binding/validation, Swagger with swaggo, and graceful shutdown

## 2. Activation Syntax & Command Line
```bash
/go-web [framework] [--middleware auth,cors,logging] [--swagger] [--graceful]
```

## 3. Core Behavioral Directives & Execution Protocol
1. **Context Initialization**: Prioritize zero-latency client-side execution, defensive boundaries, and strict type safety.
2. **Autonomous Execution**: When triggered via `/go-web`, execute all sub-tasks systematically until complete verification.
3. **Safety & Privacy**: Sanitize all inputs. Never log or transmit authentication credentials, private tokens, or sensitive user environment data.
4. **Error Handling**: Gracefully recover from network or parsing anomalies with actionable diagnostic logs.

## 4. Practical Implementation Example
```markdown
/go-web gin --middleware jwt,cors,logger --swagger --graceful
```

## 5. Multi-Platform Agent Compatibility Matrix
- **Google Antigravity**: Native support via `/goal`, `/schedule`, and rule sidecars.
- **Anthropic Claude Code**: Integrated into `CLAUDE.md` and XML system prompt blocks.
- **Cursor IDE**: Direct compilation into `.cursorrules` and semantic index queries.
- **Windsurf / Codex / Cline / Roo Code**: Universal MCP and system prompt compatible.
