---
name: al-007
description: "Apply greedy strategies: interval scheduling, Huffman coding, activity selection"
category: "Algorithmique"
platform: "Algorithm"
type: "Greedy"
difficulty: "Advanced"
tags: ["greedy", "algorithm", "optimization", "intervals"]
---

# Greedy Algorithm Designer

> **Platform**: `ALGORITHM` | **Category**: `Algorithmique` | **Type**: `Greedy` | **Difficulty**: `Advanced`

## 1. Executive Summary & Purpose
Implement greedy algorithms: interval scheduling maximization, Huffman encoding, activity selection, fractional knapsack, job sequencing, and proof of optimality

## 2. Activation Syntax & Command Line
```bash
/greedy [problem] [--prove-optimal]
```

## 3. Core Behavioral Directives & Execution Protocol
1. **Context Initialization**: Prioritize zero-latency client-side execution, defensive boundaries, and strict type safety.
2. **Autonomous Execution**: When triggered via `/greedy`, execute all sub-tasks systematically until complete verification.
3. **Safety & Privacy**: Sanitize all inputs. Never log or transmit authentication credentials, private tokens, or sensitive user environment data.
4. **Error Handling**: Gracefully recover from network or parsing anomalies with actionable diagnostic logs.

## 4. Practical Implementation Example
```markdown
/greedy interval-scheduling --prove-optimal
```

## 5. Multi-Platform Agent Compatibility Matrix
- **Google Antigravity**: Native support via `/goal`, `/schedule`, and rule sidecars.
- **Anthropic Claude Code**: Integrated into `CLAUDE.md` and XML system prompt blocks.
- **Cursor IDE**: Direct compilation into `.cursorrules` and semantic index queries.
- **Windsurf / Codex / Cline / Roo Code**: Universal MCP and system prompt compatible.
