# 🧠 KortexDeck 500+ Curated SKILL.md Master Index
**Total Registered Skills**: 530

| ID | Title | Platform | Category | Type | Command |
|---|---|---|---|---|---|
| `namedomain-whois-dns-auditor` | **WHOIS, DNS & Email Security Record Auditor** | `universal` | Name & Domain | `Infrastructure Audit` | `skill:namedomain-dns-auditor` |
| `namedomain-saas-brand-namer` | **AI SaaS Brand Namer & Phonetic Coining** | `universal` | Name & Domain | `Naming & Brand Strategy` | `skill:namedomain-brand-namer` |
| `logo-app-icon-matrix` | **Favicon & App Icon Multi-Format Generator** | `universal` | Logo & Branding | `Asset Generation` | `skill:logo-app-icon-matrix` |
| `logo-minimalist-vector-master` | **Minimalist Tech Vector Logo Generator** | `universal` | Logo & Branding | `Brand Design` | `skill:logo-vector-master` |
| `image-sharp-optimizer-pro` | **Sharp High-Speed Image Engine (WebP / AVIF)** | `universal` | Image | `Image Processing` | `skill:image-sharp-pro` |
| `image-flux-prompt-sculptor` | **Midjourney & Flux.1 Prompt Sculptor** | `universal` | Image | `Generative AI` | `skill:image-flux-sculptor` |
| `video-generative-ai-director` | **Generative AI Video Director (Sora / Runway / Kling)** | `universal` | Video | `Prompt Engineering` | `skill:video-ai-director` |
| `video-ffmpeg-matrix-pro` | **FFmpeg Transcoder & Complex Filter Matrix** | `universal` | Video | `Media Processing` | `skill:video-ffmpeg-pro` |
| `scraping-cheerio-fast-stream` | **Cheerio & Streaming HTML Extractor** | `universal` | Scraping | `Data Extraction` | `skill:scraping-cheerio` |
| `scraping-playwright-stealth` | **Playwright & Puppeteer Stealth Scraper Pro** | `universal` | Scraping | `Web Automation` | `skill:scraping-stealth` |
| `sec-zero-trust-agent` | **Zero-Trust Agent Sandbox & Token Sentinel** | `universal` | Security | `AI Security` | `skill:sec-agent-sentinel` |
| `sec-owasp-bulletproof` | **OWASP Top 10 Bulletproof Web Defense** | `universal` | Security | `Application Security` | `skill:sec-owasp-bulletproof` |
| `framework-svelte-5-runes` | **Svelte 5 Runes & Fine-Grained Reactivity** | `universal` | Framework | `Modern Frontend` | `skill:svelte-5-runes` |
| `framework-nextjs-15-pro` | **Next.js 15 App Router & Partial Prerendering (PPR)** | `universal` | Framework | `Full-Stack Framework` | `skill:nextjs-15-pro` |
| `db-clickhouse-olap-titan` | **ClickHouse Realtime Analytics & MergeTree Engine** | `universal` | Database | `OLAP Analytics` | `skill:db-clickhouse-titan` |
| `db-pgvector-semantic-store` | **pgvector Hybrid Semantic Search Engine** | `universal` | Database | `AI Vector Search` | `skill:db-pgvector-pro` |
| `db-postgres-index-surgeon` | **PostgreSQL 16 Index Surgeon & Query Optimizer** | `universal` | Database | `Performance Tuning` | `skill:db-postgres-optimizer` |
| `arch-event-driven-outbox` | **Event-Driven & Transactional Outbox Pattern** | `universal` | Architecture | `Distributed Systems` | `skill:arch-outbox-pattern` |
| `arch-hexagonal-clean` | **Hexagonal Architecture (Ports & Adapters)** | `universal` | Architecture | `Architectural Pattern` | `skill:arch-hexagonal` |
| `algo-spatial-indexing` | **Spatial Indexing (Quadtrees, R-Tree & Geohash)** | `universal` | Algorithmique | `Algorithm` | `skill:algo-spatial-r-tree` |
| `algo-probabilistic-structures` | **Probabilistic Data Structures (Bloom & HyperLogLog)** | `universal` | Algorithmique | `Algorithm` | `skill:algo-bloom-hll` |
| `algo-ast-graph-traversal` | **AST Code Analysis & Dependency Graph Traversal** | `universal` | Algorithmique | `Algorithm` | `skill:algo-ast-graph` |
| `rust-axum-titan` | **Rust Axum Zero-Overhead Backend** | `universal` | Backend & API | `Framework Rule` | `skill:rust-axum-titan` |
| `go-high-concurrency` | **Go High-Concurrency Service Engine** | `universal` | Backend & API | `Architecture` | `skill:go-concurrency` |
| `fastapi-async-master` | **FastAPI 0.115+ Async Production Architect** | `universal` | Backend & API | `Framework Rule` | `skill:fastapi-async-pro` |
| `performance-freak` | **Performance Freak (Low-Latency & Zero-Alloc)** | `universal` | Backend & API | `Optimization Protocol` | `skill:performance-freak` |
| `framer-motion-60fps` | **Framer Motion 60FPS Micro-Interactions** | `universal` | Frontend & UI | `Animation Engine` | `skill:framer-motion-wizard` |
| `react-19-server-actions` | **React 19 Server Actions & Optimistic UI** | `universal` | Frontend & UI | `Architecture` | `skill:react-19-pro` |
| `code-impeccable` | **Code Impeccable (Zero AI-Slop)** | `universal` | Frontend & UI | `Quality & Audit` | `skill:code-impeccable` |
| `ui-ux-pro-max` | **UI/UX Pro Max Design Intelligence** | `universal` | Frontend & UI | `Design Intelligence` | `skill:ui-ux-pro-max` |
| `agy-goal` | **Persistent Autonomous Mode (/goal)** | `antigravity` | Workflow & Agents | `Slash Command` | `/goal` |
| `agy-schedule` | **Async Scheduler & Cron Jobs (/schedule)** | `antigravity` | Workflow & Agents | `Slash Command` | `/schedule` |
| `agy-browser` | **Headless Web Automation (/browser)** | `antigravity` | Web & Frontend | `Slash Command` | `/browser` |
| `agy-grill-me` | **Socratic Architectural Interview (/grill-me)** | `antigravity` | Architecture & System | `Slash Command` | `/grill-me` |
| `agy-boost` | **Ultra-Deep Logical Reasoning (/boost)** | `antigravity` | Workflow & Agents | `Slash Command` | `/boost` |
| `agy-teamwork-preview` | **Multi-Agent Swarm Orchestration (/teamwork-preview)** | `antigravity` | Workflow & Agents | `Slash Command` | `/teamwork-preview` |
| `agy-learn` | **Persistent Memory & Rule Learning (/learn)** | `antigravity` | Workflow & Agents | `Slash Command` | `/learn` |
| `agy-generative-ui` | **Generative UI Engine** | `antigravity` | Web & Frontend | `Skill` | `generative_ui` |
| `agy-accidental-data-loss-prevention` | **Data Loss Prevention Guardrail** | `antigravity` | Security & Auth | `Skill` | `accidental-data-loss-prevention` |
| `agy-bigquery-sql` | **BigQuery SQL Query Optimizer** | `antigravity` | Data & Analytics | `Skill` | `bigquery-sql` |
| `agy-bigquery-ai-ml` | **BigQuery ML & In-Database AI** | `antigravity` | Data & Analytics | `Skill` | `bigquery-ai-ml` |
| `agy-bigquery-bigframes` | **BigFrames Python Analytics** | `antigravity` | Data & Analytics | `Skill` | `bigquery-bigframes` |
| `agy-bigquery-graph` | **BigQuery Graph & GQL Topologies** | `antigravity` | Data & Analytics | `Skill` | `bigquery-graph` |
| `agy-discovering-gcp-data-assets` | **Google Cloud Asset Discovery** | `antigravity` | Data & Analytics | `Skill` | `discovering-gcp-data-assets` |
| `agy-dataform-bigquery` | **Dataform & SQLX Pipeline Studio** | `antigravity` | Data & Analytics | `Skill` | `dataform-bigquery` |
| `agy-dbt-bigquery` | **dbt Core BigQuery Modeling** | `antigravity` | Data & Analytics | `Skill` | `dbt-bigquery` |
| `agy-gcp-dataflow` | **Apache Beam on Cloud Dataflow** | `antigravity` | DevOps & Cloud | `Skill` | `gcp-dataflow` |
| `agy-gcp-spark` | **Apache Spark on Serverless Dataproc** | `antigravity` | Data & Analytics | `Skill` | `gcp-spark` |
| `agy-gcp-composer-troubleshooting` | **Cloud Composer & Airflow RCA** | `antigravity` | DevOps & Cloud | `Skill` | `gcp-composer-troubleshooting` |
| `agy-gcp-managed-airflow-dag-authoring` | **Airflow 2 & 3 DAG Authoring** | `antigravity` | DevOps & Cloud | `Skill` | `gcp-managed-airflow-dag-authoring` |
| `agy-gcp-pipeline-orchestration` | **Unified GCP Pipeline Orchestrator** | `antigravity` | DevOps & Cloud | `Skill` | `gcp-pipeline-orchestration` |
| `agy-google-cloud-storage-basics` | **Cloud Storage (GCS) Architecture** | `antigravity` | DevOps & Cloud | `Skill` | `google-cloud-storage-basics` |
| `agy-gcs-security-assessment` | **GCS Security & SAIF Compliance** | `antigravity` | Security & Auth | `Skill` | `gcs-security-assessment` |
| `agy-gcloud-auth-verification` | **GCP ADC & Auth Verification** | `antigravity` | DevOps & Cloud | `Skill` | `gcloud-auth-verification` |
| `agy-firebase-basics` | **Firebase CLI & Multi-Env Setup** | `antigravity` | DevOps & Cloud | `Skill` | `firebase-basics` |
| `agy-firebase-firestore` | **Cloud Firestore NoSQL Architect** | `antigravity` | Data & Analytics | `Skill` | `firebase-firestore` |
| `agy-firebase-auth-basics` | **Firebase Multi-Factor Authentication** | `antigravity` | Security & Auth | `Skill` | `firebase-auth-basics` |
| `agy-firebase-app-hosting-basics` | **Firebase App Hosting Next.js SSR** | `antigravity` | DevOps & Cloud | `Skill` | `firebase-app-hosting-basics` |
| `agy-firebase-security-rules-auditor` | **Firestore Rules Security Auditor** | `antigravity` | Security & Auth | `Skill` | `firebase-security-rules-auditor` |
| `agy-firebase-data-connect` | **Firebase Data Connect & PostgreSQL** | `antigravity` | Data & Analytics | `Skill` | `firebase-data-connect` |
| `agy-firebase-crashlytics` | **Crashlytics Diagnostic Suite** | `antigravity` | Debugging & Tests | `Skill` | `firebase-crashlytics` |
| `agy-dart-add-unit-test` | **Dart Unit Test Generator** | `antigravity` | Debugging & Tests | `Skill` | `dart-add-unit-test` |
| `agy-dart-fix-runtime-errors` | **Dart Runtime Error Resolver** | `antigravity` | Debugging & Tests | `Skill` | `dart-fix-runtime-errors` |
| `agy-dart-run-static-analysis` | **Dart Static Analysis & Lints** | `antigravity` | Code & Refactor | `Skill` | `dart-run-static-analysis` |
| `agy-flutter-apply-architecture-best-practices` | **Flutter Clean Architecture Pro** | `antigravity` | Architecture & System | `Skill` | `flutter-apply-architecture-best-practices` |
| `agy-flutter-fix-layout-issues` | **Flutter RenderFlex Overflow Fixer** | `antigravity` | Debugging & Tests | `Skill` | `flutter-fix-layout-issues` |
| `agy-flutter-add-widget-preview` | **Interactive Flutter Widget Previews** | `antigravity` | Web & Frontend | `Skill` | `flutter-add-widget-preview` |
| `agy-flutter-setup-declarative-routing` | **Flutter GoRouter Declarative Routing** | `antigravity` | Web & Frontend | `Skill` | `flutter-setup-declarative-routing` |
| `agy-gemini-api-dev` | **Google GenAI SDK & Gemini 2.5/3 Pro** | `antigravity` | AI & Multimodal | `Skill` | `gemini-api-dev` |
| `agy-gemini-live-api-dev` | **Gemini Live API & Audio Streaming** | `antigravity` | AI & Multimodal | `Skill` | `gemini-live-api-dev` |
| `agy-gemini-omni-flash-api` | **Gemini Omni Flash Generative Video** | `antigravity` | AI & Multimodal | `Skill` | `gemini-omni-flash-api` |
| `agy-modern-web-guidance` | **Modern Web Standards & Core Web Vitals** | `antigravity` | Web & Frontend | `Skill` | `modern-web-guidance` |
| `agy-ui-ux-pro-max` | **Design System & Micro-Interactions Pro** | `antigravity` | Web & Frontend | `Skill` | `ui-ux-pro-max` |
| `agy-nextjs-best-practices` | **Next.js App Router & Server Actions** | `antigravity` | Web & Frontend | `Skill` | `nextjs-best-practices` |
| `agy-supabase-postgres-pro` | **Supabase & PostgreSQL Mastery** | `antigravity` | Data & Analytics | `Skill` | `supabase-postgres-pro` |
| `agy-test-automation-pro` | **Vitest & Playwright Test Automation** | `antigravity` | Debugging & Tests | `Skill` | `test-automation-pro` |
| `agy-cloudflare-workers-edge` | **Cloudflare Workers & Edge D1** | `antigravity` | DevOps & Cloud | `Skill` | `cloudflare-workers-edge` |
| `agy-graphify` | **Codebase Knowledge Graph Engine** | `antigravity` | Architecture & System | `Skill` | `graphify` |
| `agy-memory-leak-debugging` | **JS & Node Memory Leak Profiler** | `antigravity` | Debugging & Tests | `Skill` | `memory-leak-debugging` |
| `agy-debug-optimize-lcp` | **Largest Contentful Paint (LCP) Optimizer** | `antigravity` | Web & Frontend | `Skill` | `debug-optimize-lcp` |
| `agy-a11y-debugging` | **Accessibility & ARIA Audit Suite** | `antigravity` | Web & Frontend | `Skill` | `a11y-debugging` |
| `agy-alphafold-database-fetch-and-analyze` | **AlphaFold 3D Structure Fetcher** | `antigravity` | Science & Bio | `Skill` | `alphafold-database-fetch-and-analyze` |
| `agy-alphagenome-single-variant-analysis` | **AlphaGenome Variant Analysis** | `antigravity` | Science & Bio | `Skill` | `alphagenome-single-variant-analysis` |
| `agy-alphagenome-variant-impact-score` | **AlphaGenome Variant Impact (AVI)** | `antigravity` | Science & Bio | `Skill` | `alphagenome-variant-impact-score` |
| `agy-chembl-database` | **ChEMBL Bioactive Molecule Explorer** | `antigravity` | Science & Bio | `Skill` | `chembl-database` |
| `agy-clinical-trials-database` | **ClinicalTrials.gov Query Engine** | `antigravity` | Science & Bio | `Skill` | `clinical-trials-database` |
| `agy-clinvar-database` | **ClinVar Pathogenicity Evidence** | `antigravity` | Science & Bio | `Skill` | `clinvar-database` |
| `agy-dbsnp-database` | **NCBI dbSNP Genomic Variant Mapper** | `antigravity` | Science & Bio | `Skill` | `dbsnp-database` |
| `agy-ensembl-database` | **Ensembl Gene & Transcript API** | `antigravity` | Science & Bio | `Skill` | `ensembl-database` |
| `agy-foldseek-structural-search` | **Foldseek 3D Structural Homology** | `antigravity` | Science & Bio | `Skill` | `foldseek-structural-search` |
| `agy-gnomad-database` | **gnomAD Allele Frequency Engine** | `antigravity` | Science & Bio | `Skill` | `gnomad-database` |
| `agy-human-protein-atlas-database` | **Human Protein Atlas Spatial Data** | `antigravity` | Science & Bio | `Skill` | `human-protein-atlas-database` |
| `agy-interpro-database` | **InterPro Protein Family Classifier** | `antigravity` | Science & Bio | `Skill` | `interpro-database` |
| `agy-jaspar-database` | **JASPAR Transcription Factor Profiles** | `antigravity` | Science & Bio | `Skill` | `jaspar-database` |
| `agy-literature-search-arxiv` | **arXiv Academic Paper Search** | `antigravity` | Science & Bio | `Skill` | `literature-search-arxiv` |
| `agy-literature-search-biorxiv` | **bioRxiv & medRxiv Preprints** | `antigravity` | Science & Bio | `Skill` | `literature-search-biorxiv` |
| `agy-literature-search-europepmc` | **Europe PMC Full-Text Downloader** | `antigravity` | Science & Bio | `Skill` | `literature-search-europepmc` |
| `agy-literature-search-openalex` | **OpenAlex Scholarly Graph Explorer** | `antigravity` | Science & Bio | `Skill` | `literature-search-openalex` |
| `agy-ncbi-sequence-fetch` | **NCBI GenBank Sequence Fetcher** | `antigravity` | Science & Bio | `Skill` | `ncbi-sequence-fetch` |
| `agy-openfda-database` | **OpenFDA Adverse Drug Events API** | `antigravity` | Science & Bio | `Skill` | `openfda-database` |
| `agy-opentargets-database` | **Open Targets Drug Discovery Platform** | `antigravity` | Science & Bio | `Skill` | `opentargets-database` |
| `agy-pdb-database` | **RCSB Protein Data Bank (PDB)** | `antigravity` | Science & Bio | `Skill` | `pdb-database` |
| `agy-predictingthepast` | **Aeneas / Ithaca Epigraphic AI** | `antigravity` | Science & Bio | `Skill` | `predictingthepast` |
| `agy-protein-sequence-msa` | **Clustal Omega Multiple Alignment** | `antigravity` | Science & Bio | `Skill` | `protein-sequence-msa` |
| `agy-protein-sequence-similarity-search` | **MMseqs2 Homology Search** | `antigravity` | Science & Bio | `Skill` | `protein-sequence-similarity-search` |
| `agy-pubchem-database` | **PubChem Chemical Database** | `antigravity` | Science & Bio | `Skill` | `pubchem-database` |
| `agy-pubmed-database` | **PubMed Biomedical Literature Search** | `antigravity` | Science & Bio | `Skill` | `pubmed-database` |
| `agy-pymol` | **PyMOL Molecular Graphics Scripting** | `antigravity` | Science & Bio | `Skill` | `pymol` |
| `agy-quickgo-database` | **QuickGO Gene Ontology Annotations** | `antigravity` | Science & Bio | `Skill` | `quickgo-database` |
| `agy-reactome-database` | **Reactome Biological Pathways** | `antigravity` | Science & Bio | `Skill` | `reactome-database` |
| `agy-string-database` | **STRING Protein Interaction Network** | `antigravity` | Science & Bio | `Skill` | `string-database` |
| `agy-ucsc-conservation-and-tfbs` | **UCSC Conservation & TFBS Scores** | `antigravity` | Science & Bio | `Skill` | `ucsc-conservation-and-tfbs` |
| `agy-uniprot-database` | **UniProt Protein Knowledgebase** | `antigravity` | Science & Bio | `Skill` | `uniprot-database` |
| `claude-bug` | **Claude Code Bug Reporter** | `claude` | Debugging & Tests | `Slash Command` | `/bug` |
| `claude-clear` | **Session Context Reset** | `claude` | Workflow & Agents | `Slash Command` | `/clear` |
| `claude-compact` | **Smart Context Compression** | `claude` | Workflow & Agents | `Slash Command` | `/compact` |
| `claude-config` | **Interactive Settings Configuration** | `claude` | Architecture & System | `Slash Command` | `/config` |
| `claude-cost` | **Token & Cost Tracker** | `claude` | Data & Analytics | `Slash Command` | `/cost` |
| `claude-doctor` | **Environment Health Check** | `claude` | Debugging & Tests | `Slash Command` | `/doctor` |
| `claude-exit` | **Clean Session Termination** | `claude` | Workflow & Agents | `Slash Command` | `/exit` |
| `claude-help` | **Command Reference Manual** | `claude` | Workflow & Agents | `Slash Command` | `/help` |
| `claude-init` | **Project CLAUDE.md Initialization** | `claude` | Architecture & System | `Slash Command` | `/init` |
| `claude-login` | **Anthropic OAuth Authentication** | `claude` | Security & Auth | `Slash Command` | `/login` |
| `claude-logout` | **Session Disconnect** | `claude` | Security & Auth | `Slash Command` | `/logout` |
| `claude-memory` | **Persistent Memory Inspection** | `claude` | Workflow & Agents | `Slash Command` | `/memory` |
| `claude-model` | **Model Switcher** | `claude` | Workflow & Agents | `Slash Command` | `/model` |
| `claude-permissions` | **Tool Permission Manager** | `claude` | Security & Auth | `Slash Command` | `/permissions` |
| `claude-pr-comments` | **GitHub PR Comments Importer** | `claude` | Code & Refactor | `Slash Command` | `/pr_comments` |
| `claude-review` | **Deep Codebase Review** | `claude` | Code & Refactor | `Slash Command` | `/review` |
| `claude-search` | **Hybrid Codebase Search** | `claude` | Code & Refactor | `Slash Command` | `/search` |
| `claude-stats` | **Session Performance Analytics** | `claude` | Data & Analytics | `Slash Command` | `/stats` |
| `claude-status` | **Repository & Context Status** | `claude` | Workflow & Agents | `Slash Command` | `/status` |
| `claude-summary` | **Change Synthesis Generator** | `claude` | Code & Refactor | `Slash Command` | `/summary` |
| `claude-terminal-setup` | **Shell Auto-Completion Setup** | `claude` | DevOps & Cloud | `Slash Command` | `/terminal-setup` |
| `claude-test` | **Automated Test Runner** | `claude` | Debugging & Tests | `Slash Command` | `/test` |
| `claude-update` | **CLI Auto-Updater** | `claude` | DevOps & Cloud | `Slash Command` | `/update` |
| `claude-verbose` | **Verbose Debug Logging Toggle** | `claude` | Debugging & Tests | `Slash Command` | `/verbose` |
| `claude-version` | **Version & Build Inspector** | `claude` | Workflow & Agents | `Slash Command` | `/version` |
| `claude-workspace` | **Multi-Root Workspace Manager** | `claude` | Architecture & System | `Slash Command` | `/workspace` |
| `claude-diff` | **Colorized Git Diff Viewer** | `claude` | Code & Refactor | `Slash Command` | `/diff` |
| `claude-commit` | **Conventional Commit Generator** | `claude` | Code & Refactor | `Slash Command` | `/commit` |
| `claude-branch` | **Feature Branch Creator** | `claude` | Code & Refactor | `Slash Command` | `/branch` |
| `claude-stash` | **Git Stash Quick Manager** | `claude` | Code & Refactor | `Slash Command` | `/stash` |
| `claude-patch` | **Patch File Creator & Applier** | `claude` | Code & Refactor | `Slash Command` | `/patch` |
| `claude-rebase` | **Interactive Rebase Assistant** | `claude` | Code & Refactor | `Slash Command` | `/rebase` |
| `claude-undo` | **Last Modification Reverter** | `claude` | Code & Refactor | `Slash Command` | `/undo` |
| `claude-format` | **Global Codebase Formatter** | `claude` | Code & Refactor | `Slash Command` | `/format` |
| `claude-lint` | **Linter Runner & Auto-Fix** | `claude` | Code & Refactor | `Slash Command` | `/lint` |
| `claude-types` | **Strict TypeScript Type-Checker** | `claude` | Code & Refactor | `Slash Command` | `/types` |
| `claude-dead-code` | **Dead Code & Unused Export Detector** | `claude` | Code & Refactor | `Slash Command` | `/dead-code` |
| `claude-refactor` | **Guided Code Refactoring** | `claude` | Code & Refactor | `Slash Command` | `/refactor` |
| `claude-security` | **Dependency Vulnerability Scanner** | `claude` | Security & Auth | `Slash Command` | `/security` |
| `claude-secrets-scan` | **Hardcoded Secrets Detector** | `claude` | Security & Auth | `Slash Command` | `/secrets-scan` |
| `claude-dockerize` | **Multi-Stage Dockerfile Generator** | `claude` | DevOps & Cloud | `Slash Command` | `/dockerize` |
| `claude-k8s-manifest` | **Kubernetes Manifest Generator** | `claude` | DevOps & Cloud | `Slash Command` | `/k8s-manifest` |
| `claude-ci-pipeline` | **GitHub Actions CI/CD Pipeline** | `claude` | DevOps & Cloud | `Slash Command` | `/ci-pipeline` |
| `claude-env-template` | **Documented .env.example Sync** | `claude` | DevOps & Cloud | `Slash Command` | `/env-template` |
| `claude-readme-gen` | **Professional README Generator** | `claude` | Architecture & System | `Slash Command` | `/readme-gen` |
| `claude-changelog-gen` | **SemVer CHANGELOG Generator** | `claude` | Architecture & System | `Slash Command` | `/changelog-gen` |
| `claude-openapi-spec` | **OpenAPI v3.1 Spec Generator** | `claude` | Architecture & System | `Slash Command` | `/openapi-spec` |
| `claude-mock-api` | **MSW & Mock Server Generator** | `claude` | Web & Frontend | `Slash Command` | `/mock-api` |
| `claude-bench` | **Algorithmic Benchmark Suite** | `claude` | Debugging & Tests | `Slash Command` | `/bench` |
| `claude-bundle-size` | **Bundle Analyzer & Tree-Shaker** | `claude` | Web & Frontend | `Slash Command` | `/bundle-size` |
| `claude-pattern-xml-tags-1` | **XML Tag Structured Prompting** | `claude` | Architecture & System | `Prompt Template` | `prompt://claude/xml-tags-1` |
| `claude-pattern-cot-trigger-2` | **Chain-of-Thought <thinking> Trigger** | `claude` | Workflow & Agents | `Prompt Template` | `prompt://claude/cot-trigger-2` |
| `claude-pattern-system-role-inject-3` | **High-Expertise Principal Engineer Persona** | `claude` | Architecture & System | `Prompt Template` | `prompt://claude/system-role-inject-3` |
| `claude-pattern-few-shot-calib-4` | **Few-Shot Calibration Pairs** | `claude` | AI & Multimodal | `Prompt Template` | `prompt://claude/few-shot-calib-4` |
| `claude-pattern-json-schema-guard-5` | **Strict JSON Schema Enforcement** | `claude` | AI & Multimodal | `Prompt Template` | `prompt://claude/json-schema-guard-5` |
| `claude-pattern-multi-turn-eval-6` | **Multi-Turn Dialogue Stress-Testing** | `claude` | Debugging & Tests | `Workflow` | `prompt://claude/multi-turn-eval-6` |
| `claude-pattern-prompt-injection-filter-7` | **Prompt Injection Defense Filter** | `claude` | Security & Auth | `Prompt Template` | `prompt://claude/prompt-injection-filter-7` |
| `claude-pattern-computer-use-agent-8` | **Claude Computer Use OS Automation** | `claude` | Workflow & Agents | `Skill` | `prompt://claude/computer-use-agent-8` |
| `claude-pattern-artifact-renderer-9` | **Interactive Artifact Renderer** | `claude` | Web & Frontend | `Skill` | `prompt://claude/artifact-renderer-9` |
| `claude-pattern-context-cache-optimizer-10` | **Anthropic Context Cache Optimizer** | `claude` | Architecture & System | `Workflow` | `prompt://claude/context-cache-optimizer-10` |
| `claude-pattern-xml-tags-11` | **XML Tag Structured Prompting v2** | `claude` | Architecture & System | `Prompt Template` | `prompt://claude/xml-tags-11` |
| `claude-pattern-cot-trigger-12` | **Chain-of-Thought <thinking> Trigger v2** | `claude` | Workflow & Agents | `Prompt Template` | `prompt://claude/cot-trigger-12` |
| `claude-pattern-system-role-inject-13` | **High-Expertise Principal Engineer Persona v2** | `claude` | Architecture & System | `Prompt Template` | `prompt://claude/system-role-inject-13` |
| `claude-pattern-few-shot-calib-14` | **Few-Shot Calibration Pairs v2** | `claude` | AI & Multimodal | `Prompt Template` | `prompt://claude/few-shot-calib-14` |
| `claude-pattern-json-schema-guard-15` | **Strict JSON Schema Enforcement v2** | `claude` | AI & Multimodal | `Prompt Template` | `prompt://claude/json-schema-guard-15` |
| `claude-pattern-multi-turn-eval-16` | **Multi-Turn Dialogue Stress-Testing v2** | `claude` | Debugging & Tests | `Workflow` | `prompt://claude/multi-turn-eval-16` |
| `claude-pattern-prompt-injection-filter-17` | **Prompt Injection Defense Filter v2** | `claude` | Security & Auth | `Prompt Template` | `prompt://claude/prompt-injection-filter-17` |
| `claude-pattern-computer-use-agent-18` | **Claude Computer Use OS Automation v2** | `claude` | Workflow & Agents | `Skill` | `prompt://claude/computer-use-agent-18` |
| `claude-pattern-artifact-renderer-19` | **Interactive Artifact Renderer v2** | `claude` | Web & Frontend | `Skill` | `prompt://claude/artifact-renderer-19` |
| `claude-pattern-context-cache-optimizer-20` | **Anthropic Context Cache Optimizer v2** | `claude` | Architecture & System | `Workflow` | `prompt://claude/context-cache-optimizer-20` |
| `claude-pattern-xml-tags-21` | **XML Tag Structured Prompting v3** | `claude` | Architecture & System | `Prompt Template` | `prompt://claude/xml-tags-21` |
| `claude-pattern-cot-trigger-22` | **Chain-of-Thought <thinking> Trigger v3** | `claude` | Workflow & Agents | `Prompt Template` | `prompt://claude/cot-trigger-22` |
| `claude-pattern-system-role-inject-23` | **High-Expertise Principal Engineer Persona v3** | `claude` | Architecture & System | `Prompt Template` | `prompt://claude/system-role-inject-23` |
| `claude-pattern-few-shot-calib-24` | **Few-Shot Calibration Pairs v3** | `claude` | AI & Multimodal | `Prompt Template` | `prompt://claude/few-shot-calib-24` |
| `claude-pattern-json-schema-guard-25` | **Strict JSON Schema Enforcement v3** | `claude` | AI & Multimodal | `Prompt Template` | `prompt://claude/json-schema-guard-25` |
| `claude-pattern-multi-turn-eval-26` | **Multi-Turn Dialogue Stress-Testing v3** | `claude` | Debugging & Tests | `Workflow` | `prompt://claude/multi-turn-eval-26` |
| `claude-pattern-prompt-injection-filter-27` | **Prompt Injection Defense Filter v3** | `claude` | Security & Auth | `Prompt Template` | `prompt://claude/prompt-injection-filter-27` |
| `claude-pattern-computer-use-agent-28` | **Claude Computer Use OS Automation v3** | `claude` | Workflow & Agents | `Skill` | `prompt://claude/computer-use-agent-28` |
| `claude-pattern-artifact-renderer-29` | **Interactive Artifact Renderer v3** | `claude` | Web & Frontend | `Skill` | `prompt://claude/artifact-renderer-29` |
| `claude-pattern-context-cache-optimizer-30` | **Anthropic Context Cache Optimizer v3** | `claude` | Architecture & System | `Workflow` | `prompt://claude/context-cache-optimizer-30` |
| `claude-pattern-xml-tags-31` | **XML Tag Structured Prompting v4** | `claude` | Architecture & System | `Prompt Template` | `prompt://claude/xml-tags-31` |
| `claude-pattern-cot-trigger-32` | **Chain-of-Thought <thinking> Trigger v4** | `claude` | Workflow & Agents | `Prompt Template` | `prompt://claude/cot-trigger-32` |
| `claude-pattern-system-role-inject-33` | **High-Expertise Principal Engineer Persona v4** | `claude` | Architecture & System | `Prompt Template` | `prompt://claude/system-role-inject-33` |
| `claude-pattern-few-shot-calib-34` | **Few-Shot Calibration Pairs v4** | `claude` | AI & Multimodal | `Prompt Template` | `prompt://claude/few-shot-calib-34` |
| `claude-pattern-json-schema-guard-35` | **Strict JSON Schema Enforcement v4** | `claude` | AI & Multimodal | `Prompt Template` | `prompt://claude/json-schema-guard-35` |
| `claude-pattern-multi-turn-eval-36` | **Multi-Turn Dialogue Stress-Testing v4** | `claude` | Debugging & Tests | `Workflow` | `prompt://claude/multi-turn-eval-36` |
| `claude-pattern-prompt-injection-filter-37` | **Prompt Injection Defense Filter v4** | `claude` | Security & Auth | `Prompt Template` | `prompt://claude/prompt-injection-filter-37` |
| `claude-pattern-computer-use-agent-38` | **Claude Computer Use OS Automation v4** | `claude` | Workflow & Agents | `Skill` | `prompt://claude/computer-use-agent-38` |
| `claude-pattern-artifact-renderer-39` | **Interactive Artifact Renderer v4** | `claude` | Web & Frontend | `Skill` | `prompt://claude/artifact-renderer-39` |
| `claude-pattern-context-cache-optimizer-40` | **Anthropic Context Cache Optimizer v4** | `claude` | Architecture & System | `Workflow` | `prompt://claude/context-cache-optimizer-40` |
| `claude-pattern-xml-tags-41` | **XML Tag Structured Prompting v5** | `claude` | Architecture & System | `Prompt Template` | `prompt://claude/xml-tags-41` |
| `claude-pattern-cot-trigger-42` | **Chain-of-Thought <thinking> Trigger v5** | `claude` | Workflow & Agents | `Prompt Template` | `prompt://claude/cot-trigger-42` |
| `claude-pattern-system-role-inject-43` | **High-Expertise Principal Engineer Persona v5** | `claude` | Architecture & System | `Prompt Template` | `prompt://claude/system-role-inject-43` |
| `claude-pattern-few-shot-calib-44` | **Few-Shot Calibration Pairs v5** | `claude` | AI & Multimodal | `Prompt Template` | `prompt://claude/few-shot-calib-44` |
| `claude-pattern-json-schema-guard-45` | **Strict JSON Schema Enforcement v5** | `claude` | AI & Multimodal | `Prompt Template` | `prompt://claude/json-schema-guard-45` |
| `claude-pattern-multi-turn-eval-46` | **Multi-Turn Dialogue Stress-Testing v5** | `claude` | Debugging & Tests | `Workflow` | `prompt://claude/multi-turn-eval-46` |
| `claude-pattern-prompt-injection-filter-47` | **Prompt Injection Defense Filter v5** | `claude` | Security & Auth | `Prompt Template` | `prompt://claude/prompt-injection-filter-47` |
| `claude-pattern-computer-use-agent-48` | **Claude Computer Use OS Automation v5** | `claude` | Workflow & Agents | `Skill` | `prompt://claude/computer-use-agent-48` |
| `claude-pattern-artifact-renderer-49` | **Interactive Artifact Renderer v5** | `claude` | Web & Frontend | `Skill` | `prompt://claude/artifact-renderer-49` |
| `claude-pattern-context-cache-optimizer-50` | **Anthropic Context Cache Optimizer v5** | `claude` | Architecture & System | `Workflow` | `prompt://claude/context-cache-optimizer-50` |
| `claude-pattern-xml-tags-51` | **XML Tag Structured Prompting v6** | `claude` | Architecture & System | `Prompt Template` | `prompt://claude/xml-tags-51` |
| `claude-pattern-cot-trigger-52` | **Chain-of-Thought <thinking> Trigger v6** | `claude` | Workflow & Agents | `Prompt Template` | `prompt://claude/cot-trigger-52` |
| `claude-pattern-system-role-inject-53` | **High-Expertise Principal Engineer Persona v6** | `claude` | Architecture & System | `Prompt Template` | `prompt://claude/system-role-inject-53` |
| `claude-pattern-few-shot-calib-54` | **Few-Shot Calibration Pairs v6** | `claude` | AI & Multimodal | `Prompt Template` | `prompt://claude/few-shot-calib-54` |
| `claude-pattern-json-schema-guard-55` | **Strict JSON Schema Enforcement v6** | `claude` | AI & Multimodal | `Prompt Template` | `prompt://claude/json-schema-guard-55` |
| `claude-pattern-multi-turn-eval-56` | **Multi-Turn Dialogue Stress-Testing v6** | `claude` | Debugging & Tests | `Workflow` | `prompt://claude/multi-turn-eval-56` |
| `claude-pattern-prompt-injection-filter-57` | **Prompt Injection Defense Filter v6** | `claude` | Security & Auth | `Prompt Template` | `prompt://claude/prompt-injection-filter-57` |
| `claude-pattern-computer-use-agent-58` | **Claude Computer Use OS Automation v6** | `claude` | Workflow & Agents | `Skill` | `prompt://claude/computer-use-agent-58` |
| `claude-pattern-artifact-renderer-59` | **Interactive Artifact Renderer v6** | `claude` | Web & Frontend | `Skill` | `prompt://claude/artifact-renderer-59` |
| `claude-pattern-context-cache-optimizer-60` | **Anthropic Context Cache Optimizer v6** | `claude` | Architecture & System | `Workflow` | `prompt://claude/context-cache-optimizer-60` |
| `codebase` | **Global Codebase Vector Index (@codebase)** | `cursor` | Code & Refactor | `Extension` | `@codebase` |
| `web` | **Live Web Search (@web)** | `cursor` | Web & Frontend | `Extension` | `@web` |
| `docs` | **Official Framework Documentation (@docs)** | `cursor` | Architecture & System | `Extension` | `@docs` |
| `file` | **Target File Inclusion (@file)** | `cursor` | Code & Refactor | `Extension` | `@file` |
| `folder` | **Target Directory Inclusion (@folder)** | `cursor` | Code & Refactor | `Extension` | `@folder` |
| `git` | **Git History & Diff Context (@git)** | `cursor` | Code & Refactor | `Extension` | `@git` |
| `definitions` | **LSP Type Definition Lookup (@definitions)** | `cursor` | Code & Refactor | `Extension` | `@definitions` |
| `terminal` | **Terminal Output Capture (@terminal)** | `cursor` | Debugging & Tests | `Extension` | `@terminal` |
| `-cursorrules-ts-strict` | **Cursor TypeScript Strict & No-Any Rule** | `cursor` | Code & Refactor | `Rule / Prompt` | `.cursorrules:ts-strict` |
| `-cursorrules-nextjs-rsc` | **Next.js 15 Server Components Rule** | `cursor` | Web & Frontend | `Rule / Prompt` | `.cursorrules:nextjs-rsc` |
| `-cursorrules-tailwind-v4` | **Tailwind CSS v4 Clean UI Rule** | `cursor` | Web & Frontend | `Rule / Prompt` | `.cursorrules:tailwind-v4` |
| `-cursorrules-fastapi-async` | **FastAPI Async & Pydantic v2 Rule** | `cursor` | Architecture & System | `Rule / Prompt` | `.cursorrules:fastapi-async` |
| `-cursorrules-rust-safety` | **Rust Memory Safety & Clippy Rule** | `cursor` | Code & Refactor | `Rule / Prompt` | `.cursorrules:rust-safety` |
| `-cursorrules-go-idiomatic` | **Go Idiomatic Concurrency Rule** | `cursor` | Code & Refactor | `Rule / Prompt` | `.cursorrules:go-idiomatic` |
| `-cursorrules-prisma-perf` | **Prisma ORM Performance Guard** | `cursor` | Data & Analytics | `Rule / Prompt` | `.cursorrules:prisma-perf` |
| `-cursorrules-tdd-vitest` | **Test-Driven Development (TDD) Rule** | `cursor` | Debugging & Tests | `Rule / Prompt` | `.cursorrules:tdd-vitest` |
| `-cursorrules-security-owasp` | **OWASP Top 10 Security Guardrail** | `cursor` | Security & Auth | `Rule / Prompt` | `.cursorrules:security-owasp` |
| `-cursorrules-a11y-wcag` | **WCAG AAA Web Accessibility Standard** | `cursor` | Web & Frontend | `Rule / Prompt` | `.cursorrules:a11y-wcag` |
| `gh-copilot-suggest` | **GitHub Copilot Suggest Shell (/suggest)** | `codex` | DevOps & Cloud | `Slash Command` | `gh copilot suggest` |
| `gh-copilot-explain` | **GitHub Copilot Explain Command (/explain)** | `codex` | DevOps & Cloud | `Slash Command` | `gh copilot explain` |
| `codex-edit` | **Codex Inline Code Editor (/edit)** | `codex` | Code & Refactor | `Slash Command` | `/edit` |
| `codex-generate` | **Codex Code Generator (/generate)** | `codex` | Code & Refactor | `Slash Command` | `/generate` |
| `codex-fix` | **Codex Quick Bug Fixer (/fix)** | `codex` | Debugging & Tests | `Slash Command` | `/fix` |
| `codex-doc` | **Codex JSDoc / Docstring Generator (/doc)** | `codex` | Architecture & System | `Slash Command` | `/doc` |
| `codex-translate` | **Codex Multi-Language Code Converter (/translate)** | `codex` | Code & Refactor | `Slash Command` | `/translate` |
| `codex-bench` | **Codex Benchmark Suite Generator (/bench)** | `codex` | Debugging & Tests | `Slash Command` | `/bench` |
| `codex-optimize` | **Codex Algorithmic Optimizer (/optimize)** | `codex` | Code & Refactor | `Slash Command` | `/optimize` |
| `codex-migrate` | **Codex Framework Migration Wizard (/migrate)** | `codex` | Code & Refactor | `Slash Command` | `/migrate` |
| `codex-cursor-rule-1` | **Codex Engineering Directive #1** | `codex` | Code & Refactor | `Rule / Prompt` | `/codex-rule-1` |
| `codex-cursor-rule-2` | **Codex Engineering Directive #2** | `codex` | Code & Refactor | `Rule / Prompt` | `/codex-rule-2` |
| `codex-cursor-rule-3` | **Codex Engineering Directive #3** | `codex` | Code & Refactor | `Rule / Prompt` | `/codex-rule-3` |
| `codex-cursor-rule-4` | **Codex Engineering Directive #4** | `codex` | Code & Refactor | `Rule / Prompt` | `/codex-rule-4` |
| `codex-cursor-rule-5` | **Codex Engineering Directive #5** | `codex` | Code & Refactor | `Rule / Prompt` | `/codex-rule-5` |
| `codex-cursor-rule-6` | **Codex Engineering Directive #6** | `codex` | Code & Refactor | `Rule / Prompt` | `/codex-rule-6` |
| `codex-cursor-rule-7` | **Codex Engineering Directive #7** | `codex` | Code & Refactor | `Rule / Prompt` | `/codex-rule-7` |
| `codex-cursor-rule-8` | **Codex Engineering Directive #8** | `codex` | Code & Refactor | `Rule / Prompt` | `/codex-rule-8` |
| `codex-cursor-rule-9` | **Codex Engineering Directive #9** | `codex` | Code & Refactor | `Rule / Prompt` | `/codex-rule-9` |
| `codex-cursor-rule-10` | **Codex Engineering Directive #10** | `codex` | Code & Refactor | `Rule / Prompt` | `/codex-rule-10` |
| `codex-cursor-rule-11` | **Codex Engineering Directive #11** | `codex` | Code & Refactor | `Rule / Prompt` | `/codex-rule-11` |
| `codex-cursor-rule-12` | **Codex Engineering Directive #12** | `codex` | Code & Refactor | `Rule / Prompt` | `/codex-rule-12` |
| `codex-cursor-rule-13` | **Codex Engineering Directive #13** | `codex` | Code & Refactor | `Rule / Prompt` | `/codex-rule-13` |
| `codex-cursor-rule-14` | **Codex Engineering Directive #14** | `codex` | Code & Refactor | `Rule / Prompt` | `/codex-rule-14` |
| `codex-cursor-rule-15` | **Codex Engineering Directive #15** | `codex` | Code & Refactor | `Rule / Prompt` | `/codex-rule-15` |
| `codex-cursor-rule-16` | **Codex Engineering Directive #16** | `codex` | Code & Refactor | `Rule / Prompt` | `/codex-rule-16` |
| `codex-cursor-rule-17` | **Codex Engineering Directive #17** | `codex` | Code & Refactor | `Rule / Prompt` | `/codex-rule-17` |
| `codex-cursor-rule-18` | **Codex Engineering Directive #18** | `codex` | Code & Refactor | `Rule / Prompt` | `/codex-rule-18` |
| `codex-cursor-rule-19` | **Codex Engineering Directive #19** | `codex` | Code & Refactor | `Rule / Prompt` | `/codex-rule-19` |
| `codex-cursor-rule-20` | **Codex Engineering Directive #20** | `codex` | Code & Refactor | `Rule / Prompt` | `/codex-rule-20` |
| `codex-cursor-rule-21` | **Codex Engineering Directive #21** | `codex` | Code & Refactor | `Rule / Prompt` | `/codex-rule-21` |
| `codex-cursor-rule-22` | **Codex Engineering Directive #22** | `codex` | Code & Refactor | `Rule / Prompt` | `/codex-rule-22` |
| `codex-cursor-rule-23` | **Codex Engineering Directive #23** | `codex` | Code & Refactor | `Rule / Prompt` | `/codex-rule-23` |
| `codex-cursor-rule-24` | **Codex Engineering Directive #24** | `codex` | Code & Refactor | `Rule / Prompt` | `/codex-rule-24` |
| `codex-cursor-rule-25` | **Codex Engineering Directive #25** | `codex` | Code & Refactor | `Rule / Prompt` | `/codex-rule-25` |
| `codex-cursor-rule-26` | **Codex Engineering Directive #26** | `codex` | Code & Refactor | `Rule / Prompt` | `/codex-rule-26` |
| `codex-cursor-rule-27` | **Codex Engineering Directive #27** | `codex` | Code & Refactor | `Rule / Prompt` | `/codex-rule-27` |
| `codex-cursor-rule-28` | **Codex Engineering Directive #28** | `codex` | Code & Refactor | `Rule / Prompt` | `/codex-rule-28` |
| `codex-cursor-rule-29` | **Codex Engineering Directive #29** | `codex` | Code & Refactor | `Rule / Prompt` | `/codex-rule-29` |
| `codex-cursor-rule-30` | **Codex Engineering Directive #30** | `codex` | Code & Refactor | `Rule / Prompt` | `/codex-rule-30` |
| `codex-cursor-rule-31` | **Codex Engineering Directive #31** | `codex` | Code & Refactor | `Rule / Prompt` | `/codex-rule-31` |
| `codex-cursor-rule-32` | **Codex Engineering Directive #32** | `codex` | Code & Refactor | `Rule / Prompt` | `/codex-rule-32` |
| `codex-cursor-rule-33` | **Codex Engineering Directive #33** | `codex` | Code & Refactor | `Rule / Prompt` | `/codex-rule-33` |
| `codex-cursor-rule-34` | **Codex Engineering Directive #34** | `codex` | Code & Refactor | `Rule / Prompt` | `/codex-rule-34` |
| `codex-cursor-rule-35` | **Codex Engineering Directive #35** | `codex` | Code & Refactor | `Rule / Prompt` | `/codex-rule-35` |
| `codex-cursor-rule-36` | **Codex Engineering Directive #36** | `codex` | Code & Refactor | `Rule / Prompt` | `/codex-rule-36` |
| `codex-cursor-rule-37` | **Codex Engineering Directive #37** | `codex` | Code & Refactor | `Rule / Prompt` | `/codex-rule-37` |
| `codex-cursor-rule-38` | **Codex Engineering Directive #38** | `codex` | Code & Refactor | `Rule / Prompt` | `/codex-rule-38` |
| `codex-cursor-rule-39` | **Codex Engineering Directive #39** | `codex` | Code & Refactor | `Rule / Prompt` | `/codex-rule-39` |
| `codex-cursor-rule-40` | **Codex Engineering Directive #40** | `codex` | Code & Refactor | `Rule / Prompt` | `/codex-rule-40` |
| `codex-cursor-rule-41` | **Codex Engineering Directive #41** | `codex` | Code & Refactor | `Rule / Prompt` | `/codex-rule-41` |
| `codex-cursor-rule-42` | **Codex Engineering Directive #42** | `codex` | Code & Refactor | `Rule / Prompt` | `/codex-rule-42` |
| `codex-cursor-rule-43` | **Codex Engineering Directive #43** | `codex` | Code & Refactor | `Rule / Prompt` | `/codex-rule-43` |
| `codex-cursor-rule-44` | **Codex Engineering Directive #44** | `codex` | Code & Refactor | `Rule / Prompt` | `/codex-rule-44` |
| `codex-cursor-rule-45` | **Codex Engineering Directive #45** | `codex` | Code & Refactor | `Rule / Prompt` | `/codex-rule-45` |
| `codex-cursor-rule-46` | **Codex Engineering Directive #46** | `codex` | Code & Refactor | `Rule / Prompt` | `/codex-rule-46` |
| `codex-cursor-rule-47` | **Codex Engineering Directive #47** | `codex` | Code & Refactor | `Rule / Prompt` | `/codex-rule-47` |
| `codex-cursor-rule-48` | **Codex Engineering Directive #48** | `codex` | Code & Refactor | `Rule / Prompt` | `/codex-rule-48` |
| `codex-cursor-rule-49` | **Codex Engineering Directive #49** | `codex` | Code & Refactor | `Rule / Prompt` | `/codex-rule-49` |
| `codex-cursor-rule-50` | **Codex Engineering Directive #50** | `codex` | Code & Refactor | `Rule / Prompt` | `/codex-rule-50` |
| `codex-cursor-rule-51` | **Codex Engineering Directive #51** | `codex` | Code & Refactor | `Rule / Prompt` | `/codex-rule-51` |
| `codex-cursor-rule-52` | **Codex Engineering Directive #52** | `codex` | Code & Refactor | `Rule / Prompt` | `/codex-rule-52` |
| `codex-cursor-rule-53` | **Codex Engineering Directive #53** | `codex` | Code & Refactor | `Rule / Prompt` | `/codex-rule-53` |
| `codex-cursor-rule-54` | **Codex Engineering Directive #54** | `codex` | Code & Refactor | `Rule / Prompt` | `/codex-rule-54` |
| `codex-cursor-rule-55` | **Codex Engineering Directive #55** | `codex` | Code & Refactor | `Rule / Prompt` | `/codex-rule-55` |
| `codex-cursor-rule-56` | **Codex Engineering Directive #56** | `codex` | Code & Refactor | `Rule / Prompt` | `/codex-rule-56` |
| `codex-cursor-rule-57` | **Codex Engineering Directive #57** | `codex` | Code & Refactor | `Rule / Prompt` | `/codex-rule-57` |
| `codex-cursor-rule-58` | **Codex Engineering Directive #58** | `codex` | Code & Refactor | `Rule / Prompt` | `/codex-rule-58` |
| `codex-cursor-rule-59` | **Codex Engineering Directive #59** | `codex` | Code & Refactor | `Rule / Prompt` | `/codex-rule-59` |
| `codex-cursor-rule-60` | **Codex Engineering Directive #60** | `codex` | Code & Refactor | `Rule / Prompt` | `/codex-rule-60` |
| `codex-cursor-rule-61` | **Codex Engineering Directive #61** | `codex` | Code & Refactor | `Rule / Prompt` | `/codex-rule-61` |
| `codex-cursor-rule-62` | **Codex Engineering Directive #62** | `codex` | Code & Refactor | `Rule / Prompt` | `/codex-rule-62` |
| `codex-cursor-rule-63` | **Codex Engineering Directive #63** | `codex` | Code & Refactor | `Rule / Prompt` | `/codex-rule-63` |
| `codex-cursor-rule-64` | **Codex Engineering Directive #64** | `codex` | Code & Refactor | `Rule / Prompt` | `/codex-rule-64` |
| `codex-cursor-rule-65` | **Codex Engineering Directive #65** | `codex` | Code & Refactor | `Rule / Prompt` | `/codex-rule-65` |
| `codex-cursor-rule-66` | **Codex Engineering Directive #66** | `codex` | Code & Refactor | `Rule / Prompt` | `/codex-rule-66` |
| `codex-cursor-rule-67` | **Codex Engineering Directive #67** | `codex` | Code & Refactor | `Rule / Prompt` | `/codex-rule-67` |
| `codex-cursor-rule-68` | **Codex Engineering Directive #68** | `codex` | Code & Refactor | `Rule / Prompt` | `/codex-rule-68` |
| `codex-cursor-rule-69` | **Codex Engineering Directive #69** | `codex` | Code & Refactor | `Rule / Prompt` | `/codex-rule-69` |
| `codex-cursor-rule-70` | **Codex Engineering Directive #70** | `codex` | Code & Refactor | `Rule / Prompt` | `/codex-rule-70` |
| `codex-cursor-rule-71` | **Codex Engineering Directive #71** | `codex` | Code & Refactor | `Rule / Prompt` | `/codex-rule-71` |
| `codex-cursor-rule-72` | **Codex Engineering Directive #72** | `codex` | Code & Refactor | `Rule / Prompt` | `/codex-rule-72` |
| `codex-cursor-rule-73` | **Codex Engineering Directive #73** | `codex` | Code & Refactor | `Rule / Prompt` | `/codex-rule-73` |
| `codex-cursor-rule-74` | **Codex Engineering Directive #74** | `codex` | Code & Refactor | `Rule / Prompt` | `/codex-rule-74` |
| `codex-cursor-rule-75` | **Codex Engineering Directive #75** | `codex` | Code & Refactor | `Rule / Prompt` | `/codex-rule-75` |
| `codex-cursor-rule-76` | **Codex Engineering Directive #76** | `codex` | Code & Refactor | `Rule / Prompt` | `/codex-rule-76` |
| `codex-cursor-rule-77` | **Codex Engineering Directive #77** | `codex` | Code & Refactor | `Rule / Prompt` | `/codex-rule-77` |
| `codex-cursor-rule-78` | **Codex Engineering Directive #78** | `codex` | Code & Refactor | `Rule / Prompt` | `/codex-rule-78` |
| `codex-cursor-rule-79` | **Codex Engineering Directive #79** | `codex` | Code & Refactor | `Rule / Prompt` | `/codex-rule-79` |
| `codex-cursor-rule-80` | **Codex Engineering Directive #80** | `codex` | Code & Refactor | `Rule / Prompt` | `/codex-rule-80` |
| `codex-cursor-rule-81` | **Codex Engineering Directive #81** | `codex` | Code & Refactor | `Rule / Prompt` | `/codex-rule-81` |
| `codex-cursor-rule-82` | **Codex Engineering Directive #82** | `codex` | Code & Refactor | `Rule / Prompt` | `/codex-rule-82` |
| `mcp-server-filesystem` | **MCP Filesystem Server** | `mcp` | Architecture & System | `MCP Server` | `mcp://filesystem` |
| `mcp-server-git` | **MCP Git Version Control** | `mcp` | Code & Refactor | `MCP Server` | `mcp://git` |
| `mcp-server-github` | **MCP GitHub API Integration** | `mcp` | DevOps & Cloud | `MCP Server` | `mcp://github` |
| `mcp-server-gitlab` | **MCP GitLab Enterprise Server** | `mcp` | DevOps & Cloud | `MCP Server` | `mcp://gitlab` |
| `mcp-server-postgres` | **MCP PostgreSQL Database** | `mcp` | Data & Analytics | `MCP Server` | `mcp://postgres` |
| `mcp-server-sqlite` | **MCP SQLite Embedded Database** | `mcp` | Data & Analytics | `MCP Server` | `mcp://sqlite` |
| `mcp-server-mysql` | **MCP MySQL & MariaDB Server** | `mcp` | Data & Analytics | `MCP Server` | `mcp://mysql` |
| `mcp-server-mongodb` | **MCP MongoDB Document Store** | `mcp` | Data & Analytics | `MCP Server` | `mcp://mongodb` |
| `mcp-server-redis` | **MCP Redis In-Memory Cache** | `mcp` | Data & Analytics | `MCP Server` | `mcp://redis` |
| `mcp-server-puppeteer` | **MCP Puppeteer Web Automation** | `mcp` | Web & Frontend | `MCP Server` | `mcp://puppeteer` |
| `mcp-server-playwright` | **MCP Playwright Multi-Browser** | `mcp` | Web & Frontend | `MCP Server` | `mcp://playwright` |
| `mcp-server-brave-search` | **MCP Brave Web Search API** | `mcp` | Web & Frontend | `MCP Server` | `mcp://brave-search` |
| `mcp-server-tavily` | **MCP Tavily AI Research Engine** | `mcp` | AI & Multimodal | `MCP Server` | `mcp://tavily` |
| `mcp-server-fetch` | **MCP Web Fetch & Markdown Converter** | `mcp` | Web & Frontend | `MCP Server` | `mcp://fetch` |
| `mcp-server-memory` | **MCP Knowledge Graph Memory** | `mcp` | AI & Multimodal | `MCP Server` | `mcp://memory` |
| `mcp-server-sequential-thinking` | **MCP Sequential Thinking Dynamic** | `mcp` | Workflow & Agents | `MCP Server` | `mcp://sequential-thinking` |
| `mcp-server-google-drive` | **MCP Google Drive Documents** | `mcp` | Workflow & Agents | `MCP Server` | `mcp://google-drive` |
| `mcp-server-google-maps` | **MCP Google Maps Platform** | `mcp` | Web & Frontend | `MCP Server` | `mcp://google-maps` |
| `mcp-server-google-calendar` | **MCP Google Calendar Scheduler** | `mcp` | Workflow & Agents | `MCP Server` | `mcp://google-calendar` |
| `mcp-server-gmail` | **MCP Gmail API Connector** | `mcp` | Workflow & Agents | `MCP Server` | `mcp://gmail` |
| `mcp-server-slack` | **MCP Slack Team Communication** | `mcp` | Workflow & Agents | `MCP Server` | `mcp://slack` |
| `mcp-server-discord` | **MCP Discord Bot Integration** | `mcp` | Workflow & Agents | `MCP Server` | `mcp://discord` |
| `mcp-server-docker` | **MCP Docker Engine Management** | `mcp` | DevOps & Cloud | `MCP Server` | `mcp://docker` |
| `mcp-server-kubernetes` | **MCP Kubernetes Cluster Control** | `mcp` | DevOps & Cloud | `MCP Server` | `mcp://kubernetes` |
| `mcp-server-sentry` | **MCP Sentry Error Tracking** | `mcp` | Debugging & Tests | `MCP Server` | `mcp://sentry` |
| `mcp-server-datadog` | **MCP Datadog Observability** | `mcp` | DevOps & Cloud | `MCP Server` | `mcp://datadog` |
| `mcp-server-cloudflare` | **MCP Cloudflare DNS & Workers** | `mcp` | DevOps & Cloud | `MCP Server` | `mcp://cloudflare` |
| `mcp-server-linear` | **MCP Linear Issue Tracking** | `mcp` | Workflow & Agents | `MCP Server` | `mcp://linear` |
| `mcp-server-jira` | **MCP Atlassian Jira Agile** | `mcp` | Workflow & Agents | `MCP Server` | `mcp://jira` |
| `mcp-server-notion` | **MCP Notion Workspace API** | `mcp` | Workflow & Agents | `MCP Server` | `mcp://notion` |
| `mcp-server-obsidian` | **MCP Obsidian Local Markdown Vault** | `mcp` | Architecture & System | `MCP Server` | `mcp://obsidian` |
| `mcp-server-airtable` | **MCP Airtable Relational Base** | `mcp` | Data & Analytics | `MCP Server` | `mcp://airtable` |
| `mcp-server-stripe` | **MCP Stripe Payment Gateway** | `mcp` | Security & Auth | `MCP Server` | `mcp://stripe` |
| `mcp-server-supabase` | **MCP Supabase Backend Platform** | `mcp` | Data & Analytics | `MCP Server` | `mcp://supabase` |
| `mcp-server-qdrant` | **MCP Qdrant Vector Database** | `mcp` | AI & Multimodal | `MCP Server` | `mcp://qdrant` |
| `mcp-server-pinecone` | **MCP Pinecone Serverless Vector Index** | `mcp` | AI & Multimodal | `MCP Server` | `mcp://pinecone` |
| `mcp-server-weaviate` | **MCP Weaviate Semantic Search** | `mcp` | AI & Multimodal | `MCP Server` | `mcp://weaviate` |
| `mcp-server-chroma` | **MCP ChromaDB Embedded Vector Store** | `mcp` | AI & Multimodal | `MCP Server` | `mcp://chroma` |
| `mcp-server-duckdb` | **MCP DuckDB In-Process SQL Analytics** | `mcp` | Data & Analytics | `MCP Server` | `mcp://duckdb` |
| `mcp-server-snowflake` | **MCP Snowflake Cloud Data Warehouse** | `mcp` | Data & Analytics | `MCP Server` | `mcp://snowflake` |
| `mcp-server-databricks` | **MCP Databricks Lakehouse Platform** | `mcp` | Data & Analytics | `MCP Server` | `mcp://databricks` |
| `mcp-server-arxiv` | **MCP arXiv Academic Papers** | `mcp` | Science & Bio | `MCP Server` | `mcp://arxiv` |
| `mcp-server-weather` | **MCP Weather Forecast API** | `mcp` | Web & Frontend | `MCP Server` | `mcp://weather` |
| `mcp-server-everart` | **MCP EverArt Generative Image Studio** | `mcp` | AI & Multimodal | `MCP Server` | `mcp://everart` |
| `community-mcp-1` | **Community MCP Server #1** | `mcp` | Code & Refactor | `MCP Server` | `mcp://community-1` |
| `community-mcp-2` | **Community MCP Server #2** | `mcp` | Debugging & Tests | `MCP Server` | `mcp://community-2` |
| `community-mcp-3` | **Community MCP Server #3** | `mcp` | MCP & Integrations | `MCP Server` | `mcp://community-3` |
| `community-mcp-4` | **Community MCP Server #4** | `mcp` | Architecture & System | `MCP Server` | `mcp://community-4` |
| `community-mcp-5` | **Community MCP Server #5** | `mcp` | Web & Frontend | `MCP Server` | `mcp://community-5` |
| `community-mcp-6` | **Community MCP Server #6** | `mcp` | Data & Analytics | `MCP Server` | `mcp://community-6` |
| `community-mcp-7` | **Community MCP Server #7** | `mcp` | DevOps & Cloud | `MCP Server` | `mcp://community-7` |
| `community-mcp-8` | **Community MCP Server #8** | `mcp` | Security & Auth | `MCP Server` | `mcp://community-8` |
| `community-mcp-9` | **Community MCP Server #9** | `mcp` | AI & Multimodal | `MCP Server` | `mcp://community-9` |
| `community-mcp-10` | **Community MCP Server #10** | `mcp` | Science & Bio | `MCP Server` | `mcp://community-10` |
| `community-mcp-11` | **Community MCP Server #11** | `mcp` | Workflow & Agents | `MCP Server` | `mcp://community-11` |
| `community-mcp-12` | **Community MCP Server #12** | `mcp` | Code & Refactor | `MCP Server` | `mcp://community-12` |
| `community-mcp-13` | **Community MCP Server #13** | `mcp` | Debugging & Tests | `MCP Server` | `mcp://community-13` |
| `community-mcp-14` | **Community MCP Server #14** | `mcp` | MCP & Integrations | `MCP Server` | `mcp://community-14` |
| `community-mcp-15` | **Community MCP Server #15** | `mcp` | Architecture & System | `MCP Server` | `mcp://community-15` |
| `community-mcp-16` | **Community MCP Server #16** | `mcp` | Web & Frontend | `MCP Server` | `mcp://community-16` |
| `community-mcp-17` | **Community MCP Server #17** | `mcp` | Data & Analytics | `MCP Server` | `mcp://community-17` |
| `community-mcp-18` | **Community MCP Server #18** | `mcp` | DevOps & Cloud | `MCP Server` | `mcp://community-18` |
| `community-mcp-19` | **Community MCP Server #19** | `mcp` | Security & Auth | `MCP Server` | `mcp://community-19` |
| `community-mcp-20` | **Community MCP Server #20** | `mcp` | AI & Multimodal | `MCP Server` | `mcp://community-20` |
| `community-mcp-21` | **Community MCP Server #21** | `mcp` | Science & Bio | `MCP Server` | `mcp://community-21` |
| `community-mcp-22` | **Community MCP Server #22** | `mcp` | Workflow & Agents | `MCP Server` | `mcp://community-22` |
| `community-mcp-23` | **Community MCP Server #23** | `mcp` | Code & Refactor | `MCP Server` | `mcp://community-23` |
| `community-mcp-24` | **Community MCP Server #24** | `mcp` | Debugging & Tests | `MCP Server` | `mcp://community-24` |
| `community-mcp-25` | **Community MCP Server #25** | `mcp` | MCP & Integrations | `MCP Server` | `mcp://community-25` |
| `community-mcp-26` | **Community MCP Server #26** | `mcp` | Architecture & System | `MCP Server` | `mcp://community-26` |
| `community-mcp-27` | **Community MCP Server #27** | `mcp` | Web & Frontend | `MCP Server` | `mcp://community-27` |
| `community-mcp-28` | **Community MCP Server #28** | `mcp` | Data & Analytics | `MCP Server` | `mcp://community-28` |
| `community-mcp-29` | **Community MCP Server #29** | `mcp` | DevOps & Cloud | `MCP Server` | `mcp://community-29` |
| `community-mcp-30` | **Community MCP Server #30** | `mcp` | Security & Auth | `MCP Server` | `mcp://community-30` |
| `community-mcp-31` | **Community MCP Server #31** | `mcp` | AI & Multimodal | `MCP Server` | `mcp://community-31` |
| `community-mcp-32` | **Community MCP Server #32** | `mcp` | Science & Bio | `MCP Server` | `mcp://community-32` |
| `community-mcp-33` | **Community MCP Server #33** | `mcp` | Workflow & Agents | `MCP Server` | `mcp://community-33` |
| `community-mcp-34` | **Community MCP Server #34** | `mcp` | Code & Refactor | `MCP Server` | `mcp://community-34` |
| `community-mcp-35` | **Community MCP Server #35** | `mcp` | Debugging & Tests | `MCP Server` | `mcp://community-35` |
| `community-mcp-36` | **Community MCP Server #36** | `mcp` | MCP & Integrations | `MCP Server` | `mcp://community-36` |
| `community-mcp-37` | **Community MCP Server #37** | `mcp` | Architecture & System | `MCP Server` | `mcp://community-37` |
| `community-mcp-38` | **Community MCP Server #38** | `mcp` | Web & Frontend | `MCP Server` | `mcp://community-38` |
| `community-mcp-39` | **Community MCP Server #39** | `mcp` | Data & Analytics | `MCP Server` | `mcp://community-39` |
| `community-mcp-40` | **Community MCP Server #40** | `mcp` | DevOps & Cloud | `MCP Server` | `mcp://community-40` |
| `community-mcp-41` | **Community MCP Server #41** | `mcp` | Security & Auth | `MCP Server` | `mcp://community-41` |
| `community-mcp-42` | **Community MCP Server #42** | `mcp` | AI & Multimodal | `MCP Server` | `mcp://community-42` |
| `community-mcp-43` | **Community MCP Server #43** | `mcp` | Science & Bio | `MCP Server` | `mcp://community-43` |
| `community-mcp-44` | **Community MCP Server #44** | `mcp` | Workflow & Agents | `MCP Server` | `mcp://community-44` |
| `community-mcp-45` | **Community MCP Server #45** | `mcp` | Code & Refactor | `MCP Server` | `mcp://community-45` |
| `community-mcp-46` | **Community MCP Server #46** | `mcp` | Debugging & Tests | `MCP Server` | `mcp://community-46` |
| `community-mcp-47` | **Community MCP Server #47** | `mcp` | MCP & Integrations | `MCP Server` | `mcp://community-47` |
| `community-mcp-48` | **Community MCP Server #48** | `mcp` | Architecture & System | `MCP Server` | `mcp://community-48` |
| `community-mcp-49` | **Community MCP Server #49** | `mcp` | Web & Frontend | `MCP Server` | `mcp://community-49` |
| `community-mcp-50` | **Community MCP Server #50** | `mcp` | Data & Analytics | `MCP Server` | `mcp://community-50` |
| `community-mcp-51` | **Community MCP Server #51** | `mcp` | DevOps & Cloud | `MCP Server` | `mcp://community-51` |
| `community-mcp-52` | **Community MCP Server #52** | `mcp` | Security & Auth | `MCP Server` | `mcp://community-52` |
| `community-mcp-53` | **Community MCP Server #53** | `mcp` | AI & Multimodal | `MCP Server` | `mcp://community-53` |
| `community-mcp-54` | **Community MCP Server #54** | `mcp` | Science & Bio | `MCP Server` | `mcp://community-54` |
| `community-mcp-55` | **Community MCP Server #55** | `mcp` | Workflow & Agents | `MCP Server` | `mcp://community-55` |
| `community-mcp-56` | **Community MCP Server #56** | `mcp` | Code & Refactor | `MCP Server` | `mcp://community-56` |
| `community-mcp-57` | **Community MCP Server #57** | `mcp` | Debugging & Tests | `MCP Server` | `mcp://community-57` |
| `community-mcp-58` | **Community MCP Server #58** | `mcp` | MCP & Integrations | `MCP Server` | `mcp://community-58` |
| `community-mcp-59` | **Community MCP Server #59** | `mcp` | Architecture & System | `MCP Server` | `mcp://community-59` |
| `community-mcp-60` | **Community MCP Server #60** | `mcp` | Web & Frontend | `MCP Server` | `mcp://community-60` |
| `community-mcp-61` | **Community MCP Server #61** | `mcp` | Data & Analytics | `MCP Server` | `mcp://community-61` |
| `community-mcp-62` | **Community MCP Server #62** | `mcp` | DevOps & Cloud | `MCP Server` | `mcp://community-62` |
| `community-mcp-63` | **Community MCP Server #63** | `mcp` | Security & Auth | `MCP Server` | `mcp://community-63` |
| `community-mcp-64` | **Community MCP Server #64** | `mcp` | AI & Multimodal | `MCP Server` | `mcp://community-64` |
| `community-mcp-65` | **Community MCP Server #65** | `mcp` | Science & Bio | `MCP Server` | `mcp://community-65` |
| `community-mcp-66` | **Community MCP Server #66** | `mcp` | Workflow & Agents | `MCP Server` | `mcp://community-66` |
| `community-mcp-67` | **Community MCP Server #67** | `mcp` | Code & Refactor | `MCP Server` | `mcp://community-67` |
| `community-mcp-68` | **Community MCP Server #68** | `mcp` | Debugging & Tests | `MCP Server` | `mcp://community-68` |
| `community-mcp-69` | **Community MCP Server #69** | `mcp` | MCP & Integrations | `MCP Server` | `mcp://community-69` |
| `community-mcp-70` | **Community MCP Server #70** | `mcp` | Architecture & System | `MCP Server` | `mcp://community-70` |
| `community-mcp-71` | **Community MCP Server #71** | `mcp` | Web & Frontend | `MCP Server` | `mcp://community-71` |
| `community-mcp-72` | **Community MCP Server #72** | `mcp` | Data & Analytics | `MCP Server` | `mcp://community-72` |
| `community-mcp-73` | **Community MCP Server #73** | `mcp` | DevOps & Cloud | `MCP Server` | `mcp://community-73` |
| `community-mcp-74` | **Community MCP Server #74** | `mcp` | Security & Auth | `MCP Server` | `mcp://community-74` |
| `community-mcp-75` | **Community MCP Server #75** | `mcp` | AI & Multimodal | `MCP Server` | `mcp://community-75` |
| `community-mcp-76` | **Community MCP Server #76** | `mcp` | Science & Bio | `MCP Server` | `mcp://community-76` |
| `uni-rag-pipeline` | **Hybrid RAG & Cross-Encoder Re-Ranking** | `universal` | AI & Multimodal | `Workflow` | `/rag-pipeline` |
| `uni-jwt-rbac` | **Stateless JWT Auth with Token Rotation & RBAC** | `universal` | Security & Auth | `Workflow` | `/jwt-rbac` |
| `uni-cqrs-event-sourcing` | **CQRS & Event Sourcing Architecture** | `universal` | Architecture & System | `Workflow` | `/cqrs-pattern` |
| `uni-strangler-fig` | **Legacy Migration via Strangler Fig Pattern** | `universal` | Architecture & System | `Workflow` | `/strangler-fig` |
| `uni-circuit-breaker` | **Circuit Breaker & Exponential Backoff** | `universal` | Architecture & System | `Workflow` | `/circuit-breaker` |
| `uni-rate-limiting` | **Distributed Token Bucket Rate Limiter** | `universal` | Security & Auth | `Workflow` | `/rate-limiting` |
| `uni-graphql-federation` | **Apollo GraphQL Federation Gateway** | `universal` | Architecture & System | `Workflow` | `/graphql-federation` |
| `uni-grpc-protobuf` | **High-Throughput gRPC Microservices** | `universal` | Architecture & System | `Workflow` | `/grpc-protobuf` |
| `uni-webrtc-p2p` | **WebRTC Encrypted Peer-to-Peer Streaming** | `universal` | Web & Frontend | `Workflow` | `/webrtc-p2p` |
| `uni-zero-downtime-db` | **Zero-Downtime SQL Schema Migrations** | `universal` | Data & Analytics | `Workflow` | `/zero-downtime-db` |
| `omni-tool-434` | **Engineering Directive #434** | `antigravity` | Code & Refactor | `Prompt Template` | `/tool-434` |
| `omni-tool-435` | **Engineering Directive #435** | `claude` | Debugging & Tests | `Extension` | `/tool-435` |
| `omni-tool-436` | **Engineering Directive #436** | `universal` | MCP & Integrations | `Prompt Template` | `/tool-436` |
| `omni-tool-437` | **Engineering Directive #437** | `antigravity` | Architecture & System | `Extension` | `/tool-437` |
| `omni-tool-438` | **Engineering Directive #438** | `claude` | Web & Frontend | `Prompt Template` | `/tool-438` |
| `omni-tool-439` | **Engineering Directive #439** | `universal` | Data & Analytics | `Extension` | `/tool-439` |
| `omni-tool-440` | **Engineering Directive #440** | `antigravity` | DevOps & Cloud | `Prompt Template` | `/tool-440` |
| `omni-tool-441` | **Engineering Directive #441** | `claude` | Security & Auth | `Extension` | `/tool-441` |
| `omni-tool-442` | **Engineering Directive #442** | `universal` | AI & Multimodal | `Prompt Template` | `/tool-442` |
| `omni-tool-443` | **Engineering Directive #443** | `antigravity` | Science & Bio | `Extension` | `/tool-443` |
| `omni-tool-444` | **Engineering Directive #444** | `claude` | Workflow & Agents | `Prompt Template` | `/tool-444` |
| `omni-tool-445` | **Engineering Directive #445** | `universal` | Code & Refactor | `Extension` | `/tool-445` |
| `omni-tool-446` | **Engineering Directive #446** | `antigravity` | Debugging & Tests | `Prompt Template` | `/tool-446` |
| `omni-tool-447` | **Engineering Directive #447** | `claude` | MCP & Integrations | `Extension` | `/tool-447` |
| `omni-tool-448` | **Engineering Directive #448** | `universal` | Architecture & System | `Prompt Template` | `/tool-448` |
| `omni-tool-449` | **Engineering Directive #449** | `antigravity` | Web & Frontend | `Extension` | `/tool-449` |
| `omni-tool-450` | **Engineering Directive #450** | `claude` | Data & Analytics | `Prompt Template` | `/tool-450` |
| `omni-tool-451` | **Engineering Directive #451** | `universal` | DevOps & Cloud | `Extension` | `/tool-451` |
| `omni-tool-452` | **Engineering Directive #452** | `antigravity` | Security & Auth | `Prompt Template` | `/tool-452` |
| `omni-tool-453` | **Engineering Directive #453** | `claude` | AI & Multimodal | `Extension` | `/tool-453` |
| `omni-tool-454` | **Engineering Directive #454** | `universal` | Science & Bio | `Prompt Template` | `/tool-454` |
| `omni-tool-455` | **Engineering Directive #455** | `antigravity` | Workflow & Agents | `Extension` | `/tool-455` |
| `omni-tool-456` | **Engineering Directive #456** | `claude` | Code & Refactor | `Prompt Template` | `/tool-456` |
| `omni-tool-457` | **Engineering Directive #457** | `universal` | Debugging & Tests | `Extension` | `/tool-457` |
| `omni-tool-458` | **Engineering Directive #458** | `antigravity` | MCP & Integrations | `Prompt Template` | `/tool-458` |
| `omni-tool-459` | **Engineering Directive #459** | `claude` | Architecture & System | `Extension` | `/tool-459` |
| `omni-tool-460` | **Engineering Directive #460** | `universal` | Web & Frontend | `Prompt Template` | `/tool-460` |
| `omni-tool-461` | **Engineering Directive #461** | `antigravity` | Data & Analytics | `Extension` | `/tool-461` |
| `omni-tool-462` | **Engineering Directive #462** | `claude` | DevOps & Cloud | `Prompt Template` | `/tool-462` |
| `omni-tool-463` | **Engineering Directive #463** | `universal` | Security & Auth | `Extension` | `/tool-463` |
| `omni-tool-464` | **Engineering Directive #464** | `antigravity` | AI & Multimodal | `Prompt Template` | `/tool-464` |
| `omni-tool-465` | **Engineering Directive #465** | `claude` | Science & Bio | `Extension` | `/tool-465` |
| `omni-tool-466` | **Engineering Directive #466** | `universal` | Workflow & Agents | `Prompt Template` | `/tool-466` |
| `omni-tool-467` | **Engineering Directive #467** | `antigravity` | Code & Refactor | `Extension` | `/tool-467` |
| `omni-tool-468` | **Engineering Directive #468** | `claude` | Debugging & Tests | `Prompt Template` | `/tool-468` |
| `omni-tool-469` | **Engineering Directive #469** | `universal` | MCP & Integrations | `Extension` | `/tool-469` |
| `omni-tool-470` | **Engineering Directive #470** | `antigravity` | Architecture & System | `Prompt Template` | `/tool-470` |
| `omni-tool-471` | **Engineering Directive #471** | `claude` | Web & Frontend | `Extension` | `/tool-471` |
| `omni-tool-472` | **Engineering Directive #472** | `universal` | Data & Analytics | `Prompt Template` | `/tool-472` |
| `omni-tool-473` | **Engineering Directive #473** | `antigravity` | DevOps & Cloud | `Extension` | `/tool-473` |
| `omni-tool-474` | **Engineering Directive #474** | `claude` | Security & Auth | `Prompt Template` | `/tool-474` |
| `omni-tool-475` | **Engineering Directive #475** | `universal` | AI & Multimodal | `Extension` | `/tool-475` |
| `omni-tool-476` | **Engineering Directive #476** | `antigravity` | Science & Bio | `Prompt Template` | `/tool-476` |
| `omni-tool-477` | **Engineering Directive #477** | `claude` | Workflow & Agents | `Extension` | `/tool-477` |
| `omni-tool-478` | **Engineering Directive #478** | `universal` | Code & Refactor | `Prompt Template` | `/tool-478` |
| `omni-tool-479` | **Engineering Directive #479** | `antigravity` | Debugging & Tests | `Extension` | `/tool-479` |
| `omni-tool-480` | **Engineering Directive #480** | `claude` | MCP & Integrations | `Prompt Template` | `/tool-480` |
| `omni-tool-481` | **Engineering Directive #481** | `universal` | Architecture & System | `Extension` | `/tool-481` |
| `omni-tool-482` | **Engineering Directive #482** | `antigravity` | Web & Frontend | `Prompt Template` | `/tool-482` |
| `omni-tool-483` | **Engineering Directive #483** | `claude` | Data & Analytics | `Extension` | `/tool-483` |
| `omni-tool-484` | **Engineering Directive #484** | `universal` | DevOps & Cloud | `Prompt Template` | `/tool-484` |
| `omni-tool-485` | **Engineering Directive #485** | `antigravity` | Security & Auth | `Extension` | `/tool-485` |
| `omni-tool-486` | **Engineering Directive #486** | `claude` | AI & Multimodal | `Prompt Template` | `/tool-486` |
| `omni-tool-487` | **Engineering Directive #487** | `universal` | Science & Bio | `Extension` | `/tool-487` |
| `omni-tool-488` | **Engineering Directive #488** | `antigravity` | Workflow & Agents | `Prompt Template` | `/tool-488` |
| `omni-tool-489` | **Engineering Directive #489** | `claude` | Code & Refactor | `Extension` | `/tool-489` |
| `omni-tool-490` | **Engineering Directive #490** | `universal` | Debugging & Tests | `Prompt Template` | `/tool-490` |
| `omni-tool-491` | **Engineering Directive #491** | `antigravity` | MCP & Integrations | `Extension` | `/tool-491` |
| `omni-tool-492` | **Engineering Directive #492** | `claude` | Architecture & System | `Prompt Template` | `/tool-492` |
| `omni-tool-493` | **Engineering Directive #493** | `universal` | Web & Frontend | `Extension` | `/tool-493` |
| `omni-tool-494` | **Engineering Directive #494** | `antigravity` | Data & Analytics | `Prompt Template` | `/tool-494` |
| `omni-tool-495` | **Engineering Directive #495** | `claude` | DevOps & Cloud | `Extension` | `/tool-495` |
| `omni-tool-496` | **Engineering Directive #496** | `universal` | Security & Auth | `Prompt Template` | `/tool-496` |
| `omni-tool-497` | **Engineering Directive #497** | `antigravity` | AI & Multimodal | `Extension` | `/tool-497` |
| `omni-tool-498` | **Engineering Directive #498** | `claude` | Science & Bio | `Prompt Template` | `/tool-498` |
| `omni-tool-499` | **Engineering Directive #499** | `universal` | Workflow & Agents | `Extension` | `/tool-499` |
| `omni-tool-500` | **Engineering Directive #500** | `antigravity` | Code & Refactor | `Prompt Template` | `/tool-500` |