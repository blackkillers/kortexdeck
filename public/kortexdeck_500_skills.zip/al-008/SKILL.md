---
name: al-008
description: "Disjoint Set Union with path compression and union by rank"
category: "Algorithmique"
platform: "Algorithm"
type: "Data Structure"
difficulty: "Advanced"
tags: ["union-find", "dsu", "graph", "mst", "algorithm"]
---

# Union-Find / DSU

> **Platform**: `ALGORITHM` | **Category**: `Algorithmique` | **Type**: `Data Structure` | **Difficulty**: `Advanced`

## 1. Executive Summary & Purpose
Implement Union-Find with path compression + union by rank, offline LCA, Kruskal's MST, connected components, percolation, and bipartite detection

## 2. Activation Syntax & Command Line
```bash
/union-find [application] [--path-compression] [--weighted]
```

## 3. Core Behavioral Directives & Execution Protocol
1. **Context Initialization**: Prioritize zero-latency client-side execution, defensive boundaries, and strict type safety.
2. **Autonomous Execution**: When triggered via `/union-find`, execute all sub-tasks systematically until complete verification.
3. **Safety & Privacy**: Sanitize all inputs. Never log or transmit authentication credentials, private tokens, or sensitive user environment data.
4. **Error Handling**: Gracefully recover from network or parsing anomalies with actionable diagnostic logs.

## 4. Practical Implementation Example
```markdown
/union-find kruskal-mst --path-compression --weighted
```

## 5. Multi-Platform Agent Compatibility Matrix
- **Google Antigravity**: Native support via `/goal`, `/schedule`, and rule sidecars.
- **Anthropic Claude Code**: Integrated into `CLAUDE.md` and XML system prompt blocks.
- **Cursor IDE**: Direct compilation into `.cursorrules` and semantic index queries.
- **Windsurf / Codex / Cline / Roo Code**: Universal MCP and system prompt compatible.
