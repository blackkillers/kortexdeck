---
name: agy-teamwork-preview
description: "Spawns and coordinates specialized autonomous subagents working concurrently on large projects."
category: "Workflow & Agents"
platform: "antigravity"
type: "Slash Command"
difficulty: "Expert"
tags: ["multi-agent", "subagents", "collaboration", "parallel"]
---

# Multi-Agent Swarm Orchestration (/teamwork-preview)

> **Platform**: `ANTIGRAVITY` | **Category**: `Workflow & Agents` | **Type**: `Slash Command` | **Difficulty**: `Expert`

## 1. Executive Summary & Purpose
Automatically divides large deliverables between research, frontend, backend, testing, and documentation agents communicating via structured message passing.

## 2. Activation Syntax & Command Line
```bash
/teamwork-preview <project> [--agents front,back,test,docs]
```

## 3. Core Behavioral Directives & Execution Protocol
1. **Context Initialization**: Prioritize zero-latency client-side execution, defensive boundaries, and strict type safety.
2. **Autonomous Execution**: When triggered via `/teamwork-preview`, execute all sub-tasks systematically until complete verification.
3. **Safety & Privacy**: Sanitize all inputs. Never log or transmit authentication credentials, private tokens, or sensitive user environment data.
4. **Error Handling**: Gracefully recover from network or parsing anomalies with actionable diagnostic logs.

## 4. Practical Implementation Example
```markdown
/teamwork-preview Build a real-time Linear clone with React frontend, Fastify API, and Supabase database.
```

## 5. Multi-Platform Agent Compatibility Matrix
- **Google Antigravity**: Native support via `/goal`, `/schedule`, and rule sidecars.
- **Anthropic Claude Code**: Integrated into `CLAUDE.md` and XML system prompt blocks.
- **Cursor IDE**: Direct compilation into `.cursorrules` and semantic index queries.
- **Windsurf / Codex / Cline / Roo Code**: Universal MCP and system prompt compatible.
