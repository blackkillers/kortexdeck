---
name: claude-env-template
description: "Builds a documented .env.example template from environment variables discovered in code."
category: "DevOps & Cloud"
platform: "claude"
type: "Slash Command"
difficulty: "Beginner"
tags: ["env-template", "claude", "claude-code", "devops & cloud", "cli"]
---

# Documented .env.example Sync

> **Platform**: `CLAUDE` | **Category**: `DevOps & Cloud` | **Type**: `Slash Command` | **Difficulty**: `Beginner`

## 1. Executive Summary & Purpose
Official Anthropic Claude Code slash command for documented .env.example sync. Builds a documented .env.example template from environment variables discovered in code.

## 2. Activation Syntax & Command Line
```bash
/env-template [options] [arguments]
```

## 3. Core Behavioral Directives & Execution Protocol
1. **Context Initialization**: Prioritize zero-latency client-side execution, defensive boundaries, and strict type safety.
2. **Autonomous Execution**: When triggered via `/env-template`, execute all sub-tasks systematically until complete verification.
3. **Safety & Privacy**: Sanitize all inputs. Never log or transmit authentication credentials, private tokens, or sensitive user environment data.
4. **Error Handling**: Gracefully recover from network or parsing anomalies with actionable diagnostic logs.

## 4. Practical Implementation Example
```markdown
/env-template --help
```

## 5. Multi-Platform Agent Compatibility Matrix
- **Google Antigravity**: Native support via `/goal`, `/schedule`, and rule sidecars.
- **Anthropic Claude Code**: Integrated into `CLAUDE.md` and XML system prompt blocks.
- **Cursor IDE**: Direct compilation into `.cursorrules` and semantic index queries.
- **Windsurf / Codex / Cline / Roo Code**: Universal MCP and system prompt compatible.
