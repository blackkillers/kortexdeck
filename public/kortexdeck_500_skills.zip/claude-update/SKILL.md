---
name: claude-update
description: "Checks for, downloads, and installs the latest official Claude Code CLI release."
category: "DevOps & Cloud"
platform: "claude"
type: "Slash Command"
difficulty: "Beginner"
tags: ["update", "claude", "claude-code", "devops & cloud", "cli"]
---

# CLI Auto-Updater

> **Platform**: `CLAUDE` | **Category**: `DevOps & Cloud` | **Type**: `Slash Command` | **Difficulty**: `Beginner`

## 1. Executive Summary & Purpose
Official Anthropic Claude Code slash command for cli auto-updater. Checks for, downloads, and installs the latest official Claude Code CLI release.

## 2. Activation Syntax & Command Line
```bash
/update [options] [arguments]
```

## 3. Core Behavioral Directives & Execution Protocol
1. **Context Initialization**: Prioritize zero-latency client-side execution, defensive boundaries, and strict type safety.
2. **Autonomous Execution**: When triggered via `/update`, execute all sub-tasks systematically until complete verification.
3. **Safety & Privacy**: Sanitize all inputs. Never log or transmit authentication credentials, private tokens, or sensitive user environment data.
4. **Error Handling**: Gracefully recover from network or parsing anomalies with actionable diagnostic logs.

## 4. Practical Implementation Example
```markdown
/update --help
```

## 5. Multi-Platform Agent Compatibility Matrix
- **Google Antigravity**: Native support via `/goal`, `/schedule`, and rule sidecars.
- **Anthropic Claude Code**: Integrated into `CLAUDE.md` and XML system prompt blocks.
- **Cursor IDE**: Direct compilation into `.cursorrules` and semantic index queries.
- **Windsurf / Codex / Cline / Roo Code**: Universal MCP and system prompt compatible.
