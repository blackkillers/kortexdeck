---
name: claude-k8s-manifest
description: "Generates Deployment, Service, Ingress, and ConfigMap YAMLs tailored to the application."
category: "DevOps & Cloud"
platform: "claude"
type: "Slash Command"
difficulty: "Expert"
tags: ["k8s-manifest", "claude", "claude-code", "devops & cloud", "cli"]
---

# Kubernetes Manifest Generator

> **Platform**: `CLAUDE` | **Category**: `DevOps & Cloud` | **Type**: `Slash Command` | **Difficulty**: `Expert`

## 1. Executive Summary & Purpose
Official Anthropic Claude Code slash command for kubernetes manifest generator. Generates Deployment, Service, Ingress, and ConfigMap YAMLs tailored to the application.

## 2. Activation Syntax & Command Line
```bash
/k8s-manifest [options] [arguments]
```

## 3. Core Behavioral Directives & Execution Protocol
1. **Context Initialization**: Prioritize zero-latency client-side execution, defensive boundaries, and strict type safety.
2. **Autonomous Execution**: When triggered via `/k8s-manifest`, execute all sub-tasks systematically until complete verification.
3. **Safety & Privacy**: Sanitize all inputs. Never log or transmit authentication credentials, private tokens, or sensitive user environment data.
4. **Error Handling**: Gracefully recover from network or parsing anomalies with actionable diagnostic logs.

## 4. Practical Implementation Example
```markdown
/k8s-manifest --help
```

## 5. Multi-Platform Agent Compatibility Matrix
- **Google Antigravity**: Native support via `/goal`, `/schedule`, and rule sidecars.
- **Anthropic Claude Code**: Integrated into `CLAUDE.md` and XML system prompt blocks.
- **Cursor IDE**: Direct compilation into `.cursorrules` and semantic index queries.
- **Windsurf / Codex / Cline / Roo Code**: Universal MCP and system prompt compatible.
