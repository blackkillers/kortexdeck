---
name: agy-goal
description: "Executes long-running autonomous tasks without stopping until all success criteria are met."
category: "Workflow & Agents"
platform: "antigravity"
type: "Slash Command"
difficulty: "Expert"
tags: ["goal", "autonomous", "agent", "long-running", "unsupervised"]
---

# Persistent Autonomous Mode (/goal)

> **Platform**: `ANTIGRAVITY` | **Category**: `Workflow & Agents` | **Type**: `Slash Command` | **Difficulty**: `Expert`

## 1. Executive Summary & Purpose
Engages the persistent autonomous agent loop. The agent conducts iterative research, code editing, unit test execution, and self-correction until full resolution is achieved and verified.

## 2. Activation Syntax & Command Line
```bash
/goal <detailed_objective> [--max-steps N] [--verify-tests]
```

## 3. Core Behavioral Directives & Execution Protocol
1. **Context Initialization**: Prioritize zero-latency client-side execution, defensive boundaries, and strict type safety.
2. **Autonomous Execution**: When triggered via `/goal`, execute all sub-tasks systematically until complete verification.
3. **Safety & Privacy**: Sanitize all inputs. Never log or transmit authentication credentials, private tokens, or sensitive user environment data.
4. **Error Handling**: Gracefully recover from network or parsing anomalies with actionable diagnostic logs.

## 4. Practical Implementation Example
```markdown
/goal Migrate the entire authentication module to NextAuth v5 with JWT session handling and 100% Vitest coverage.
```

## 5. Multi-Platform Agent Compatibility Matrix
- **Google Antigravity**: Native support via `/goal`, `/schedule`, and rule sidecars.
- **Anthropic Claude Code**: Integrated into `CLAUDE.md` and XML system prompt blocks.
- **Cursor IDE**: Direct compilation into `.cursorrules` and semantic index queries.
- **Windsurf / Codex / Cline / Roo Code**: Universal MCP and system prompt compatible.
