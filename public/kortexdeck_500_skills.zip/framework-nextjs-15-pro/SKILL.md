---
name: framework-nextjs-15-pro
description: "Mastery of Next.js 15 Partial Prerendering, async Request APIs, Server Actions, and granular cache controls."
category: "Framework"
platform: "universal"
type: "Full-Stack Framework"
difficulty: "Advanced"
tags: ["nextjs", "react", "framework", "app-router", "ppr"]
---

# Next.js 15 App Router & Partial Prerendering (PPR)

> **Platform**: `UNIVERSAL` | **Category**: `Framework` | **Type**: `Full-Stack Framework` | **Difficulty**: `Advanced`

## 1. Executive Summary & Purpose
Architects high-speed production Next.js 15 applications. Leverages React Server Components for instant shell delivery while streaming dynamic personalized content via Suspense boundaries.

## 2. Activation Syntax & Command Line
```bash
export const experimental_ppr = true;
```

## 3. Core Behavioral Directives & Execution Protocol
1. **Context Initialization**: Prioritize zero-latency client-side execution, defensive boundaries, and strict type safety.
2. **Autonomous Execution**: When triggered via `skill:nextjs-15-pro`, execute all sub-tasks systematically until complete verification.
3. **Safety & Privacy**: Sanitize all inputs. Never log or transmit authentication credentials, private tokens, or sensitive user environment data.
4. **Error Handling**: Gracefully recover from network or parsing anomalies with actionable diagnostic logs.

## 4. Practical Implementation Example
```markdown
Implement a product page with static SEO-optimized product details and a streaming Suspense cart widget with optimistic updates.
```

## 5. Multi-Platform Agent Compatibility Matrix
- **Google Antigravity**: Native support via `/goal`, `/schedule`, and rule sidecars.
- **Anthropic Claude Code**: Integrated into `CLAUDE.md` and XML system prompt blocks.
- **Cursor IDE**: Direct compilation into `.cursorrules` and semantic index queries.
- **Windsurf / Codex / Cline / Roo Code**: Universal MCP and system prompt compatible.
