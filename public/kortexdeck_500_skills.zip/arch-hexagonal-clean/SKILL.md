---
name: arch-hexagonal-clean
description: "Strict decoupling of core business logic from databases, external APIs, and UI layers using Dependency Inversion."
category: "Architecture"
platform: "universal"
type: "Architectural Pattern"
difficulty: "Expert"
tags: ["architecture", "hexagonal", "clean-architecture", "ports-and-adapters", "ddd"]
---

# Hexagonal Architecture (Ports & Adapters)

> **Platform**: `UNIVERSAL` | **Category**: `Architecture` | **Type**: `Architectural Pattern` | **Difficulty**: `Expert`

## 1. Executive Summary & Purpose
Defines explicit input and output ports (interfaces). Isolates domain models from framework dependencies, allowing trivial unit testing with mock adapters and hot-swappable databases.

## 2. Activation Syntax & Command Line
```bash
Domain -> Ports (Interfaces) <- Adapters (DB / HTTP / CLI)
```

## 3. Core Behavioral Directives & Execution Protocol
1. **Context Initialization**: Prioritize zero-latency client-side execution, defensive boundaries, and strict type safety.
2. **Autonomous Execution**: When triggered via `skill:arch-hexagonal`, execute all sub-tasks systematically until complete verification.
3. **Safety & Privacy**: Sanitize all inputs. Never log or transmit authentication credentials, private tokens, or sensitive user environment data.
4. **Error Handling**: Gracefully recover from network or parsing anomalies with actionable diagnostic logs.

## 4. Practical Implementation Example
```markdown
Design an Order Processing domain service implementing the PaymentPort and NotificationPort with Stripe and SendGrid adapters.
```

## 5. Multi-Platform Agent Compatibility Matrix
- **Google Antigravity**: Native support via `/goal`, `/schedule`, and rule sidecars.
- **Anthropic Claude Code**: Integrated into `CLAUDE.md` and XML system prompt blocks.
- **Cursor IDE**: Direct compilation into `.cursorrules` and semantic index queries.
- **Windsurf / Codex / Cline / Roo Code**: Universal MCP and system prompt compatible.
