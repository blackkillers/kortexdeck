---
name: namedomain-saas-brand-namer
description: "Creative algorithm generating punchy, memorable tech brand names, portmanteaus, phonetic rhymes, and verb-ready product titles."
category: "Name & Domain"
platform: "universal"
type: "Naming & Brand Strategy"
difficulty: "Beginner"
tags: ["domain", "branding", "naming", "saas", "marketing"]
---

# AI SaaS Brand Namer & Phonetic Coining

> **Platform**: `UNIVERSAL` | **Category**: `Name & Domain` | **Type**: `Naming & Brand Strategy` | **Difficulty**: `Beginner`

## 1. Executive Summary & Purpose
Generates brandable company and product names tailored to tech sectors. Evaluates pronounceability across international languages, memorability score, and syllable cadence.

## 2. Activation Syntax & Command Line
```bash
/name-brand --sector='AI Developer Tools' --vibe='futuristic, crisp' --syllables=2
```

## 3. Core Behavioral Directives & Execution Protocol
1. **Context Initialization**: Prioritize zero-latency client-side execution, defensive boundaries, and strict type safety.
2. **Autonomous Execution**: When triggered via `skill:namedomain-brand-namer`, execute all sub-tasks systematically until complete verification.
3. **Safety & Privacy**: Sanitize all inputs. Never log or transmit authentication credentials, private tokens, or sensitive user environment data.
4. **Error Handling**: Gracefully recover from network or parsing anomalies with actionable diagnostic logs.

## 4. Practical Implementation Example
```markdown
/name-brand Generate 10 crisp, two-syllable brand names for an autonomous AI command center with available .dev / .ai / .com extensions.
```

## 5. Multi-Platform Agent Compatibility Matrix
- **Google Antigravity**: Native support via `/goal`, `/schedule`, and rule sidecars.
- **Anthropic Claude Code**: Integrated into `CLAUDE.md` and XML system prompt blocks.
- **Cursor IDE**: Direct compilation into `.cursorrules` and semantic index queries.
- **Windsurf / Codex / Cline / Roo Code**: Universal MCP and system prompt compatible.
