---
name: agy-schedule
description: "Schedules background timers and recurring cron notifications without blocking current work."
category: "Workflow & Agents"
platform: "antigravity"
type: "Slash Command"
difficulty: "Intermediate"
tags: ["schedule", "cron", "timer", "background", "polling"]
---

# Async Scheduler & Cron Jobs (/schedule)

> **Platform**: `ANTIGRAVITY` | **Category**: `Workflow & Agents` | **Type**: `Slash Command` | **Difficulty**: `Intermediate`

## 1. Executive Summary & Purpose
Allows the agent to schedule one-off reminders, deployment health-checks, or periodic polling tasks in the background without freezing active conversation turns.

## 2. Activation Syntax & Command Line
```bash
/schedule --duration <sec> | --cron <expr> --prompt <message>
```

## 3. Core Behavioral Directives & Execution Protocol
1. **Context Initialization**: Prioritize zero-latency client-side execution, defensive boundaries, and strict type safety.
2. **Autonomous Execution**: When triggered via `/schedule`, execute all sub-tasks systematically until complete verification.
3. **Safety & Privacy**: Sanitize all inputs. Never log or transmit authentication credentials, private tokens, or sensitive user environment data.
4. **Error Handling**: Gracefully recover from network or parsing anomalies with actionable diagnostic logs.

## 4. Practical Implementation Example
```markdown
/schedule --duration 300 --prompt 'Check if Docker container status is healthy and analyze any error logs'
```

## 5. Multi-Platform Agent Compatibility Matrix
- **Google Antigravity**: Native support via `/goal`, `/schedule`, and rule sidecars.
- **Anthropic Claude Code**: Integrated into `CLAUDE.md` and XML system prompt blocks.
- **Cursor IDE**: Direct compilation into `.cursorrules` and semantic index queries.
- **Windsurf / Codex / Cline / Roo Code**: Universal MCP and system prompt compatible.
