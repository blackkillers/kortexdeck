---
name: vid-001
description: "FFmpeg commands: transcode, trim, merge, add subtitles, change resolution"
category: "Video"
platform: "Video"
type: "Processing"
difficulty: "Advanced"
tags: ["ffmpeg", "video", "transcode", "processing"]
---

# FFmpeg Video Processor

> **Platform**: `VIDEO` | **Category**: `Video` | **Type**: `Processing` | **Difficulty**: `Advanced`

## 1. Executive Summary & Purpose
FFmpeg master commands: video transcoding, segment trimming, concat demuxer merging, subtitle burning, resolution scaling, audio extraction, thumbnail generation, and HLS streaming

## 2. Activation Syntax & Command Line
```bash
/ffmpeg [operation] [--input] [--output-format mp4|webm|hls] [--quality crf 23]
```

## 3. Core Behavioral Directives & Execution Protocol
1. **Context Initialization**: Prioritize zero-latency client-side execution, defensive boundaries, and strict type safety.
2. **Autonomous Execution**: When triggered via `/ffmpeg`, execute all sub-tasks systematically until complete verification.
3. **Safety & Privacy**: Sanitize all inputs. Never log or transmit authentication credentials, private tokens, or sensitive user environment data.
4. **Error Handling**: Gracefully recover from network or parsing anomalies with actionable diagnostic logs.

## 4. Practical Implementation Example
```markdown
/ffmpeg transcode --input video.mov --output-format mp4 --quality crf 18
```

## 5. Multi-Platform Agent Compatibility Matrix
- **Google Antigravity**: Native support via `/goal`, `/schedule`, and rule sidecars.
- **Anthropic Claude Code**: Integrated into `CLAUDE.md` and XML system prompt blocks.
- **Cursor IDE**: Direct compilation into `.cursorrules` and semantic index queries.
- **Windsurf / Codex / Cline / Roo Code**: Universal MCP and system prompt compatible.
