---
name: logo-minimalist-vector-master
description: "Vector logo geometry generator based on golden ratio proportions, negative space harmony, and multi-scale legibility."
category: "Logo & Branding"
platform: "universal"
type: "Brand Design"
difficulty: "Intermediate"
tags: ["logo", "branding", "vector", "svg", "design-system", "iconography"]
---

# Minimalist Tech Vector Logo Generator

> **Platform**: `UNIVERSAL` | **Category**: `Logo & Branding` | **Type**: `Brand Design` | **Difficulty**: `Intermediate`

## 1. Executive Summary & Purpose
Designs modern, memorable tech brand marks. Produces clean SVG code, defines strict monochrome fallbacks, minimum sizing limits (16px favicon to billboard), and dark/light adaptive versions.

## 2. Activation Syntax & Command Line
```bash
/logo-gen --name='KortexDeck' --style='minimal-geometric' --format=svg
```

## 3. Core Behavioral Directives & Execution Protocol
1. **Context Initialization**: Prioritize zero-latency client-side execution, defensive boundaries, and strict type safety.
2. **Autonomous Execution**: When triggered via `skill:logo-vector-master`, execute all sub-tasks systematically until complete verification.
3. **Safety & Privacy**: Sanitize all inputs. Never log or transmit authentication credentials, private tokens, or sensitive user environment data.
4. **Error Handling**: Gracefully recover from network or parsing anomalies with actionable diagnostic logs.

## 4. Practical Implementation Example
```markdown
/logo-gen Create a sleek, geometric hexagonal logo for an AI developer platform with electric cyan and neon violet gradient accents in pure SVG.
```

## 5. Multi-Platform Agent Compatibility Matrix
- **Google Antigravity**: Native support via `/goal`, `/schedule`, and rule sidecars.
- **Anthropic Claude Code**: Integrated into `CLAUDE.md` and XML system prompt blocks.
- **Cursor IDE**: Direct compilation into `.cursorrules` and semantic index queries.
- **Windsurf / Codex / Cline / Roo Code**: Universal MCP and system prompt compatible.
