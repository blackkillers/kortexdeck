---
name: fw-004
description: "Build Laravel REST APIs: Eloquent resources, policies, form requests, Sanctum"
category: "Framework"
platform: "Framework"
type: "Backend"
difficulty: "Advanced"
tags: ["laravel", "php", "eloquent", "sanctum", "api"]
---

# Laravel API Blueprint

> **Platform**: `FRAMEWORK` | **Category**: `Framework` | **Type**: `Backend` | **Difficulty**: `Advanced`

## 1. Executive Summary & Purpose
Laravel API: Eloquent API resources, model policies, form request validation, Laravel Sanctum for SPA auth, API versioning, queue jobs, and Laravel Telescope debugging

## 2. Activation Syntax & Command Line
```bash
/laravel-api [resource] [--auth sanctum|passport] [--policy] [--queue]
```

## 3. Core Behavioral Directives & Execution Protocol
1. **Context Initialization**: Prioritize zero-latency client-side execution, defensive boundaries, and strict type safety.
2. **Autonomous Execution**: When triggered via `/laravel-api`, execute all sub-tasks systematically until complete verification.
3. **Safety & Privacy**: Sanitize all inputs. Never log or transmit authentication credentials, private tokens, or sensitive user environment data.
4. **Error Handling**: Gracefully recover from network or parsing anomalies with actionable diagnostic logs.

## 4. Practical Implementation Example
```markdown
/laravel-api Product --auth sanctum --policy --queue
```

## 5. Multi-Platform Agent Compatibility Matrix
- **Google Antigravity**: Native support via `/goal`, `/schedule`, and rule sidecars.
- **Anthropic Claude Code**: Integrated into `CLAUDE.md` and XML system prompt blocks.
- **Cursor IDE**: Direct compilation into `.cursorrules` and semantic index queries.
- **Windsurf / Codex / Cline / Roo Code**: Universal MCP and system prompt compatible.
