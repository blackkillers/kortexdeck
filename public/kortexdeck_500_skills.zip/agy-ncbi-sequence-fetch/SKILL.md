---
name: agy-ncbi-sequence-fetch
description: "Downloads nucleotide and protein sequences directly in standard FASTA format."
category: "Science & Bio"
platform: "antigravity"
type: "Skill"
difficulty: "Intermediate"
tags: ["ncbi-sequence-fetch", "science", "biology", "genomics", "research"]
---

# NCBI GenBank Sequence Fetcher

> **Platform**: `ANTIGRAVITY` | **Category**: `Science & Bio` | **Type**: `Skill` | **Difficulty**: `Intermediate`

## 1. Executive Summary & Purpose
Retrieves and analyzes specialized research data from NCBI GenBank Sequence Fetcher for bioinformatics and scientific computing workflows.

## 2. Activation Syntax & Command Line
```bash
use skill: ncbi-sequence-fetch --query <term_or_id>
```

## 3. Core Behavioral Directives & Execution Protocol
1. **Context Initialization**: Prioritize zero-latency client-side execution, defensive boundaries, and strict type safety.
2. **Autonomous Execution**: When triggered via `ncbi-sequence-fetch`, execute all sub-tasks systematically until complete verification.
3. **Safety & Privacy**: Sanitize all inputs. Never log or transmit authentication credentials, private tokens, or sensitive user environment data.
4. **Error Handling**: Gracefully recover from network or parsing anomalies with actionable diagnostic logs.

## 4. Practical Implementation Example
```markdown
use skill: ncbi-sequence-fetch --query BRCA1 --limit 5
```

## 5. Multi-Platform Agent Compatibility Matrix
- **Google Antigravity**: Native support via `/goal`, `/schedule`, and rule sidecars.
- **Anthropic Claude Code**: Integrated into `CLAUDE.md` and XML system prompt blocks.
- **Cursor IDE**: Direct compilation into `.cursorrules` and semantic index queries.
- **Windsurf / Codex / Cline / Roo Code**: Universal MCP and system prompt compatible.
