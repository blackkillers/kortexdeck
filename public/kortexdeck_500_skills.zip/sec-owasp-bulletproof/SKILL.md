---
name: sec-owasp-bulletproof
description: "Hardened application security auditing for injection flaws, broken access control, XSS, CSRF, and cryptographic failures."
category: "Security"
platform: "universal"
type: "Application Security"
difficulty: "Expert"
tags: ["security", "owasp", "appsec", "xss", "csrf", "infosec"]
---

# OWASP Top 10 Bulletproof Web Defense

> **Platform**: `UNIVERSAL` | **Category**: `Security` | **Type**: `Application Security` | **Difficulty**: `Expert`

## 1. Executive Summary & Purpose
Applies zero-trust security controls across backend and frontend codebases. Enforces strict Content Security Policy (CSP), parameterized SQL queries, DOMPurify sanitization, and timing-safe comparisons.

## 2. Activation Syntax & Command Line
```bash
/sec-audit --owasp --strict-csp --auth-matrix
```

## 3. Core Behavioral Directives & Execution Protocol
1. **Context Initialization**: Prioritize zero-latency client-side execution, defensive boundaries, and strict type safety.
2. **Autonomous Execution**: When triggered via `skill:sec-owasp-bulletproof`, execute all sub-tasks systematically until complete verification.
3. **Safety & Privacy**: Sanitize all inputs. Never log or transmit authentication credentials, private tokens, or sensitive user environment data.
4. **Error Handling**: Gracefully recover from network or parsing anomalies with actionable diagnostic logs.

## 4. Practical Implementation Example
```markdown
/sec-audit Audit all user input entry points, verify parameterized query enforcement, and generate strict CSP headers with nonce support.
```

## 5. Multi-Platform Agent Compatibility Matrix
- **Google Antigravity**: Native support via `/goal`, `/schedule`, and rule sidecars.
- **Anthropic Claude Code**: Integrated into `CLAUDE.md` and XML system prompt blocks.
- **Cursor IDE**: Direct compilation into `.cursorrules` and semantic index queries.
- **Windsurf / Codex / Cline / Roo Code**: Universal MCP and system prompt compatible.
