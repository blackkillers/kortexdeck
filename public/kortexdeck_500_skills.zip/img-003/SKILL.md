---
name: img-003
description: "Extract text from images with Tesseract or Gemini Vision OCR"
category: "Image"
platform: "Image"
type: "Extraction"
difficulty: "Advanced"
tags: ["ocr", "tesseract", "gemini", "text-extraction", "image"]
---

# Image OCR Extractor

> **Platform**: `IMAGE` | **Category**: `Image` | **Type**: `Extraction` | **Difficulty**: `Advanced`

## 1. Executive Summary & Purpose
OCR pipeline: Tesseract with language packs, Gemini Vision for complex layouts, table extraction from images, receipt parsing, ID document OCR, and structured output

## 2. Activation Syntax & Command Line
```bash
/ocr [image] [--engine tesseract|gemini] [--lang en,fr,he] [--type document|table|receipt]
```

## 3. Core Behavioral Directives & Execution Protocol
1. **Context Initialization**: Prioritize zero-latency client-side execution, defensive boundaries, and strict type safety.
2. **Autonomous Execution**: When triggered via `/ocr`, execute all sub-tasks systematically until complete verification.
3. **Safety & Privacy**: Sanitize all inputs. Never log or transmit authentication credentials, private tokens, or sensitive user environment data.
4. **Error Handling**: Gracefully recover from network or parsing anomalies with actionable diagnostic logs.

## 4. Practical Implementation Example
```markdown
/ocr invoice.jpg --engine gemini --type table
```

## 5. Multi-Platform Agent Compatibility Matrix
- **Google Antigravity**: Native support via `/goal`, `/schedule`, and rule sidecars.
- **Anthropic Claude Code**: Integrated into `CLAUDE.md` and XML system prompt blocks.
- **Cursor IDE**: Direct compilation into `.cursorrules` and semantic index queries.
- **Windsurf / Codex / Cline / Roo Code**: Universal MCP and system prompt compatible.
