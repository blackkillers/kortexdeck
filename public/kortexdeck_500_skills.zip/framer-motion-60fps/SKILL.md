---
name: framer-motion-60fps
description: "Spring-physics layout animations, exit transitions, drag gestures, and scroll-linked timeline sequences."
category: "Frontend & UI"
platform: "universal"
type: "Animation Engine"
difficulty: "Intermediate"
tags: ["framer-motion", "animation", "micro-interactions", "frontend", "ui"]
---

# Framer Motion 60FPS Micro-Interactions

> **Platform**: `UNIVERSAL` | **Category**: `Frontend & UI` | **Type**: `Animation Engine` | **Difficulty**: `Intermediate`

## 1. Executive Summary & Purpose
Architects butter-smooth 60fps GPU-accelerated UI animations using Framer Motion and Motion One. Eliminates layout thrashing by animating transform and opacity properties exclusively.

## 2. Activation Syntax & Command Line
```bash
<motion.div layout initial={{ opacity: 0, y: 15 }} animate={{ opacity: 1, y: 0 }} transition={{ type: 'spring', stiffness: 300 }} />
```

## 3. Core Behavioral Directives & Execution Protocol
1. **Context Initialization**: Prioritize zero-latency client-side execution, defensive boundaries, and strict type safety.
2. **Autonomous Execution**: When triggered via `skill:framer-motion-wizard`, execute all sub-tasks systematically until complete verification.
3. **Safety & Privacy**: Sanitize all inputs. Never log or transmit authentication credentials, private tokens, or sensitive user environment data.
4. **Error Handling**: Gracefully recover from network or parsing anomalies with actionable diagnostic logs.

## 4. Practical Implementation Example
```markdown
Implement shared layout morphing transitions between product grid cards and the modal preview with spring physics.
```

## 5. Multi-Platform Agent Compatibility Matrix
- **Google Antigravity**: Native support via `/goal`, `/schedule`, and rule sidecars.
- **Anthropic Claude Code**: Integrated into `CLAUDE.md` and XML system prompt blocks.
- **Cursor IDE**: Direct compilation into `.cursorrules` and semantic index queries.
- **Windsurf / Codex / Cline / Roo Code**: Universal MCP and system prompt compatible.
