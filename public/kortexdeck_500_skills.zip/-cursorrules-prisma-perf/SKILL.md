---
name: -cursorrules-prisma-perf
description: "Eliminates N+1 query bottlenecks by enforcing explicit select: {} projections."
category: "Data & Analytics"
platform: "cursor"
type: "Rule / Prompt"
difficulty: "Intermediate"
tags: [".cursorrules-prisma-perf", "cursorrules", "cursor", "best-practices"]
---

# Prisma ORM Performance Guard

> **Platform**: `CURSOR` | **Category**: `Data & Analytics` | **Type**: `Rule / Prompt` | **Difficulty**: `Intermediate`

## 1. Executive Summary & Purpose
.cursorrules governance file to automate team engineering standards: Eliminates N+1 query bottlenecks by enforcing explicit select: {} projections.

## 2. Activation Syntax & Command Line
```bash
// .cursorrules
.cursorrules:prisma-perf
// Active directives in Cursor IDE
```

## 3. Core Behavioral Directives & Execution Protocol
1. **Context Initialization**: Prioritize zero-latency client-side execution, defensive boundaries, and strict type safety.
2. **Autonomous Execution**: When triggered via `.cursorrules:prisma-perf`, execute all sub-tasks systematically until complete verification.
3. **Safety & Privacy**: Sanitize all inputs. Never log or transmit authentication credentials, private tokens, or sensitive user environment data.
4. **Error Handling**: Gracefully recover from network or parsing anomalies with actionable diagnostic logs.

## 4. Practical Implementation Example
```markdown
Build an authentication component strictly following the Prisma ORM Performance Guard specification.
```

## 5. Multi-Platform Agent Compatibility Matrix
- **Google Antigravity**: Native support via `/goal`, `/schedule`, and rule sidecars.
- **Anthropic Claude Code**: Integrated into `CLAUDE.md` and XML system prompt blocks.
- **Cursor IDE**: Direct compilation into `.cursorrules` and semantic index queries.
- **Windsurf / Codex / Cline / Roo Code**: Universal MCP and system prompt compatible.
