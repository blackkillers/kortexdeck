---
name: db-postgres-index-surgeon
description: "Precision indexing strategies (Partial B-Tree, GIN JSONB, BRIN time-series) and deep EXPLAIN (ANALYZE, BUFFERS) query surgery."
category: "Database"
platform: "universal"
type: "Performance Tuning"
difficulty: "Expert"
tags: ["database", "postgres", "indexing", "sql-tuning", "performance"]
---

# PostgreSQL 16 Index Surgeon & Query Optimizer

> **Platform**: `UNIVERSAL` | **Category**: `Database` | **Type**: `Performance Tuning` | **Difficulty**: `Expert`

## 1. Executive Summary & Purpose
Eliminates sequential scans on multi-million row tables. Detects index bloat, creates covering indexes with INCLUDE clauses, tunes autovacuum parameters, and eliminates deadlock hazards.

## 2. Activation Syntax & Command Line
```bash
EXPLAIN (ANALYZE, BUFFERS, SETTINGS) SELECT ...
```

## 3. Core Behavioral Directives & Execution Protocol
1. **Context Initialization**: Prioritize zero-latency client-side execution, defensive boundaries, and strict type safety.
2. **Autonomous Execution**: When triggered via `skill:db-postgres-optimizer`, execute all sub-tasks systematically until complete verification.
3. **Safety & Privacy**: Sanitize all inputs. Never log or transmit authentication credentials, private tokens, or sensitive user environment data.
4. **Error Handling**: Gracefully recover from network or parsing anomalies with actionable diagnostic logs.

## 4. Practical Implementation Example
```markdown
Optimize a slow multi-tenant query by creating a composite partial B-tree index on (tenant_id, created_at DESC) WHERE status = 'active'.
```

## 5. Multi-Platform Agent Compatibility Matrix
- **Google Antigravity**: Native support via `/goal`, `/schedule`, and rule sidecars.
- **Anthropic Claude Code**: Integrated into `CLAUDE.md` and XML system prompt blocks.
- **Cursor IDE**: Direct compilation into `.cursorrules` and semantic index queries.
- **Windsurf / Codex / Cline / Roo Code**: Universal MCP and system prompt compatible.
