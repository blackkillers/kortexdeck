---
name: -cursorrules-security-owasp
description: "Sanitizes all user inputs, prevents XSS, SQLi, and CSRF vulnerabilities."
category: "Security & Auth"
platform: "cursor"
type: "Rule / Prompt"
difficulty: "Intermediate"
tags: [".cursorrules-security-owasp", "cursorrules", "cursor", "best-practices"]
---

# OWASP Top 10 Security Guardrail

> **Platform**: `CURSOR` | **Category**: `Security & Auth` | **Type**: `Rule / Prompt` | **Difficulty**: `Intermediate`

## 1. Executive Summary & Purpose
.cursorrules governance file to automate team engineering standards: Sanitizes all user inputs, prevents XSS, SQLi, and CSRF vulnerabilities.

## 2. Activation Syntax & Command Line
```bash
// .cursorrules
.cursorrules:security-owasp
// Active directives in Cursor IDE
```

## 3. Core Behavioral Directives & Execution Protocol
1. **Context Initialization**: Prioritize zero-latency client-side execution, defensive boundaries, and strict type safety.
2. **Autonomous Execution**: When triggered via `.cursorrules:security-owasp`, execute all sub-tasks systematically until complete verification.
3. **Safety & Privacy**: Sanitize all inputs. Never log or transmit authentication credentials, private tokens, or sensitive user environment data.
4. **Error Handling**: Gracefully recover from network or parsing anomalies with actionable diagnostic logs.

## 4. Practical Implementation Example
```markdown
Build an authentication component strictly following the OWASP Top 10 Security Guardrail specification.
```

## 5. Multi-Platform Agent Compatibility Matrix
- **Google Antigravity**: Native support via `/goal`, `/schedule`, and rule sidecars.
- **Anthropic Claude Code**: Integrated into `CLAUDE.md` and XML system prompt blocks.
- **Cursor IDE**: Direct compilation into `.cursorrules` and semantic index queries.
- **Windsurf / Codex / Cline / Roo Code**: Universal MCP and system prompt compatible.
