---
name: omni-tool-451
description: "High-performance engineering directive #451 specialized for DevOps & Cloud."
category: "DevOps & Cloud"
platform: "universal"
type: "Extension"
difficulty: "Beginner"
tags: ["tool-451", "devops & cloud", "universal", "command"]
---

# Engineering Directive #451

> **Platform**: `UNIVERSAL` | **Category**: `DevOps & Cloud` | **Type**: `Extension` | **Difficulty**: `Beginner`

## 1. Executive Summary & Purpose
Detailed technical specification and execution prompt for solving advanced engineering challenges in DevOps & Cloud.

## 2. Activation Syntax & Command Line
```bash
/tool-451 --target-env <dev|staging|prod> [--debug]
```

## 3. Core Behavioral Directives & Execution Protocol
1. **Context Initialization**: Prioritize zero-latency client-side execution, defensive boundaries, and strict type safety.
2. **Autonomous Execution**: When triggered via `/tool-451`, execute all sub-tasks systematically until complete verification.
3. **Safety & Privacy**: Sanitize all inputs. Never log or transmit authentication credentials, private tokens, or sensitive user environment data.
4. **Error Handling**: Gracefully recover from network or parsing anomalies with actionable diagnostic logs.

## 4. Practical Implementation Example
```markdown
/tool-451 --target-env prod --debug
```

## 5. Multi-Platform Agent Compatibility Matrix
- **Google Antigravity**: Native support via `/goal`, `/schedule`, and rule sidecars.
- **Anthropic Claude Code**: Integrated into `CLAUDE.md` and XML system prompt blocks.
- **Cursor IDE**: Direct compilation into `.cursorrules` and semantic index queries.
- **Windsurf / Codex / Cline / Roo Code**: Universal MCP and system prompt compatible.
