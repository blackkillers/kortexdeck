---
name: uni-zero-downtime-db
description: "Applies the Expand/Contract database migration pattern under heavy production traffic."
category: "Data & Analytics"
platform: "universal"
type: "Workflow"
difficulty: "Expert"
tags: ["uni-zero-downtime-db", "universal", "architecture", "engineering"]
---

# Zero-Downtime SQL Schema Migrations

> **Platform**: `UNIVERSAL` | **Category**: `Data & Analytics` | **Type**: `Workflow` | **Difficulty**: `Expert`

## 1. Executive Summary & Purpose
Universal software engineering workflow: Applies the Expand/Contract database migration pattern under heavy production traffic. Applicable across all modern tech stacks.

## 2. Activation Syntax & Command Line
```bash
/zero-downtime-db --target <module> [--apply]
```

## 3. Core Behavioral Directives & Execution Protocol
1. **Context Initialization**: Prioritize zero-latency client-side execution, defensive boundaries, and strict type safety.
2. **Autonomous Execution**: When triggered via `/zero-downtime-db`, execute all sub-tasks systematically until complete verification.
3. **Safety & Privacy**: Sanitize all inputs. Never log or transmit authentication credentials, private tokens, or sensitive user environment data.
4. **Error Handling**: Gracefully recover from network or parsing anomalies with actionable diagnostic logs.

## 4. Practical Implementation Example
```markdown
/zero-downtime-db --target src/billing --apply
```

## 5. Multi-Platform Agent Compatibility Matrix
- **Google Antigravity**: Native support via `/goal`, `/schedule`, and rule sidecars.
- **Anthropic Claude Code**: Integrated into `CLAUDE.md` and XML system prompt blocks.
- **Cursor IDE**: Direct compilation into `.cursorrules` and semantic index queries.
- **Windsurf / Codex / Cline / Roo Code**: Universal MCP and system prompt compatible.
