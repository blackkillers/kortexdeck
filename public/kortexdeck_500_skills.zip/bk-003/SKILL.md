---
name: bk-003
description: "Design and implement GraphQL schema with resolvers, mutations, subscriptions"
category: "Backend & API"
platform: "Backend"
type: "Architecture"
difficulty: "Advanced"
tags: ["graphql", "apollo", "schema", "api"]
---

# GraphQL Schema Architect

> **Platform**: `BACKEND` | **Category**: `Backend & API` | **Type**: `Architecture` | **Difficulty**: `Advanced`

## 1. Executive Summary & Purpose
Build complete GraphQL API with Apollo Server, schema-first design, DataLoader for N+1 prevention, subscriptions via WebSocket, and field-level authorization

## 2. Activation Syntax & Command Line
```bash
/graphql-schema [type] [--resolvers] [--subscriptions]
```

## 3. Core Behavioral Directives & Execution Protocol
1. **Context Initialization**: Prioritize zero-latency client-side execution, defensive boundaries, and strict type safety.
2. **Autonomous Execution**: When triggered via `/graphql-schema`, execute all sub-tasks systematically until complete verification.
3. **Safety & Privacy**: Sanitize all inputs. Never log or transmit authentication credentials, private tokens, or sensitive user environment data.
4. **Error Handling**: Gracefully recover from network or parsing anomalies with actionable diagnostic logs.

## 4. Practical Implementation Example
```markdown
/graphql-schema User --resolvers --subscriptions
```

## 5. Multi-Platform Agent Compatibility Matrix
- **Google Antigravity**: Native support via `/goal`, `/schedule`, and rule sidecars.
- **Anthropic Claude Code**: Integrated into `CLAUDE.md` and XML system prompt blocks.
- **Cursor IDE**: Direct compilation into `.cursorrules` and semantic index queries.
- **Windsurf / Codex / Cline / Roo Code**: Universal MCP and system prompt compatible.
