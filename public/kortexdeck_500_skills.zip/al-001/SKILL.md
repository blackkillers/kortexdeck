---
name: al-001
description: "Implement binary search variants: leftmost, rightmost, rotated array"
category: "Algorithmique"
platform: "Algorithm"
type: "Search"
difficulty: "Advanced"
tags: ["binary-search", "algorithm", "leetcode", "array"]
---

# Binary Search Variants

> **Platform**: `ALGORITHM` | **Category**: `Algorithmique` | **Type**: `Search` | **Difficulty**: `Advanced`

## 1. Executive Summary & Purpose
Master binary search: classic, find first/last occurrence, search in rotated sorted array, peak element, minimized maximum, and answer binary search pattern

## 2. Activation Syntax & Command Line
```bash
/binary-search [variant] [--complexity O(log n)]
```

## 3. Core Behavioral Directives & Execution Protocol
1. **Context Initialization**: Prioritize zero-latency client-side execution, defensive boundaries, and strict type safety.
2. **Autonomous Execution**: When triggered via `/binary-search`, execute all sub-tasks systematically until complete verification.
3. **Safety & Privacy**: Sanitize all inputs. Never log or transmit authentication credentials, private tokens, or sensitive user environment data.
4. **Error Handling**: Gracefully recover from network or parsing anomalies with actionable diagnostic logs.

## 4. Practical Implementation Example
```markdown
/binary-search rotated-array
```

## 5. Multi-Platform Agent Compatibility Matrix
- **Google Antigravity**: Native support via `/goal`, `/schedule`, and rule sidecars.
- **Anthropic Claude Code**: Integrated into `CLAUDE.md` and XML system prompt blocks.
- **Cursor IDE**: Direct compilation into `.cursorrules` and semantic index queries.
- **Windsurf / Codex / Cline / Roo Code**: Universal MCP and system prompt compatible.
