---
name: code-impeccable
description: "Paul Bakaus-style design language and code auditor eliminating visual inconsistencies, low-contrast text, bad gradients, and structural sloppiness."
category: "Frontend & UI"
platform: "universal"
type: "Quality & Audit"
difficulty: "Expert"
tags: ["code-quality", "frontend", "impeccable", "design-audit", "clean-code"]
---

# Code Impeccable (Zero AI-Slop)

> **Platform**: `UNIVERSAL` | **Category**: `Frontend & UI` | **Type**: `Quality & Audit` | **Difficulty**: `Expert`

## 1. Executive Summary & Purpose
Performs deterministic static analysis and aesthetic auditing on frontend code. Enforces crisp typography ratios, clean DOM hierarchies, semantic HTML5 landmarks, and consistent spacing variables.

## 2. Activation Syntax & Command Line
```bash
/impeccable audit --strict --fix
```

## 3. Core Behavioral Directives & Execution Protocol
1. **Context Initialization**: Prioritize zero-latency client-side execution, defensive boundaries, and strict type safety.
2. **Autonomous Execution**: When triggered via `skill:code-impeccable`, execute all sub-tasks systematically until complete verification.
3. **Safety & Privacy**: Sanitize all inputs. Never log or transmit authentication credentials, private tokens, or sensitive user environment data.
4. **Error Handling**: Gracefully recover from network or parsing anomalies with actionable diagnostic logs.

## 4. Practical Implementation Example
```markdown
/impeccable audit Check the entire landing page for contrast violations, layout shifts, unstyled state fallbacks, and generic placeholder text.
```

## 5. Multi-Platform Agent Compatibility Matrix
- **Google Antigravity**: Native support via `/goal`, `/schedule`, and rule sidecars.
- **Anthropic Claude Code**: Integrated into `CLAUDE.md` and XML system prompt blocks.
- **Cursor IDE**: Direct compilation into `.cursorrules` and semantic index queries.
- **Windsurf / Codex / Cline / Roo Code**: Universal MCP and system prompt compatible.
