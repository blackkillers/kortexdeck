---
name: sc-002
description: "Generate Scrapy spiders with middlewares, pipelines, and distributed crawling"
category: "Scraping"
platform: "Scraping"
type: "Framework"
difficulty: "Advanced"
tags: ["scrapy", "python", "spider", "crawling"]
---

# Scrapy Spider Factory

> **Platform**: `SCRAPING` | **Category**: `Scraping` | **Type**: `Framework` | **Difficulty**: `Advanced`

## 1. Executive Summary & Purpose
Build production Scrapy spiders: item pipelines (MongoDB, PostgreSQL), download middlewares, rotating proxies, AutoThrottle, Splash JS rendering, and Scrapy-Splash

## 2. Activation Syntax & Command Line
```bash
/scrapy-spider [domain] [--pipeline mongo|postgres] [--js-render] [--distributed]
```

## 3. Core Behavioral Directives & Execution Protocol
1. **Context Initialization**: Prioritize zero-latency client-side execution, defensive boundaries, and strict type safety.
2. **Autonomous Execution**: When triggered via `/scrapy-spider`, execute all sub-tasks systematically until complete verification.
3. **Safety & Privacy**: Sanitize all inputs. Never log or transmit authentication credentials, private tokens, or sensitive user environment data.
4. **Error Handling**: Gracefully recover from network or parsing anomalies with actionable diagnostic logs.

## 4. Practical Implementation Example
```markdown
/scrapy-spider ecommerce.com --pipeline postgres --js-render --distributed
```

## 5. Multi-Platform Agent Compatibility Matrix
- **Google Antigravity**: Native support via `/goal`, `/schedule`, and rule sidecars.
- **Anthropic Claude Code**: Integrated into `CLAUDE.md` and XML system prompt blocks.
- **Cursor IDE**: Direct compilation into `.cursorrules` and semantic index queries.
- **Windsurf / Codex / Cline / Roo Code**: Universal MCP and system prompt compatible.
