---
name: uni-graphql-federation
description: "Unifies multiple domain subgraphs into a single, high-performance federated GraphQL gateway."
category: "Architecture & System"
platform: "universal"
type: "Workflow"
difficulty: "Expert"
tags: ["uni-graphql-federation", "universal", "architecture", "engineering"]
---

# Apollo GraphQL Federation Gateway

> **Platform**: `UNIVERSAL` | **Category**: `Architecture & System` | **Type**: `Workflow` | **Difficulty**: `Expert`

## 1. Executive Summary & Purpose
Universal software engineering workflow: Unifies multiple domain subgraphs into a single, high-performance federated GraphQL gateway. Applicable across all modern tech stacks.

## 2. Activation Syntax & Command Line
```bash
/graphql-federation --target <module> [--apply]
```

## 3. Core Behavioral Directives & Execution Protocol
1. **Context Initialization**: Prioritize zero-latency client-side execution, defensive boundaries, and strict type safety.
2. **Autonomous Execution**: When triggered via `/graphql-federation`, execute all sub-tasks systematically until complete verification.
3. **Safety & Privacy**: Sanitize all inputs. Never log or transmit authentication credentials, private tokens, or sensitive user environment data.
4. **Error Handling**: Gracefully recover from network or parsing anomalies with actionable diagnostic logs.

## 4. Practical Implementation Example
```markdown
/graphql-federation --target src/billing --apply
```

## 5. Multi-Platform Agent Compatibility Matrix
- **Google Antigravity**: Native support via `/goal`, `/schedule`, and rule sidecars.
- **Anthropic Claude Code**: Integrated into `CLAUDE.md` and XML system prompt blocks.
- **Cursor IDE**: Direct compilation into `.cursorrules` and semantic index queries.
- **Windsurf / Codex / Cline / Roo Code**: Universal MCP and system prompt compatible.
