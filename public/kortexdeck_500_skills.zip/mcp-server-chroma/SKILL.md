---
name: mcp-server-chroma
description: "Lightweight embedded vector store for local agent prototypes."
category: "AI & Multimodal"
platform: "mcp"
type: "MCP Server"
difficulty: "Beginner"
tags: ["chroma", "mcp", "server", "model-context-protocol", "ai & multimodal"]
---

# MCP ChromaDB Embedded Vector Store

> **Platform**: `MCP` | **Category**: `AI & Multimodal` | **Type**: `MCP Server` | **Difficulty**: `Beginner`

## 1. Executive Summary & Purpose
Official Model Context Protocol (MCP) server: MCP ChromaDB Embedded Vector Store. Connects AI models directly to the chroma ecosystem.

## 2. Activation Syntax & Command Line
```bash
npx -y @modelcontextprotocol/server-chroma [options]
```

## 3. Core Behavioral Directives & Execution Protocol
1. **Context Initialization**: Prioritize zero-latency client-side execution, defensive boundaries, and strict type safety.
2. **Autonomous Execution**: When triggered via `mcp://chroma`, execute all sub-tasks systematically until complete verification.
3. **Safety & Privacy**: Sanitize all inputs. Never log or transmit authentication credentials, private tokens, or sensitive user environment data.
4. **Error Handling**: Gracefully recover from network or parsing anomalies with actionable diagnostic logs.

## 4. Practical Implementation Example
```markdown
npx -y @modelcontextprotocol/server-chroma --port 3000
```

## 5. Multi-Platform Agent Compatibility Matrix
- **Google Antigravity**: Native support via `/goal`, `/schedule`, and rule sidecars.
- **Anthropic Claude Code**: Integrated into `CLAUDE.md` and XML system prompt blocks.
- **Cursor IDE**: Direct compilation into `.cursorrules` and semantic index queries.
- **Windsurf / Codex / Cline / Roo Code**: Universal MCP and system prompt compatible.
