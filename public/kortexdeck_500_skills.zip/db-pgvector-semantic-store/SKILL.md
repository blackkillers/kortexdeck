---
name: db-pgvector-semantic-store
description: "High-performance vector embedding storage and retrieval using HNSW indexing and Reciprocal Rank Fusion (RRF) hybrid search."
category: "Database"
platform: "universal"
type: "AI Vector Search"
difficulty: "Advanced"
tags: ["database", "pgvector", "postgres", "vector-search", "rag", "embeddings"]
---

# pgvector Hybrid Semantic Search Engine

> **Platform**: `UNIVERSAL` | **Category**: `Database` | **Type**: `AI Vector Search` | **Difficulty**: `Advanced`

## 1. Executive Summary & Purpose
Stores high-dimensional AI vectors directly inside PostgreSQL. Combines BM25 full-text search (tsvector) with HNSW cosine distance vector matching for state-of-the-art RAG retrieval.

## 2. Activation Syntax & Command Line
```bash
CREATE INDEX ON documents USING hnsw (embedding vector_cosine_ops) WITH (m = 16, ef_construction = 64);
```

## 3. Core Behavioral Directives & Execution Protocol
1. **Context Initialization**: Prioritize zero-latency client-side execution, defensive boundaries, and strict type safety.
2. **Autonomous Execution**: When triggered via `skill:db-pgvector-pro`, execute all sub-tasks systematically until complete verification.
3. **Safety & Privacy**: Sanitize all inputs. Never log or transmit authentication credentials, private tokens, or sensitive user environment data.
4. **Error Handling**: Gracefully recover from network or parsing anomalies with actionable diagnostic logs.

## 4. Practical Implementation Example
```markdown
Write a SQL query performing hybrid RAG retrieval combining full-text search and vector cosine similarity with Reciprocal Rank Fusion.
```

## 5. Multi-Platform Agent Compatibility Matrix
- **Google Antigravity**: Native support via `/goal`, `/schedule`, and rule sidecars.
- **Anthropic Claude Code**: Integrated into `CLAUDE.md` and XML system prompt blocks.
- **Cursor IDE**: Direct compilation into `.cursorrules` and semantic index queries.
- **Windsurf / Codex / Cline / Roo Code**: Universal MCP and system prompt compatible.
