---
name: agy-browser
description: "Navigates, clicks, fills forms, inspects DOM, and captures live screenshots in real browsers."
category: "Web & Frontend"
platform: "antigravity"
type: "Slash Command"
difficulty: "Beginner"
tags: ["browser", "web", "e2e", "scraping", "devtools", "screenshot"]
---

# Headless Web Automation (/browser)

> **Platform**: `ANTIGRAVITY` | **Category**: `Web & Frontend` | **Type**: `Slash Command` | **Difficulty**: `Beginner`

## 1. Executive Summary & Purpose
Enables controlled headless web browsing for inspecting local (localhost) or remote web apps, interacting with UI components, capturing visual diffs, and analyzing JavaScript console errors.

## 2. Activation Syntax & Command Line
```bash
/browser <url> [--action click|type|screenshot] [--query text]
```

## 3. Core Behavioral Directives & Execution Protocol
1. **Context Initialization**: Prioritize zero-latency client-side execution, defensive boundaries, and strict type safety.
2. **Autonomous Execution**: When triggered via `/browser`, execute all sub-tasks systematically until complete verification.
3. **Safety & Privacy**: Sanitize all inputs. Never log or transmit authentication credentials, private tokens, or sensitive user environment data.
4. **Error Handling**: Gracefully recover from network or parsing anomalies with actionable diagnostic logs.

## 4. Practical Implementation Example
```markdown
/browser http://localhost:5173 --action screenshot --inspect-console
```

## 5. Multi-Platform Agent Compatibility Matrix
- **Google Antigravity**: Native support via `/goal`, `/schedule`, and rule sidecars.
- **Anthropic Claude Code**: Integrated into `CLAUDE.md` and XML system prompt blocks.
- **Cursor IDE**: Direct compilation into `.cursorrules` and semantic index queries.
- **Windsurf / Codex / Cline / Roo Code**: Universal MCP and system prompt compatible.
