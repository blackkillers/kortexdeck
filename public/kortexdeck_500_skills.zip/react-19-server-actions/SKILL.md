---
name: react-19-server-actions
description: "Mastery of React 19 useActionState, useOptimistic, Server Component boundaries, and streaming suspense architecture."
category: "Frontend & UI"
platform: "universal"
type: "Architecture"
difficulty: "Advanced"
tags: ["react19", "server-actions", "frontend", "optimistic-ui", "nextjs"]
---

# React 19 Server Actions & Optimistic UI

> **Platform**: `UNIVERSAL` | **Category**: `Frontend & UI` | **Type**: `Architecture` | **Difficulty**: `Advanced`

## 1. Executive Summary & Purpose
Builds zero-waterfall full-stack interfaces using native React 19 primitives. Implements optimistic UI rollbacks on mutation failure, non-blocking form handling, and progressive hydration.

## 2. Activation Syntax & Command Line
```bash
import { useActionState, useOptimistic } from 'react'
```

## 3. Core Behavioral Directives & Execution Protocol
1. **Context Initialization**: Prioritize zero-latency client-side execution, defensive boundaries, and strict type safety.
2. **Autonomous Execution**: When triggered via `skill:react-19-pro`, execute all sub-tasks systematically until complete verification.
3. **Safety & Privacy**: Sanitize all inputs. Never log or transmit authentication credentials, private tokens, or sensitive user environment data.
4. **Error Handling**: Gracefully recover from network or parsing anomalies with actionable diagnostic logs.

## 4. Practical Implementation Example
```markdown
const [state, formAction, isPending] = useActionState(updateProfileMutation, initialState);
```

## 5. Multi-Platform Agent Compatibility Matrix
- **Google Antigravity**: Native support via `/goal`, `/schedule`, and rule sidecars.
- **Anthropic Claude Code**: Integrated into `CLAUDE.md` and XML system prompt blocks.
- **Cursor IDE**: Direct compilation into `.cursorrules` and semantic index queries.
- **Windsurf / Codex / Cline / Roo Code**: Universal MCP and system prompt compatible.
