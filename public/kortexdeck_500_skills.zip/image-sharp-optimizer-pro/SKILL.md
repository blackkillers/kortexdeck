---
name: image-sharp-optimizer-pro
description: "High-performance Node.js image transformation, responsive srcset generation, metadata stripping, and lossless AVIF encoding."
category: "Image"
platform: "universal"
type: "Image Processing"
difficulty: "Intermediate"
tags: ["image", "sharp", "webp", "avif", "optimization", "performance"]
---

# Sharp High-Speed Image Engine (WebP / AVIF)

> **Platform**: `UNIVERSAL` | **Category**: `Image` | **Type**: `Image Processing` | **Difficulty**: `Intermediate`

## 1. Executive Summary & Purpose
Processes thousands of images per minute with native libvips C bindings. Automatically resizes, crops with smart entropy detection, strips EXIF privacy data, and compresses to modern AVIF/WebP formats.

## 2. Activation Syntax & Command Line
```bash
await sharp(buffer).resize(1200, 630, { fit: 'cover' }).avif({ quality: 80 }).toFile('output.avif');
```

## 3. Core Behavioral Directives & Execution Protocol
1. **Context Initialization**: Prioritize zero-latency client-side execution, defensive boundaries, and strict type safety.
2. **Autonomous Execution**: When triggered via `skill:image-sharp-pro`, execute all sub-tasks systematically until complete verification.
3. **Safety & Privacy**: Sanitize all inputs. Never log or transmit authentication credentials, private tokens, or sensitive user environment data.
4. **Error Handling**: Gracefully recover from network or parsing anomalies with actionable diagnostic logs.

## 4. Practical Implementation Example
```markdown
Generate responsive multi-resolution WebP and AVIF assets (320w, 640w, 1280w) from raw user upload images on the fly.
```

## 5. Multi-Platform Agent Compatibility Matrix
- **Google Antigravity**: Native support via `/goal`, `/schedule`, and rule sidecars.
- **Anthropic Claude Code**: Integrated into `CLAUDE.md` and XML system prompt blocks.
- **Cursor IDE**: Direct compilation into `.cursorrules` and semantic index queries.
- **Windsurf / Codex / Cline / Roo Code**: Universal MCP and system prompt compatible.
