---
name: go-high-concurrency
description: "Idiomatic Go concurrency design with worker pools, bounded channels, context cancellation, and zero-allocation JSON streaming."
category: "Backend & API"
platform: "universal"
type: "Architecture"
difficulty: "Advanced"
tags: ["golang", "concurrency", "backend", "goroutines", "high-throughput"]
---

# Go High-Concurrency Service Engine

> **Platform**: `UNIVERSAL` | **Category**: `Backend & API` | **Type**: `Architecture` | **Difficulty**: `Advanced`

## 1. Executive Summary & Purpose
Architects production Go services handling 100k+ req/sec. Prevents goroutine leaks with context propagation, errgroup parallel execution, and race detector compliance.

## 2. Activation Syntax & Command Line
```bash
g, ctx := errgroup.WithContext(ctx)
```

## 3. Core Behavioral Directives & Execution Protocol
1. **Context Initialization**: Prioritize zero-latency client-side execution, defensive boundaries, and strict type safety.
2. **Autonomous Execution**: When triggered via `skill:go-concurrency`, execute all sub-tasks systematically until complete verification.
3. **Safety & Privacy**: Sanitize all inputs. Never log or transmit authentication credentials, private tokens, or sensitive user environment data.
4. **Error Handling**: Gracefully recover from network or parsing anomalies with actionable diagnostic logs.

## 4. Practical Implementation Example
```markdown
Implement a fan-out worker pool processing 10,000 scraping jobs concurrently with bounded concurrency of 50 workers and graceful SIGTERM shutdown.
```

## 5. Multi-Platform Agent Compatibility Matrix
- **Google Antigravity**: Native support via `/goal`, `/schedule`, and rule sidecars.
- **Anthropic Claude Code**: Integrated into `CLAUDE.md` and XML system prompt blocks.
- **Cursor IDE**: Direct compilation into `.cursorrules` and semantic index queries.
- **Windsurf / Codex / Cline / Roo Code**: Universal MCP and system prompt compatible.
